﻿param([string]$Configuration = (Join-Path $PSScriptRoot 'examples\background-local.json'), [switch]$NoTray)
$ErrorActionPreference = 'Stop'
$Configuration = [IO.Path]::GetFullPath($Configuration)
$script = Join-Path $PSScriptRoot 'Hintergrund.ps1'
& $script -Configuration $Configuration -ValidateOnly
foreach ($path in @($script,$Configuration)) { if ($path.Contains('"') -or $path.Contains("`r") -or $path.Contains("`n")) { throw 'Ungültiger Pfad.' } }
$launcher=Join-Path $PSScriptRoot 'out\BackgroundLauncher.exe'
if (!(Test-Path -LiteralPath $launcher)) { throw 'Das Hintergrund-Startprogramm fehlt. Bitte den Manager aktualisieren.' }
# The detached WMI parent avoids inheriting pipes from a setup/test caller.
# The GUI launcher itself creates PowerShell with CREATE_NO_WINDOW.
$command='"'+$launcher+'" "'+$Configuration+'"'
if ($NoTray) {$command+=' --no-tray'}
$startup=New-CimInstance -ClassName Win32_ProcessStartup -ClientOnly -Property @{ShowWindow=[uint16]0}
$result=Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{CommandLine=$command;CurrentDirectory=$PSScriptRoot;ProcessStartupInformation=$startup}
if ($result.ReturnValue -ne 0) {throw 'Der unabhängige Hintergrundprozess konnte nicht gestartet werden.'}
[PSCustomObject]@{processId=$result.ProcessId;status='Start angefordert; Zustand steht in der Paketablage.'}
