﻿param([switch]$ValidateOnly, [string]$Store = (Join-Path $PSScriptRoot 'demo-store'))
$ErrorActionPreference = 'Stop'
function New-OverviewFailureRecord {
    param(
        [ValidateSet('startup','preferences','preferences-setup','source-move','trust-rotation',
            'source-disconnect','local-remove','local-restore','company-setup','manager-updates',
            'stop-watch','package-check')]
        [string]$Operation,
        [System.Management.Automation.ErrorRecord]$Failure
    )
    $reason = if ($Failure.Exception -is [UnauthorizedAccessException]) { 'access-denied' }
        elseif ($Failure.Exception -is [IO.IOException]) { 'storage-io' }
        else { 'operation-failed' }
    $message = switch ($Operation) {
        'startup' { 'Die Übersicht konnte nicht starten. Bitte die Manager-Installation und den lokalen Speicher prüfen.' }
        'preferences' { 'Die persönlichen Einstellungen konnten nicht geöffnet werden. Bitte erneut versuchen.' }
        'preferences-setup' { 'Die Einrichtung konnte nicht geöffnet werden. Bitte erneut versuchen.' }
        'source-move' { 'Der Quellenwechsel konnte nicht geöffnet werden. Bitte erneut versuchen.' }
        'trust-rotation' { 'Der Prüfschlüsselwechsel konnte nicht geöffnet werden. Bitte erneut versuchen.' }
        'source-disconnect' { 'Die Trennung konnte nicht geöffnet werden. Bitte erneut versuchen.' }
        'local-remove' { 'Die lokale Entfernung konnte nicht geöffnet werden. Bitte erneut versuchen.' }
        'local-restore' { 'Die lokale Wiederherstellung konnte nicht geöffnet werden. Bitte erneut versuchen.' }
        'company-setup' { 'Die Firmenregeln konnten nicht geöffnet werden. Bitte erneut versuchen.' }
        'manager-updates' { 'Manager-Updates konnte nicht geöffnet werden. Bitte den Installer prüfen.' }
        'stop-watch' { 'Die Beendigung des Manager-Abgleichs konnte nicht angefordert werden. Bitte erneut versuchen.' }
        'package-check' { 'Die Paketablage konnte nicht vollständig geprüft werden. Bitte Dateien und Freigabestand prüfen lassen.' }
    }
    return [pscustomobject]@{ code = ($Operation + '/' + $reason); message = $message }
}
$script:managerWorkLease = & (Join-Path $PSScriptRoot 'Manager-Work-Lease.ps1')
trap {
    $failure = New-OverviewFailureRecord -Operation startup -Failure $_
    $logDirectory = Join-Path $env:LOCALAPPDATA 'PersonalPluginManager\logs'
    try {
        [IO.Directory]::CreateDirectory($logDirectory) | Out-Null
        $logPath=Join-Path $logDirectory 'overview-start.log'
        [IO.File]::AppendAllText($logPath, ([DateTimeOffset]::Now.ToString('o') + ' code=' + $failure.code + [Environment]::NewLine))
        Add-Type -AssemblyName System.Windows.Forms
        . (Join-Path $PSScriptRoot 'Wartungsdialog.ps1')
        Show-PathMessage -Message $failure.message -Title 'Plugin-Verwaltung' -FilePath $logPath
    } catch { [Windows.Forms.MessageBox]::Show($failure.message,'Plugin-Verwaltung') | Out-Null }
    exit 1
}
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$script:managerStore = [IO.Path]::GetFullPath($Store)
$managerExecutable = Join-Path $PSScriptRoot 'out\PluginManager.exe'

$window = New-Object System.Windows.Forms.Form
$window.Text = 'Persönliche Plugin-Verwaltung'
$window.Size = New-Object System.Drawing.Size(1100, 720)
$window.MinimumSize = New-Object System.Drawing.Size(700, 450)
$window.StartPosition = 'CenterScreen'
$window.Font = New-Object System.Drawing.Font('Segoe UI', 11)

$layout = New-Object System.Windows.Forms.TableLayoutPanel
$layout.Dock = 'Fill'
$layout.Padding = New-Object System.Windows.Forms.Padding(20)
$layout.RowCount = 5
$layout.ColumnCount = 1
$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 48))) | Out-Null
$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 60))) | Out-Null
$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent', 100))) | Out-Null
$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 160))) | Out-Null
$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 120))) | Out-Null
$window.Controls.Add($layout)

$heading = New-Object System.Windows.Forms.Label
$heading.Text = 'Deine Plugins'
$heading.Font = New-Object System.Drawing.Font('Segoe UI', 19, [System.Drawing.FontStyle]::Bold)
$heading.Dock = 'Fill'
$layout.Controls.Add($heading, 0, 0)

$description = New-Object System.Windows.Forms.Label
$description.Text = 'Die Ansicht prüft deine Paketablage. Sie installiert nichts und verändert den ChatGPT-Client nicht.'
$description.Dock = 'Fill'
$layout.Controls.Add($description, 0, 1)

$list = New-Object System.Windows.Forms.ListView
$list.View = 'Details'
$list.FullRowSelect = $true
$list.HideSelection = $false
$list.AccessibleName = 'Deine Plugins'
$list.AccessibleDescription = 'Liste mit Plugin, freigegebener Version und Zustand.'
$list.Dock = 'Fill'
$list.Columns.Add('Plugin', 250) | Out-Null
$list.Columns.Add('Freigegebene Version', 270) | Out-Null
$list.Columns.Add('Zustand', 480) | Out-Null
$layout.Controls.Add($list, 0, 2)

$status = New-Object System.Windows.Forms.Label
$status.AccessibleName = 'Prüfstatus der Plugins'
$status.Dock = 'Fill'
$status.Padding = New-Object System.Windows.Forms.Padding(0, 10, 0, 0)
$layout.Controls.Add($status, 0, 3)

$buttons = New-Object System.Windows.Forms.FlowLayoutPanel
$buttons.Dock = 'Fill'
$buttons.AutoScroll = $true
$layout.Controls.Add($buttons, 0, 4)
$choose = New-Object System.Windows.Forms.Button
$choose.Text = 'Paketablage auswählen'
$choose.AutoSize = $true
$choose.Height = 36
$buttons.Controls.Add($choose)
$refresh = New-Object System.Windows.Forms.Button
$refresh.Text = 'Jetzt online prüfen'
$refresh.AutoSize = $true
$refresh.Height = 36
$buttons.Controls.Add($refresh)
$preferences = New-Object System.Windows.Forms.Button
$preferences.Text = 'Persönliche Einstellungen'
$preferences.AutoSize = $true
$preferences.Height = 36
$buttons.Controls.Add($preferences)
$preferences.Add_Click({
    try { & (Join-Path $PSScriptRoot 'Start-Fenster.ps1') -View Preferences -Store $script:managerStore | Out-Null }
    catch { $status.Text = (New-OverviewFailureRecord -Operation preferences -Failure $_).message }
})
$preferenceSetup = New-Object System.Windows.Forms.Button
$preferenceSetup.Text = 'Einstellungen auf diesem Gerät einrichten'
$preferenceSetup.AutoSize = $true
$preferenceSetup.Height = 36
$buttons.Controls.Add($preferenceSetup)
$preferenceSetup.Add_Click({
    try { & (Join-Path $PSScriptRoot 'Start-Fenster.ps1') -View PreferencesSetup -Store $script:managerStore | Out-Null }
    catch { $status.Text = (New-OverviewFailureRecord -Operation preferences-setup -Failure $_).message }
})
$preferenceMove = New-Object System.Windows.Forms.Button
$preferenceMove.Text = 'Persönliche Quelle wechseln'
$preferenceMove.AutoSize = $true
$preferenceMove.Height = 36
$buttons.Controls.Add($preferenceMove)
$preferenceMove.Add_Click({
    try { & (Join-Path $PSScriptRoot 'Start-Fenster.ps1') -View PreferencesSourceMove -Store $script:managerStore | Out-Null }
    catch { $status.Text = (New-OverviewFailureRecord -Operation source-move -Failure $_).message }
})
$preferenceTrustRotation = New-Object System.Windows.Forms.Button
$preferenceTrustRotation.Text = 'Persönlichen Prüfschlüssel wechseln'
$preferenceTrustRotation.AutoSize = $true
$preferenceTrustRotation.Height = 36
$buttons.Controls.Add($preferenceTrustRotation)
$preferenceTrustRotation.Add_Click({
    try { & (Join-Path $PSScriptRoot 'Start-Fenster.ps1') -View PreferencesTrustRotation -Store $script:managerStore | Out-Null }
    catch { $status.Text = (New-OverviewFailureRecord -Operation trust-rotation -Failure $_).message }
})
$preferenceDisconnect = New-Object System.Windows.Forms.Button
$preferenceDisconnect.Text = 'Persönliche Quellenverbindung trennen'
$preferenceDisconnect.AutoSize = $true
$preferenceDisconnect.Height = 36
$buttons.Controls.Add($preferenceDisconnect)
$preferenceDisconnect.Add_Click({
    try { & (Join-Path $PSScriptRoot 'Start-Fenster.ps1') -View PreferencesSourceDisconnect -Store $script:managerStore | Out-Null }
    catch { $status.Text = (New-OverviewFailureRecord -Operation source-disconnect -Failure $_).message }
})
$preferenceRemove = New-Object System.Windows.Forms.Button
$preferenceRemove.Text = 'Persönliche Werte hier entfernen'
$preferenceRemove.AutoSize = $true
$preferenceRemove.Height = 36
$buttons.Controls.Add($preferenceRemove)
$preferenceRemove.Add_Click({
    try { & (Join-Path $PSScriptRoot 'Start-Fenster.ps1') -View PreferencesLocalRemove -Store $script:managerStore | Out-Null }
    catch { $status.Text = (New-OverviewFailureRecord -Operation local-remove -Failure $_).message }
})
$preferenceRestore = New-Object System.Windows.Forms.Button
$preferenceRestore.Text = 'Persönliche Werte hier wiederherstellen'
$preferenceRestore.AutoSize = $true
$preferenceRestore.Height = 36
$buttons.Controls.Add($preferenceRestore)
$preferenceRestore.Add_Click({
    try { & (Join-Path $PSScriptRoot 'Start-Fenster.ps1') -View PreferencesLocalRestore -Store $script:managerStore | Out-Null }
    catch { $status.Text = (New-OverviewFailureRecord -Operation local-restore -Failure $_).message }
})
$companySetup = New-Object System.Windows.Forms.Button
$companySetup.Text = 'Firmenregeln auf diesem Gerät einrichten'
$companySetup.AutoSize = $true
$companySetup.Height = 36
$buttons.Controls.Add($companySetup)
$companySetup.Add_Click({
    try { & (Join-Path $PSScriptRoot 'Start-Fenster.ps1') -View CompanyPreferencesSetup -Store $script:managerStore | Out-Null }
    catch { $status.Text = (New-OverviewFailureRecord -Operation company-setup -Failure $_).message }
})
$stopWatch = New-Object System.Windows.Forms.Button
$stopWatch.Text = 'Abgleich beenden'
$stopWatch.AutoSize = $true
$stopWatch.Height = 36
$buttons.Controls.Add($stopWatch)
$managerUpdates = New-Object System.Windows.Forms.Button
$managerUpdates.Text = 'Manager-Updates'
$managerUpdates.AccessibleName = 'Manager-Updates unabhängig öffnen'
$managerUpdates.AutoSize = $true
$managerUpdates.Height = 36
$buttons.Controls.Add($managerUpdates)
$managerParent=Split-Path $PSScriptRoot -Parent
$managerInstallRoot=if ((Split-Path $managerParent -Leaf) -ceq 'manager-generations' -and
    (Split-Path $PSScriptRoot -Leaf) -cmatch '^[a-f0-9]{32}-[0-9]{12}$') {
    Split-Path $managerParent -Parent
} else { $managerParent }
$stableUpdatesLauncher = Join-Path $managerInstallRoot 'bootstrap\ManagerUpdatesLauncher.exe'
$managerUpdates.Enabled = Test-Path -LiteralPath $stableUpdatesLauncher -PathType Leaf
$managerOnlyMarker = Join-Path $managerInstallRoot 'profiles\personal\manager-only.json'
$script:managerOnly = Test-Path -LiteralPath $managerOnlyMarker -PathType Leaf
if ($script:managerOnly) {
    $window.Text = 'Plugin-Manager'
    $heading.Text = 'Plugin-Manager'
    $description.Text = 'Der Manager ist eingerichtet. Ein persönliches Plugin-Profil ist noch nicht verbunden.'
    foreach ($button in @($choose,$refresh,$preferences,$preferenceSetup,$preferenceMove,
        $preferenceTrustRotation,$preferenceDisconnect,$preferenceRemove,$preferenceRestore,
        $companySetup,$stopWatch)) { $button.Visible = $false }
}
$managerUpdates.Add_Click({
    try {
        if (-not (Test-Path -LiteralPath $stableUpdatesLauncher -PathType Leaf)) {
            throw 'Der unabhängige Manager-Updates-Einstieg fehlt.'
        }
        $start = New-Object System.Diagnostics.ProcessStartInfo
        $start.FileName = $stableUpdatesLauncher
        $start.UseShellExecute = $false
        $start.CreateNoWindow = $true
        $process = [System.Diagnostics.Process]::Start($start)
        if ($null -eq $process) { throw 'Manager-Updates konnte nicht geöffnet werden.' }
        $process.Dispose()
    } catch { $status.Text = (New-OverviewFailureRecord -Operation manager-updates -Failure $_).message }
})
$stopWatch.Add_Click({
    try {
        $null = & $managerExecutable stop-watch --store $script:managerStore 2>&1
        if ($LASTEXITCODE -ne 0) { throw 'Die Beendigung konnte nicht angefordert werden.' }
        $status.Text = 'Beendigung des Manager-Abgleichs angefordert. ChatGPT und laufende Plugin-Aufgaben werden nicht beendet.'
    } catch { $status.Text = (New-OverviewFailureRecord -Operation stop-watch -Failure $_).message }
})

function Update-PluginDisplay {
    if ($script:managerOnly) {
        $list.Items.Clear()
        $description.Text = 'Der Manager ist eingerichtet. Ein persönliches Plugin-Profil ist noch nicht verbunden.'
        $status.Text = 'Manager-Updates sind verfügbar. Der Anschluss deines eigenen Plugin-Profils folgt später.'
        return
    }
    $backgroundPath = Join-Path $script:managerStore 'background-status.json'
    $description.Text = 'Die Ansicht prüft deine Paketablage. Installationen werden hier nicht ausgelöst.'
    if (Test-Path -LiteralPath $backgroundPath) {
        try {
            $background = Get-Content -LiteralPath $backgroundPath -Raw -Encoding UTF8 | ConvertFrom-Json
            $active = Get-Process -Id $background.workerId -ErrorAction SilentlyContinue
            if ($background.state -eq 'failed') {
                $description.Text = 'Der Hintergrundabgleich meldet einen Fehler. Der bisherige Paketstand bleibt erhalten.'
            } elseif ($active -and $active.StartTime.ToUniversalTime().Ticks -eq ([DateTimeOffset]$background.workerStartedAt).UtcDateTime.Ticks) {
                if ($background.installationAutomatic) { $description.Text = 'Signierter Abgleich mit Wartung aktiv: Installation erst nach Schließen von ChatGPT und Agents.' }
                else { $description.Text = 'Der Hintergrundabgleich läuft. Freigaben werden bereitgestellt; die Installation benötigt ein Wartungsfenster.' }
            } else { $description.Text = 'Der Hintergrundabgleich ist beendet. Bereits bereitgestellte Pakete bleiben verfügbar.' }
        } catch { $description.Text = 'Der Hintergrundzustand ist derzeit nicht bestätigt.' }
    }
    $refresh.Enabled = $false
    $choose.Enabled = $false
    $list.Items.Clear()
    $status.Text = 'Paketdateien werden geprüft …'
    $window.Refresh()
    $temporaryReport = Join-Path ([System.IO.Path]::GetTempPath()) ('ppm-view-' + [guid]::NewGuid().ToString('N') + '.html')
    try {
        if (-not (Test-Path -LiteralPath $managerExecutable -PathType Leaf)) { throw 'Das gebaute Programm fehlt im Ordner out.' }
        $statePath = Join-Path $script:managerStore 'staged.json'
        $stateText = Get-Content -LiteralPath $statePath -Raw
        $start = New-Object System.Diagnostics.ProcessStartInfo
        $start.FileName = $managerExecutable
        $start.UseShellExecute = $false
        $start.CreateNoWindow = $true
        $start.RedirectStandardOutput = $true
        $start.RedirectStandardError = $true
        $start.Arguments = 'status --store "' + $script:managerStore + '" --output "' + $temporaryReport + '"'
        $process = [System.Diagnostics.Process]::Start($start)
        try {
            $stdout = $process.StandardOutput.ReadToEndAsync()
            $stderr = $process.StandardError.ReadToEndAsync()
            if (-not $process.WaitForExit(15000)) { $process.Kill(); throw 'Die Prüfung dauert zu lange. Bitte erneut versuchen.' }
            $null = $stdout.Result
            $null = $stderr.Result
            if ($process.ExitCode -ne 0) { throw 'Die Paketablage konnte nicht vollständig geprüft werden. Dateien und Freigabestand prüfen lassen.' }
        } finally { $process.Dispose() }
        if ((Get-Content -LiteralPath $statePath -Raw) -cne $stateText) { throw 'Der Stand hat sich während der Prüfung geändert. Bitte erneut prüfen.' }
        $state = $stateText | ConvertFrom-Json
        foreach ($plugin in $state.plugins) {
            $item = New-Object System.Windows.Forms.ListViewItem($plugin.name)
            $item.SubItems.Add($plugin.version) | Out-Null
            $item.SubItems.Add('Bereitgestellt; Hash geprüft') | Out-Null
            $list.Items.Add($item) | Out-Null
        }
        $status.Text = 'Geprüft um ' + (Get-Date -Format 'HH:mm:ss') + ': Alle Paketdateien stimmen. Profil: ' + $state.profileId + ' | Revision: ' + $state.revision + "`r`nLokale Prüfung abgeschlossen. Neue GitHub-Freigaben lädt der Hintergrundabgleich; installiert wird dabei nicht."
    } catch {
        $status.Text = (New-OverviewFailureRecord -Operation package-check -Failure $_).message
    } finally {
        if (Test-Path -LiteralPath $temporaryReport -PathType Leaf) { Remove-Item -LiteralPath $temporaryReport }
        $refresh.Enabled = $true
        $choose.Enabled = $true
    }
}
. (Join-Path $PSScriptRoot 'Online-Ansicht.ps1')
if ($script:managerOnly) {
    foreach ($button in @($review,$install,$prepareReview)) { $button.Visible = $false }
}
$refresh.Add_Click({ Start-OnlineCheck })
$choose.Add_Click({
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = 'Eine vorhandene Paketablage des Managers auswählen.'
    $dialog.SelectedPath = $script:managerStore
    try {
        if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            $script:managerStore = $dialog.SelectedPath
            Show-OnlineState
        }
    } finally { $dialog.Dispose() }
})
$window.Add_Shown({
    if ($script:managerOnly) { Update-PluginDisplay }
    else { Show-OnlineState; Start-OnlineCheck }
})
if ($ValidateOnly) {
    'Windows interface constructed successfully; no window shown.'
    if ($managerUpdates.Enabled) { 'Independent Manager-Updates entry enabled.' }
    $window.Dispose()
    return
}
[System.Windows.Forms.Application]::Run($window)
$onlineTimer.Dispose()
$window.Dispose()
