﻿$script:observer = $null
$script:nextObservation = [DateTime]::MinValue
$script:lastTrayRead = [DateTime]::MinValue
$script:lastNotice = ''
$script:pluginAttention = $false
$script:pluginTrayText = 'Plugin-Verwaltung: Status offen'
$noticePath = Safe-Path (Join-Path $store 'last-notification.txt')
if (Test-Path $noticePath) { $script:lastNotice = [IO.File]::ReadAllText($noticePath) }
$alertIcon = $null
$alertPath = Join-Path $PSScriptRoot 'assets\plugin-manager-attention.ico'
if ($tray -and (Test-Path $alertPath)) { $alertIcon = New-Object Drawing.Icon($alertPath) }
function Update-OnlineTray {
    if ($config.mode -ne 'signed') { return }
    if ($script:observer -and $script:observer.HasExited) { $script:observer.Dispose(); $script:observer = $null }
    if (!$script:observer -and [DateTime]::UtcNow -ge $script:nextObservation) {
        $p = New-Object Diagnostics.ProcessStartInfo
        $p.FileName = $manager; $p.UseShellExecute = $false; $p.CreateNoWindow = $true
        $p.Arguments = 'check-online --store "' + $store + '"'
        try { $script:observer = [Diagnostics.Process]::Start($p) } catch { }
        $script:nextObservation = [DateTime]::UtcNow.AddSeconds($interval)
    }
    if (!$tray -or [DateTime]::UtcNow -lt $script:lastTrayRead.AddSeconds(2)) { return }
    $script:lastTrayRead = [DateTime]::UtcNow
    try {
        $view = Get-Content -LiteralPath (Safe-Path (Join-Path $store 'online-state.json')) -Raw -Encoding UTF8 | ConvertFrom-Json
        if (!$view.online) { $message = 'Online-Prüfung fehlgeschlagen. Übersicht öffnen.'; $signature = 'offline' }
        else {
            $signature = (($view.plugins | ForEach-Object { $_.name + $_.approvedVersion + $_.installedVersion + $_.state + $_.sourceState + $_.latestCommit }) -join '|')
            if (@($view.plugins | Where-Object state -eq 'recovery-required').Count) { $message = 'Wiederherstellung nötig. Übersicht öffnen.' }
            elseif (@($view.plugins | Where-Object sourceState -eq 'approval-required').Count) { $message = 'Neue Quelländerung: Prüfung und Freigabe nötig.' }
            elseif (@($view.plugins | Where-Object state -eq 'release-ready').Count) { $message = 'Update freigegeben: Installation vorbereiten.' }
            elseif (@($view.plugins | Where-Object state -eq 'installed-restart-required').Count) { $message = 'Installiert: Client neu starten.' }
            elseif ($view.attention) { $message = 'Quellprüfung nicht bestätigt. Übersicht öffnen.' }
            else { $message = 'Installiert; Client danach gestartet.' }
        }
        $info.Text = $message
        $tray.Text = ('Plugin-Verwaltung: ' + $message).Substring(0,[Math]::Min(63,('Plugin-Verwaltung: ' + $message).Length))
        $script:pluginAttention = [bool]$view.attention
        $script:pluginTrayText = $tray.Text
        if ($view.attention -and $alertIcon) { $tray.Icon = $alertIcon } elseif ($trayIcon) { $tray.Icon = $trayIcon }
        if ($view.attention -and $signature -ne $script:lastNotice) {
            $script:managerBalloonTarget=$false
            $tray.ShowBalloonTip(8000,'Plugin-Verwaltung',$message,[Windows.Forms.ToolTipIcon]::Info)
        }
        if ($script:lastNotice -ne $signature) { [IO.File]::WriteAllText($noticePath,$signature); $script:lastNotice = $signature }
    } catch { $info.Text = 'Online-Prüfung läuft; Ergebnis noch offen.' }
}
