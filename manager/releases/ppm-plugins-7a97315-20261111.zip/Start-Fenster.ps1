﻿param(
    [ValidateSet('Overview','Maintenance','Approval','Preferences','PreferencesSetup','PreferencesSourceMove','PreferencesTrustRotation','PreferencesSourceDisconnect','PreferencesLocalRemove','PreferencesLocalRestore','CompanyPreferencesSetup')][string]$View = 'Overview',
    [string]$Store = (Join-Path $PSScriptRoot 'demo-store'),
    [long]$ExpectedRevision = 0,
    [switch]$AutoStart
)
$ErrorActionPreference = 'Stop'
# CREATE_NO_WINDOW suppresses the console without SW_HIDE suppressing the GUI.
$file = if ($View -eq 'Maintenance') {
    $installedRoot=Split-Path $PSScriptRoot -Parent
    if ((Split-Path $installedRoot -Leaf) -ceq 'manager-generations' -and
        (Split-Path $PSScriptRoot -Leaf) -cmatch '^[a-f0-9]{32}-[0-9]{12}$') {
        Join-Path $PSScriptRoot 'Aktualisieren.ps1'
    } elseif (Test-Path -LiteralPath (Join-Path $installedRoot 'installation.json')) { Join-Path $installedRoot 'Aktualisieren.ps1' }
    else { Join-Path $env:USERPROFILE '.personal-plugin-manager\Aktualisieren.ps1' }
} elseif ($View -eq 'Approval') { Join-Path $PSScriptRoot 'Freigabe.ps1' }
elseif ($View -eq 'Preferences') { Join-Path $PSScriptRoot 'Persoenliche-Einstellungen.ps1' }
elseif ($View -eq 'PreferencesSetup') { Join-Path $PSScriptRoot 'Persoenliche-Einstellungen-Einrichten.ps1' }
elseif ($View -eq 'PreferencesSourceMove') { Join-Path $PSScriptRoot 'Persoenliche-Einstellungen-Einrichten.ps1' }
elseif ($View -eq 'PreferencesTrustRotation') { Join-Path $PSScriptRoot 'Persoenliche-Einstellungen-Einrichten.ps1' }
elseif ($View -eq 'PreferencesSourceDisconnect') { Join-Path $PSScriptRoot 'Persoenliche-Einstellungen-Einrichten.ps1' }
elseif ($View -eq 'PreferencesLocalRemove' -or $View -eq 'PreferencesLocalRestore') { Join-Path $PSScriptRoot 'Persoenliche-Einstellungen-Lokal.ps1' }
elseif ($View -eq 'CompanyPreferencesSetup') { Join-Path $PSScriptRoot 'Persoenliche-Einstellungen-Einrichten.ps1' }
else { Join-Path $PSScriptRoot 'Plugin-Verwaltung.ps1' }
if (!(Test-Path -LiteralPath $file -PathType Leaf)) { throw ('Fensterprogramm fehlt: ' + $file) }
$arguments = @('-NoProfile','-STA','-File',$file)
if ($View -eq 'Maintenance') {
    $arguments += @('-Guide','-ExpectedRevision',[string]$ExpectedRevision)
    if ($AutoStart) { $arguments += '-AutoStart' }
}
else { $arguments += @('-Store',[IO.Path]::GetFullPath($Store)) }
if ($View -eq 'CompanyPreferencesSetup') { $arguments += '-Company' }
if ($View -eq 'PreferencesSourceMove') { $arguments += '-Move' }
if ($View -eq 'PreferencesTrustRotation') { $arguments += '-Rotate' }
if ($View -eq 'PreferencesSourceDisconnect') { $arguments += '-Disconnect' }
if ($View -eq 'PreferencesLocalRestore') { $arguments += '-Restore' }
foreach ($argument in $arguments) {
    if ($argument -match '["\r\n]' -or $argument.EndsWith('\')) { throw 'Ungueltiger Fensterparameter.' }
}
$start = New-Object Diagnostics.ProcessStartInfo
$start.FileName = Join-Path ([Environment]::GetFolderPath('System')) 'WindowsPowerShell\v1.0\powershell.exe'
$start.UseShellExecute = $false
$start.CreateNoWindow = $true
$start.Arguments = ($arguments | ForEach-Object { '"' + $_ + '"' }) -join ' '
$process = [Diagnostics.Process]::Start($start)
try {
    if ($process.WaitForExit(1200) -and $process.ExitCode -ne 0) {
        throw 'Die Fensteranwendung wurde beim Start beendet.'
    }
    [pscustomobject]@{ processId = $process.Id; view = $View }
} finally { $process.Dispose() }
