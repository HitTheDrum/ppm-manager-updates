﻿param([Alias('InstallRoot')][string]$ShortcutInstallRoot, [Alias('ProgramsDirectory')][string]$ShortcutProgramsDirectory)

# Shared by device setup and plugin maintenance; importing this file has no effects.
function Ensure-ManagerStartMenuEntry {
    param([Parameter(Mandatory=$true)][string]$InstallRoot, [string]$ProgramsDirectory)
    $ErrorActionPreference='Stop'
    function Checked-StartPath([string]$Path) {
        $full=[IO.Path]::GetFullPath($Path)
        if ($full -match '["\r\n]' -or $full.EndsWith('\')) { throw 'Ungültiger Startmenü-Pfad.' }
        for ($part=$full; $part; $part=[IO.Path]::GetDirectoryName($part)) {
            if ((Test-Path -LiteralPath $part) -and ((Get-Item -LiteralPath $part -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Verknüpfte Startmenü-Pfade sind nicht erlaubt.' }
        }
        return $full
    }
    function Start-FileHash([string]$Path) {
        $algorithm=[Security.Cryptography.SHA256]::Create()
        try { return [BitConverter]::ToString($algorithm.ComputeHash([IO.File]::ReadAllBytes($Path))).Replace('-','').ToLowerInvariant() }
        finally { $algorithm.Dispose() }
    }
    function Write-StartFile([string]$Path, [byte[]]$Bytes) {
        $temporary=$Path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
        try {
            [IO.File]::WriteAllBytes($temporary,$Bytes)
            if (Test-Path -LiteralPath $Path) { [IO.File]::Replace($temporary,$Path,[NullString]::Value) }
            else { [IO.File]::Move($temporary,$Path) }
        } finally { if (Test-Path -LiteralPath $temporary) { [IO.File]::Delete($temporary) } }
    }
    $root=Checked-StartPath $InstallRoot
    $settings=Get-Content -LiteralPath (Join-Path $root 'installation.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $app=Checked-StartPath ([string]$settings.appDirectory)
    $profile=Checked-StartPath ([string]$settings.profileDirectory)
    foreach ($path in @($app,$profile)) {
        if (!$path.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Die Startmenü-Zuordnung gehört nicht zu dieser Installation.' }
    }
    foreach ($path in @((Join-Path $app 'out\BackgroundLauncher.exe'),(Join-Path $profile 'background.json'))) {
        $null=Checked-StartPath $path
        if (!(Test-Path -LiteralPath $path -PathType Leaf)) { throw ('Startdatei fehlt: '+$path) }
    }
    if (!$ProgramsDirectory) { $ProgramsDirectory=[Environment]::GetFolderPath('Programs') }
    $programs=Checked-StartPath $ProgramsDirectory
    $entry=Checked-StartPath (Join-Path $programs 'Plugin-Verwaltung.lnk')
    $updatesEntry=Checked-StartPath (Join-Path $programs 'Manager-Updates.lnk')
    $legacy=Checked-StartPath (Join-Path $programs 'Persönliche Plugin-Verwaltung.lnk')
    $shellPath=Join-Path ([Environment]::GetFolderPath('System')) 'WindowsPowerShell\v1.0\powershell.exe'
    $starter=Checked-StartPath (Join-Path $root 'Manager-starten.ps1')
    $icon=Checked-StartPath (Join-Path $root 'Plugin-Verwaltung.ico')
    $arguments='-NoProfile -STA -WindowStyle Hidden -File "'+$starter+'"'
    $stableLauncher=Checked-StartPath (Join-Path $root 'bootstrap\ManagerUpdatesLauncher.exe')
    $stableAvailable=Test-Path -LiteralPath $stableLauncher -PathType Leaf
    $stableIcon=Checked-StartPath (Join-Path $root 'bootstrap\plugin-manager.ico')
    if ($stableAvailable -and !(Test-Path -LiteralPath $stableIcon -PathType Leaf)) {
        throw 'Das Icon des unabhängigen Manager-Updates-Einstiegs fehlt.'
    }
    $targetPath=if ($stableAvailable) { $stableLauncher } else { $shellPath }
    $targetArguments=if ($stableAvailable) { '' } else { $arguments }
    $receiptPath=Checked-StartPath (Join-Path $root 'start-menu.json')
    $sha=[Security.Cryptography.SHA256]::Create()
    try { $identity=[BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($root.ToUpperInvariant()))).Replace('-','').Substring(0,24) }
    finally { $sha.Dispose() }
    $mutex=New-Object Threading.Mutex($false,('Local\PersonalPluginManager-StartMenu-'+$identity))
    $held=$false
    try {
        try { $held=$mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $held=$true }
        if (!$held) { throw 'Der Startmenü-Eintrag wird bereits aktualisiert. Bitte erneut versuchen.' }
        $shell=New-Object -ComObject WScript.Shell
        function Is-ManagerEntry($Link) {
            if ($stableAvailable -and $Link.TargetPath -ieq $stableLauncher -and -not $Link.Arguments) { return $true }
            if ($Link.TargetPath -ieq $shellPath) {
                if ($Link.Arguments -ceq $arguments) { return $true }
                $match=[regex]::Match($Link.Arguments,'^-NoProfile -STA -WindowStyle Hidden -File "([^"]+)"$')
                if ($match.Success) {
                    $old=Checked-StartPath $match.Groups[1].Value
                    return $old.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase) -and [IO.Path]::GetFileName($old) -ieq 'Manager-starten.ps1'
                }
            }
            # Adopt the earlier local shortcut that directly started the tray launcher.
            $oldTarget=[string]$Link.TargetPath
            return $oldTarget.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase) -and $oldTarget.EndsWith('\out\BackgroundLauncher.exe',[StringComparison]::OrdinalIgnoreCase) -and $Link.Arguments -ceq ('"'+(Join-Path $profile 'background.json')+'"')
        }
        if ((Test-Path -LiteralPath $entry) -and !(Is-ManagerEntry ($shell.CreateShortcut($entry)))) { throw 'Eine fremde Startmenü-Verknüpfung „Plugin-Verwaltung“ wird nicht überschrieben.' }
        if ($stableAvailable -and (Test-Path -LiteralPath $updatesEntry)) {
            $existingUpdates=$shell.CreateShortcut($updatesEntry)
            if ($existingUpdates.TargetPath -ine $stableLauncher -or $existingUpdates.Arguments) {
                throw 'Eine fremde Startmenü-Verknüpfung „Manager-Updates“ wird nicht überschrieben.'
            }
        }
        $previous=$null
        if (Test-Path -LiteralPath $receiptPath) { $previous=Get-Content -LiteralPath $receiptPath -Raw -Encoding UTF8 | ConvertFrom-Json }
        $sources=@{'Manager-starten.ps1'=(Join-Path $app 'Manager-starten.ps1');'Plugin-Verwaltung.ico'=(Join-Path $app 'assets\plugin-manager.ico')}
        $hashes=@{}
        foreach ($name in $sources.Keys) {
            $source=Checked-StartPath $sources[$name]
            if (!(Test-Path -LiteralPath $source -PathType Leaf)) { throw ('Startmenü-Datei fehlt: '+$source) }
            $hashes[$name]=Start-FileHash $source
            $destination=Checked-StartPath (Join-Path $root $name)
            if (Test-Path -LiteralPath $destination) {
                $actual=Start-FileHash $destination
                $oldHash=if ($previous -and $previous.files) { $previous.files.PSObject.Properties[$name].Value } else { $null }
                if ($actual -ne $hashes[$name] -and $actual -ne $oldHash) { throw ('Eine fremde oder bearbeitete Startdatei wird nicht ersetzt: '+$name) }
            }
        }
        [IO.Directory]::CreateDirectory($programs) | Out-Null
        foreach ($name in $sources.Keys) {
            $destination=Join-Path $root $name
            if (!(Test-Path -LiteralPath $destination) -or (Start-FileHash $destination) -ne $hashes[$name]) { Write-StartFile $destination ([IO.File]::ReadAllBytes($sources[$name])) }
        }
        $link=$shell.CreateShortcut($entry)
        $iconLocation=$icon+',0'
        if (!(Test-Path -LiteralPath $entry) -or $link.TargetPath -ine $targetPath -or $link.Arguments -cne $targetArguments -or $link.IconLocation -ine $iconLocation -or $link.WorkingDirectory -ine $root -or $link.WindowStyle -ne 7) {
            $temporary=Join-Path $programs ('.ppm-'+[guid]::NewGuid().ToString('N')+'.lnk')
            try {
                $link=$shell.CreateShortcut($temporary)
                $link.TargetPath=$targetPath;$link.Arguments=$targetArguments;$link.WorkingDirectory=$root;$link.WindowStyle=7
                $link.Description='Persönliche Plugin-Verwaltung öffnen';$link.IconLocation=$iconLocation;$link.Save()
                Write-StartFile $entry ([IO.File]::ReadAllBytes($temporary))
            } finally { if (Test-Path -LiteralPath $temporary) { [IO.File]::Delete($temporary) } }
        }
        $verified=$shell.CreateShortcut($entry)
        if ($verified.TargetPath -ine $targetPath -or $verified.Arguments -cne $targetArguments -or $verified.IconLocation -ine $iconLocation -or (Start-FileHash $icon) -ne $hashes['Plugin-Verwaltung.ico']) { throw 'Startmenü-Eintrag oder Icon konnte nicht bestätigt werden.' }
        if ($stableAvailable) {
            $updateIconLocation=$stableIcon+',0'
            $updateWorkingDirectory=Split-Path $stableLauncher -Parent
            $updates=$shell.CreateShortcut($updatesEntry)
            if (!(Test-Path -LiteralPath $updatesEntry) -or $updates.TargetPath -ine $stableLauncher -or
                $updates.Arguments -or $updates.IconLocation -ine $updateIconLocation -or
                $updates.WorkingDirectory -ine $updateWorkingDirectory) {
                $temporary=Join-Path $programs ('.ppm-'+[guid]::NewGuid().ToString('N')+'.lnk')
                try {
                    $updates=$shell.CreateShortcut($temporary)
                    $updates.TargetPath=$stableLauncher;$updates.Arguments=''
                    $updates.WorkingDirectory=$updateWorkingDirectory
                    $updates.IconLocation=$updateIconLocation
                    $updates.Description='Unabhängigen Manager-Update-Status öffnen'
                    $updates.Save()
                    Write-StartFile $updatesEntry ([IO.File]::ReadAllBytes($temporary))
                } finally { if (Test-Path -LiteralPath $temporary) { [IO.File]::Delete($temporary) } }
            }
            $verifiedUpdates=$shell.CreateShortcut($updatesEntry)
            if ($verifiedUpdates.TargetPath -ine $stableLauncher -or $verifiedUpdates.Arguments -or
                $verifiedUpdates.IconLocation -ine $updateIconLocation -or
                $verifiedUpdates.WorkingDirectory -ine $updateWorkingDirectory) {
                throw 'Manager-Updates-Startmenüeintrag konnte nicht bestätigt werden.'
            }
        }
        $record=@{schemaVersion=1;entry=$entry;files=$hashes} | ConvertTo-Json -Depth 4
        Write-StartFile $receiptPath ([Text.Encoding]::UTF8.GetBytes($record))
        if ((Test-Path -LiteralPath $legacy) -and (Is-ManagerEntry ($shell.CreateShortcut($legacy)))) { [IO.File]::Delete($legacy) }
        return [pscustomobject]@{verified=$true;entry=$entry;updatesEntry=$(if($stableAvailable){$updatesEntry}else{$null});icon=$icon;starter=$starter}
    } finally { if ($held) { $mutex.ReleaseMutex() }; $mutex.Dispose() }
}

if ($ShortcutInstallRoot) {
    $ErrorActionPreference='Stop'
    [Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)
    Ensure-ManagerStartMenuEntry -InstallRoot $ShortcutInstallRoot -ProgramsDirectory $ShortcutProgramsDirectory | ConvertTo-Json
}
