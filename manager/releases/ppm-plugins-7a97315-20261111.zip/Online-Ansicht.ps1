﻿# Loaded by the existing Windows overview. No installation is performed by an online check.
$script:onlineProcess = $null
$script:onlineView = $null
$script:lastOnlineFile = ''
$onlineTimer = New-Object Windows.Forms.Timer
$onlineTimer.Interval = 500
function Show-OnlineState {
    if ($script:managerOnly) { Update-PluginDisplay; return }
    $path = Join-Path $script:managerStore 'online-state.json'
    if (!(Test-Path -LiteralPath $path)) { $status.Text = 'Noch keine Online-Prüfung. Klicke auf Jetzt online prüfen.'; return }
    try {
        $view = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
        $fileStamp = $path + ':' + (Get-Item -LiteralPath $path).LastWriteTimeUtc.Ticks
        if ($script:lastOnlineFile -eq $fileStamp) { return }
        $script:lastOnlineFile = $fileStamp
        $description.Text = 'Quelle geändert → Freigabe prüfen → Installation → Client neu starten. Ein Push allein ist keine Freigabe.'
        $stamp = ([DateTimeOffset]$view.checkedAt).ToLocalTime().ToString('dd.MM. HH:mm:ss')
        $script:onlineView = $null
        if (!$view.online) { $status.Text = 'Online-Prüfung vom ' + $stamp + ': ' + $view.message; return }
        $list.Items.Clear(); $script:onlineView = $view
        foreach ($p in $view.plugins) {
            $label = switch ($p.state) {
                'release-ready' { 'Installation nötig' }
                'recovery-required' { 'Wiederherstellung erforderlich' }
                'installed-client-restarted' { 'Installiert; Client danach gestartet' }
                default { 'Installiert; Neustart nötig' }
            }
            if ($p.sourceState -eq 'approval-required') { $label += ' | Quelländerung: Abnahme nötig' }
            elseif ($p.sourceState -eq 'unavailable') { $label += ' | Quellprüfung fehlgeschlagen' }
            elseif ($p.sourceState -eq 'not-configured') { $label += ' | Quellüberwachung fehlt' }
            $item = New-Object Windows.Forms.ListViewItem($p.name)
            $item.SubItems.Add($p.approvedVersion) | Out-Null
            $item.SubItems.Add($label) | Out-Null
            $list.Items.Add($item) | Out-Null
        }
        $status.Text = 'Online geprüft: ' + $stamp + ' | Profil-Revision: ' + $view.revision + "`r`n" + (($view.plugins | ForEach-Object { $_.name + ' (installiert: ' + $_.installedVersion + '): ' + $_.nextStep }) -join "`r`n")
    } catch { $status.Text = 'Der Online-Status ist nicht lesbar. Bitte erneut online prüfen.' }
}
function Start-OnlineCheck {
    param([switch]$PrepareReview)
    if ($script:managerOnly) { Update-PluginDisplay; return }
    if ($script:onlineProcess) { return }
    if (!(Test-Path (Join-Path $script:managerStore 'sync-binding.json'))) { Update-PluginDisplay; $status.Text += "`r`nDiese Testablage hat keine Online-Quelle."; return }
    $start = New-Object Diagnostics.ProcessStartInfo
    $start.FileName = $managerExecutable; $start.UseShellExecute = $false; $start.CreateNoWindow = $true
    $script:onlineMode = if ($PrepareReview) { 'prepare-review' } else { 'check-online' }
    $start.RedirectStandardOutput = $true; $start.RedirectStandardError = $true
    $start.Arguments = $script:onlineMode + ' --store "' + $script:managerStore + '"'
    try {
        $script:onlineProcess = [Diagnostics.Process]::Start($start)
        $script:onlineOutput = $script:onlineProcess.StandardOutput.ReadToEndAsync()
        $script:onlineError = $script:onlineProcess.StandardError.ReadToEndAsync()
        $refresh.Enabled = $false; $choose.Enabled = $false
        $status.Text = 'Online-Prüfung läuft: signierte Freigabe und eingerichtete Quellrepositories …'
        $onlineTimer.Start()
    } catch { $status.Text = 'Online-Prüfung konnte nicht gestartet werden.' }
}
$onlineTimer.Add_Tick({
    if ($script:onlineProcess -and $script:onlineProcess.HasExited) {
        $exitCode = $script:onlineProcess.ExitCode
        $outputText = $script:onlineOutput.GetAwaiter().GetResult()
        $null = $script:onlineError.GetAwaiter().GetResult()
        $script:onlineProcess.Dispose(); $script:onlineProcess = $null
        $script:lastOnlineFile = ''; $refresh.Enabled = $true; $choose.Enabled = $true
        Show-OnlineState
        if ($exitCode -eq 0 -and $script:onlineMode -eq 'prepare-review') {
            try {
                $report = $outputText | ConvertFrom-Json
                if ($report.prepared) {
                    $reportPath = [IO.Path]::GetFullPath([string]$report.path)
                    $reviewRoot = [IO.Path]::GetFullPath((Join-Path $script:managerStore 'reviews')).TrimEnd('\') + '\'
                    if (!$reportPath.StartsWith($reviewRoot,[StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetExtension($reportPath) -ne '.md') { throw 'Ungueltiger Berichtspfad' }
                    Start-Process notepad.exe -ArgumentList ('"' + $reportPath + '"')
                    $status.Text = 'Abnahmebericht geöffnet. Noch nicht freigegeben: Änderungen und Tests prüfen, danach eine neue signierte Freigabe veröffentlichen.'
                } else { $status.Text = $report.message }
            } catch { $status.Text = 'Abnahmebericht konnte nicht geöffnet werden.' }
        }
        if ($exitCode -ne 0) { $status.Text = 'Prüfung fehlgeschlagen oder bereits im Hintergrund aktiv. ' + $status.Text }
    } elseif (!$script:onlineProcess) { Show-OnlineState }
})
if (-not $script:managerOnly) { $onlineTimer.Start() }
$review = New-Object Windows.Forms.Button
$review.Text = 'Quelländerungen ansehen'; $review.AutoSize = $true
$buttons.Controls.Add($review)
$review.Add_Click({
    if ($list.SelectedIndices.Count -eq 0 -or !$script:onlineView) { $status.Text = 'Bitte zuerst online prüfen und ein Plugin auswählen.'; return }
    $url = $script:onlineView.plugins[$list.SelectedIndices[0]].reviewUrl
    if ($url -match '^https://github.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+/compare/[a-f0-9]{40}\.\.\.[a-f0-9]{40}$') { Start-Process $url }
    else { $status.Text = 'Für diese Quelle liegt kein geprüfter Vergleichslink vor.' }
})
$install = New-Object Windows.Forms.Button
$install.Text = 'Installation vorbereiten'; $install.AutoSize = $true
$buttons.Controls.Add($install)
$install.Add_Click({
    $installedRoot=Split-Path $PSScriptRoot -Parent
    if (!(Test-Path -LiteralPath (Join-Path $installedRoot 'installation.json'))) { $installedRoot=Join-Path $env:USERPROFILE '.personal-plugin-manager' }
    $starter = Join-Path $installedRoot 'Aktualisieren.ps1'
    $personalStore = Join-Path $installedRoot 'profiles\personal\store'
    if ($script:managerStore -ne $personalStore -or !$script:onlineView.online -or $script:onlineView.revision -le 0 -or @($script:onlineView.plugins | Where-Object state -eq 'recovery-required').Count -gt 0 -or !(Test-Path $starter)) {
        $status.Text = 'Für diesen Stand fehlt noch ein geprüfter Wartungsauftrag. Die Freigabe muss als konkreter Installationsauftrag vorbereitet werden.'; return
    }
    try { & (Join-Path $PSScriptRoot 'Start-Fenster.ps1') -View Maintenance -ExpectedRevision $script:onlineView.revision | Out-Null }
    catch { $status.Text = 'Installationsdialog konnte nicht starten. Bitte die Wartungsinstallation prüfen.' }
})

$prepareReview = New-Object Windows.Forms.Button
$prepareReview.Text = 'Abnahme vorbereiten'; $prepareReview.AutoSize = $true
$buttons.Controls.Add($prepareReview)
$prepareReview.Add_Click({
    if (Test-Path -LiteralPath (Join-Path $script:managerStore 'authoring-config.json')) {
        try { & (Join-Path $PSScriptRoot 'Start-Fenster.ps1') -View Approval -Store $script:managerStore | Out-Null }
        catch { $status.Text = 'Freigabedialog konnte nicht starten. Bitte die Einrichtung des Freigabegeräts prüfen.' }
    } else { Start-OnlineCheck -PrepareReview }
})

# A read-only device needs one install action; authoring controls belong on the signing device.
if (!(Test-Path -LiteralPath (Join-Path $script:managerStore 'authoring-config.json'))) {
    $choose.Visible = $false
    $stopWatch.Visible = $false
    $review.Visible = $false
    $prepareReview.Visible = $false
    $refresh.Text = 'Erneut prüfen'
    $install.Text = 'Installieren oder aktualisieren'
}
