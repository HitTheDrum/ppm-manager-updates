﻿param([switch]$ValidateOnly, [switch]$Guide, [long]$ExpectedRevision = 0, [switch]$AutoStart, [string]$ProgramsDirectory)
$ErrorActionPreference = 'Stop'
function New-MaintenanceFailureRecord {
    param(
        [ValidateSet('startup','execution','device-restore','watch-restart')][string]$Operation,
        [System.Management.Automation.ErrorRecord]$Failure
    )
    $reason = if ($Failure.Exception -is [UnauthorizedAccessException]) { 'access-denied' }
        elseif ($Failure.Exception -is [IO.IOException]) { 'storage-io' }
        else { 'operation-failed' }
    $message = switch ($Operation) {
        'startup' { 'Die Plugin-Wartung konnte nicht starten. Bitte die Installation und den lokalen Speicher prüfen.' }
        'execution' { 'Der Plugin-Wartungsschritt wurde angehalten. Bitte den bisherigen Stand im Wartungsfenster prüfen und erst danach erneut versuchen.' }
        'device-restore' { 'Die Geräteeinstellungen konnten nicht wiederhergestellt werden. Bitte den bisherigen Stand prüfen lassen.' }
        'watch-restart' { 'Der Hintergrundabgleich konnte nicht wieder gestartet werden. Bitte den Dienstzustand prüfen lassen.' }
    }
    return [pscustomobject]@{ code = ($Operation + '/' + $reason); message = $message }
}
trap {
    $failure = New-MaintenanceFailureRecord -Operation startup -Failure $_
    try {
        $logs = Join-Path $env:LOCALAPPDATA 'PersonalPluginManager\logs'
        [IO.Directory]::CreateDirectory($logs) | Out-Null
        [IO.File]::AppendAllText((Join-Path $logs 'maintenance-start.log'), ([DateTimeOffset]::Now.ToString('o') + ' code=' + $failure.code + [Environment]::NewLine))
        if (!$ValidateOnly) {
            Add-Type -AssemblyName System.Windows.Forms
            [Windows.Forms.MessageBox]::Show($failure.message, 'Plugin-Aktualisierung: Vorbereitung angehalten') | Out-Null
        } else { Write-Output $failure.message }
    } catch { }
    exit 1
}
$managerParent=Split-Path $PSScriptRoot -Parent
$versionedManager=((Split-Path $managerParent -Leaf) -ceq 'manager-generations' -and
    (Split-Path $PSScriptRoot -Leaf) -cmatch '^[a-f0-9]{32}-[0-9]{12}$')
$root = if ($versionedManager) { Split-Path $managerParent -Parent } else { $PSScriptRoot }
$installationPath=Join-Path $root 'installation.json'
if (Test-Path -LiteralPath $installationPath) {
    $settings=Get-Content -LiteralPath $installationPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $app=if ($versionedManager) { $PSScriptRoot } else { [string]$settings.appDirectory }
    $profile=[string]$settings.profileDirectory
    $clientHome=[string]$settings.clientHome

} else {
    $app=Join-Path $root 'app-client-0155'
    $profile=Join-Path $root 'profiles\personal'
    $clientHome=Join-Path $env:USERPROFILE '.codex'
    $settings=Get-Content -LiteralPath (Join-Path $root 'adoption-settings.json') -Raw -Encoding UTF8 | ConvertFrom-Json
}
if (Test-Path -LiteralPath $installationPath) {
    $script:managerWorkLease = & (Join-Path $app 'Manager-Work-Lease.ps1')
}
$store=Join-Path $profile 'store'
$manager=Join-Path $app 'out\PluginManager.exe'
$cli=[string]$settings.cli
$script:unresolvedWorker=$false
$script:lastErrorLogPath=''
$devicePath = Join-Path $profile 'device.json'
. (Join-Path $PSScriptRoot 'Wartungsdialog.ps1')
function Check-Closed {
    $blockers = @(Get-MaintenanceBlockers)
    if ($blockers.Count) {
        throw ("Noch geöffnet: " + ($blockers -join '; ') + '. Bitte Arbeit speichern und diese Programme schließen. Danach das Update erneut starten.')
    }
}
function Run-Manager([string[]]$CommandArguments) {
    $stage = switch ($CommandArguments[0]) {
        'stop-watch' { 'Hintergrundabgleich wird angehalten …' }
        'sync' { 'Signierte Freigabe und Paketdateien werden geprüft …' }
        'prepare-activation' { 'Installation wird vorbereitet …' }
        'update-candidate' { 'Plugin wird installiert und anschließend überprüft …' }
        'recover-update' { 'Vorheriger Plugin-Stand wird wiederhergestellt …' }
        'adoption-plan' { 'Vorhandene Plugin-Installation wird geprüft …' }
        'adopt-existing' { 'Vorhandenes Plugin wird gesichert und übernommen …' }
        'recover-adoption' { 'Bisherige Plugin-Zuordnung wird wiederhergestellt …' }
        default { 'Update wird bearbeitet …' }
    }
    Set-MaintenanceProgress $stage
    $start = New-Object Diagnostics.ProcessStartInfo
    $start.FileName=$manager; $start.UseShellExecute=$false; $start.CreateNoWindow=$true
    $start.RedirectStandardOutput=$true; $start.RedirectStandardError=$true
    $start.Arguments=($CommandArguments | ForEach-Object {
        if ($_ -match '["\r\n]' -or $_.EndsWith('\')) { throw 'Ungueltiges Befehlsargument.' }
        '"'+$_+'"'
    }) -join ' '
    $process=[Diagnostics.Process]::Start($start)
    $stdout=$process.StandardOutput.ReadToEndAsync();$stderr=$process.StandardError.ReadToEndAsync()
    try {
        $waitDeadline = [DateTime]::UtcNow.AddSeconds(120)
        while (!$process.WaitForExit(100) -and [DateTime]::UtcNow -lt $waitDeadline) { [Windows.Forms.Application]::DoEvents() }
        if (!$process.HasExited) { $script:unresolvedWorker=$true;throw 'Zeitlimit erreicht. Ein moeglicher laufender Wartungsvorgang muss geprueft werden; keine Wiederholung starten.' }
        $text=$stdout.GetAwaiter().GetResult();$errorText=$stderr.GetAwaiter().GetResult()
        $logPath=Join-Path $root 'update-operation.log'
        $entry="`r`n[$([DateTimeOffset]::Now.ToString('o'))] $($CommandArguments[0]) exit=$($process.ExitCode)`r`n"
        [IO.File]::AppendAllText($logPath,$entry)
        if ($process.ExitCode -ne 0) {
            $script:lastErrorLogPath=$logPath
            if ($errorText -like '*already installed from another source*') { throw 'Ein angefordertes Plugin ist bereits aus einer anderen Quelle installiert. Es wurde nicht ersetzt oder doppelt installiert. Für diesen Bestand muss zunächst eine ausdrückliche Übernahme eingerichtet werden.' }
            throw (Format-MaintenanceFailure -Operation $CommandArguments[0] -Stage $stage -ErrorText $errorText -ExitCode $process.ExitCode)
        }
        $script:lastManagerOutput = $text
    } finally { $process.Dispose() }
}
function Get-MaintenancePlan {
    Run-Manager @('maintenance-plan','--store',$store)
    return ($script:lastManagerOutput | ConvertFrom-Json)
}
function Assert-SelectedPlan {
    $current = Get-MaintenancePlan
    if ($current.fingerprint -cne $script:selectedPlan.fingerprint) {
        throw 'Die Freigabe oder Installation hat sich seit der Vorschau geändert. Es wird nichts Neues installiert. Bitte die Übersicht erneut prüfen und den geänderten Plan bestätigen.'
    }
}
function Sync-Profile {
    Run-Manager @('sync','--source',(Join-Path $profile 'source.json'),'--trust',(Join-Path $profile 'trust.json'),'--device',$devicePath,'--store',$store)
}
if (Test-Path -LiteralPath $installationPath) {
    $checkCommand = if ($ValidateOnly) { 'setup-check-client' } else { 'setup-refresh-client' }
    $compatibilityText = & $manager $checkCommand --install-root $root
    if ($LASTEXITCODE -ne 0) { throw 'Der aktuelle Client konnte nicht sicher geprüft und zugeordnet werden. Offene Wartung zuerst abschließen; fehlgeschlagene Funktionsprüfungen bleiben gesperrt.' }
    $cli = [string](($compatibilityText | ConvertFrom-Json).cli)
} else {
$bundledRoot = Join-Path $env:LOCALAPPDATA 'OpenAI\Codex\bin'
if (!(Test-Path -LiteralPath $cli -PathType Leaf) -or $cli.Replace('/','\').StartsWith($bundledRoot.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)) {
    $discoveryText = & $manager setup-discover
    if ($LASTEXITCODE -ne 0) { throw 'Aktueller Client konnte nicht gefunden werden. Bitte den Installer erneut öffnen und den Client auswählen.' }
    $latest = @(($discoveryText | ConvertFrom-Json).candidates | Select-Object -First 1)
    if (!$latest.Count) { throw 'Kein Client gefunden. Bitte die ChatGPT-Desktop-App installieren oder den Client im Installer auswählen.' }
    $cli = [string]$latest[0].path
}
$compatibilityText = & $manager inspect-host --codex $cli
if ($LASTEXITCODE -ne 0) { throw 'Die benötigten Plugin-Funktionen des Clients konnten nicht geprüft werden. Es wurde nichts installiert. Details stehen in der Manager-Ausgabe.' }
}
$compatibility = $compatibilityText | ConvertFrom-Json
$observedVersion = [string]$compatibility.version
$script:compatibilityWarning = [string]$compatibility.warning
foreach ($path in @($manager,$devicePath,(Join-Path $profile 'background.json'))) {
    if (!(Test-Path -LiteralPath $path -PathType Leaf)) { throw ('Einrichtungsdatei fehlt: '+$path) }
}
$device=Get-Content -LiteralPath $devicePath -Raw -Encoding UTF8 | ConvertFrom-Json
if ($device.profileId -ne 'personal' -or $null -ne $device.companyId) { throw 'Dieser Starter ist ausschliesslich fuer das eingerichtete persoenliche Profil vorgesehen.' }
Add-Type -AssemblyName System.Windows.Forms
$script:selectedPlan = Get-MaintenancePlan
if ($ExpectedRevision -gt 0 -and $script:selectedPlan.revision -ne $ExpectedRevision) { throw 'Die angezeigte Freigabe ist noch nicht vollständig bereitgestellt oder hat sich geändert. Bitte den Online-Abgleich abwarten und erneut prüfen.' }
if ($ValidateOnly) { 'Aktualisierung-Starter und signierter Freigabeplan geprueft; keine Wartung ausgefuehrt.'; return }
. (Join-Path $app 'Startmenue.ps1')
Ensure-ManagerStartMenuEntry -InstallRoot $root -ProgramsDirectory $ProgramsDirectory | Out-Null
Add-Type -AssemblyName System.Windows.Forms
# Installation state is captured by the confirmed maintenance plan.
if (!$script:selectedPlan.requiresUpdate) {
    [void][Windows.Forms.MessageBox]::Show('Das vorbereitete Plugin-Update ist bereits installiert. Du kannst die ChatGPT-Desktop-App verwenden. Es ist keine weitere Installation erforderlich.','Plugin bereits aktuell')
    return
}
if (!(Show-MaintenanceReady -PlanSummary (($script:compatibilityWarning + "`r`n" + $script:selectedPlan.summary).Trim()) -Revision $script:selectedPlan.revision -AutoStart:$AutoStart)) { return }
Show-MaintenanceProgress
$originalDevice=$null;$writtenDevice=$null;$stopped=$false;$completed=$false
$failureMessage='';$cleanupMessages=@()
$mutex=New-Object Threading.Mutex($false,'Local\PersonalPluginManager-Update-Personal')
$owned=$false
try {
    try { $owned=$mutex.WaitOne(0) }
    catch [System.Threading.AbandonedMutexException] {
        $owned=$true
        $managerState=Join-Path $profile 'manager-state'
        [IO.Directory]::CreateDirectory($managerState) | Out-Null
        $uncertain=Join-Path $managerState 'manager-owner-uncertain.json'
        if ([IO.Directory]::Exists($uncertain)) {
            throw 'Der Pfad der ungeklärten Manager-Besitzersperre ist belegt.'
        }
        if (-not [IO.File]::Exists($uncertain)) {
            $temporary=$uncertain+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
            try {
                $bytes=[Text.UTF8Encoding]::new($false).GetBytes((@{
                    reason='abandoned-plugin-maintenance-owner'
                    observedAt=[DateTimeOffset]::UtcNow.ToString('o')
                } | ConvertTo-Json -Compress))
                $stream=[IO.FileStream]::new($temporary,[IO.FileMode]::CreateNew,
                    [IO.FileAccess]::Write,[IO.FileShare]::None,4096,[IO.FileOptions]::WriteThrough)
                try { $stream.Write($bytes,0,$bytes.Length);$stream.Flush($true) }
                finally { $stream.Dispose() }
                [IO.File]::Move($temporary,$uncertain)
            } finally {
                if ([IO.File]::Exists($temporary)) { [IO.File]::Delete($temporary) }
            }
        }
        throw 'Eine vorherige Wartung wurde unterbrochen. Erst den Manager-Zustand prüfen.'
    }
    if (!$owned) { throw 'Eine Aktualisierung laeuft bereits.' }
    Check-Closed
    # Installation state is captured by the confirmed maintenance plan.
    Assert-SelectedPlan
    Run-Manager @('stop-watch','--store',$store)
    $deadline=[DateTime]::UtcNow.AddSeconds(20)
    do {
        $state=Get-Content -LiteralPath (Join-Path $store 'background-status.json') -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($state.state -in @('stopped','failed')) { $stopped=$true;break }
        [Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 100
    } while ([DateTime]::UtcNow -lt $deadline)
    if (!$stopped) { throw 'Der Hintergrundabgleich ist noch aktiv. Es wurde keine Installation begonnen.' }
    Check-Closed
    $originalDevice=[IO.File]::ReadAllText($devicePath)
    $device=$originalDevice | ConvertFrom-Json
    if ($device.profileId -ne 'personal' -or $null -ne $device.companyId) { throw 'Geraetezuordnung inzwischen geaendert.' }
    $device.pauseActivation=$false
    $writtenDevice=$device | ConvertTo-Json -Depth 8
    [IO.File]::WriteAllText($devicePath,$writtenDevice,(New-Object Text.UTF8Encoding($false)))
    Sync-Profile
    $base=@('--store',$store,'--client-home',$clientHome,'--codex',$cli,'--maintenance','confirmed')
    if (Test-Path (Join-Path $store 'real-update-pending.json')) {
        Run-Manager (@('recover-update')+$base)
        throw 'Der vorherige Zustand wurde wiederhergestellt. Vor einem neuen Versuch ist die Wartungsablage zu pruefen.'
    }
    $staged = Get-Content -LiteralPath (Join-Path $store 'staged.json') -Raw | ConvertFrom-Json
    Assert-SelectedPlan
    Run-Manager @('prepare-activation','--store',$store)
    $adoption=$null
    $operation=@([string]$script:selectedPlan.operation)+$base
    if ($script:selectedPlan.operation -eq 'install-candidate') {
        Run-Manager (@('adoption-plan')+$base)
        $adoption=$script:lastManagerOutput | ConvertFrom-Json
        if ($adoption.required) {
            if (!$adoption.eligible) { throw $adoption.message }
            Close-MaintenanceProgress
            if (!(Show-AdoptionConfirmation -Summary $adoption.summary)) { return }
            Check-Closed
            Assert-SelectedPlan
            Show-MaintenanceProgress
            $operation=@('adopt-existing')+$base+@('--existing-plugin',$adoption.pluginId,'--confirmation',$adoption.fingerprint)
        }
    }
    try { Run-Manager $operation;$completed=$true }
    catch {
        if (!$script:unresolvedWorker -and (Test-Path (Join-Path $store 'adoption-pending.json'))) {
            Check-Closed
            Run-Manager (@('recover-adoption')+$base+@('--existing-plugin',$adoption.pluginId))
        } elseif (!$script:unresolvedWorker -and (Test-Path (Join-Path $store 'real-installation-pending.json'))) {
            Check-Closed
            Run-Manager (@('recover-initial-install')+$base)
        }
        if (!$script:unresolvedWorker -and (Test-Path (Join-Path $store 'real-update-pending.json'))) {
            Check-Closed
            Run-Manager (@('recover-update')+$base)
        }
        throw
    }
} catch {
    $failureMessage=(New-MaintenanceFailureRecord -Operation execution -Failure $_).message
    Set-MaintenanceProgress 'Vorgang angehalten. Wartungszustand wird geprüft und der Hintergrundabgleich wiederhergestellt …'
} finally {
    try {
        if ($null -ne $originalDevice) {
            try {
                if ([IO.File]::ReadAllText($devicePath) -ceq $writtenDevice) {
                    [IO.File]::WriteAllText($devicePath,$originalDevice,(New-Object Text.UTF8Encoding($false)))
                } else { $cleanupMessages+='Die Geräteeinstellungen wurden inzwischen geändert und deshalb nicht überschrieben.' }
            } catch { $cleanupMessages+=(New-MaintenanceFailureRecord -Operation device-restore -Failure $_).message }
        }
        if ($stopped -and !$script:unresolvedWorker -and !(Test-Path (Join-Path $store 'real-update-pending.json')) -and !(Test-Path (Join-Path $store 'real-installation-pending.json')) -and !(Test-Path (Join-Path $store 'adoption-pending.json'))) {
            try {
                Set-MaintenanceProgress 'Hintergrundabgleich wird wieder gestartet …'
                Sync-Profile
                & (Join-Path $app 'Start-Hintergrund.ps1') -Configuration (Join-Path $profile 'background.json') | Out-Null
            } catch { $cleanupMessages+=(New-MaintenanceFailureRecord -Operation watch-restart -Failure $_).message }
        }
    } finally {
        try { Close-MaintenanceProgress }
        finally {
            try { if ($owned) { $mutex.ReleaseMutex() } }
            finally { $mutex.Dispose() }
        }
    }
}
if ($failureMessage -or $cleanupMessages.Count) {
    $message=(@($failureMessage)+$cleanupMessages | Where-Object {$_}) -join "`r`n`r`n"
    Show-PathMessage -Message $message -Title 'Plugin-Aktualisierung' -FilePath $script:lastErrorLogPath
} elseif ($completed) {
    [void][Windows.Forms.MessageBox]::Show('Plugin-Update erfolgreich installiert und geprüft. Öffne jetzt deinen ChatGPT-/Codex-Client wieder. Visual Studio Code und andere zuvor geschlossene Programme kannst du ebenfalls wieder öffnen.','Plugin-Update abgeschlossen')
}
