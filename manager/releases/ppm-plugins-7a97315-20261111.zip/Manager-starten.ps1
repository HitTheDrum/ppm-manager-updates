﻿$ErrorActionPreference='Stop'
$parent=Split-Path $PSScriptRoot -Parent
$versionedManager=((Split-Path $parent -Leaf) -ceq 'manager-generations' -and
    (Split-Path $PSScriptRoot -Leaf) -cmatch '^[a-f0-9]{32}-[0-9]{12}$')
$root=if ($versionedManager) {
    Split-Path $parent -Parent
} elseif (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'installation.json')) {
    $PSScriptRoot
} else { $parent }
$settings=Get-Content -LiteralPath (Join-Path $root 'installation.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$app=if ($versionedManager) { [IO.Path]::GetFullPath($PSScriptRoot) }
    else { [IO.Path]::GetFullPath([string]$settings.appDirectory) }
$profile=[IO.Path]::GetFullPath([string]$settings.profileDirectory)
foreach ($path in @($app,$profile)) {
 if (!$path.StartsWith(([IO.Path]::GetFullPath($root)+'\'),[StringComparison]::OrdinalIgnoreCase)) { throw 'Die Startzuordnung gehört nicht zu dieser Installation.' }
 for ($part=$path; $part; $part=[IO.Path]::GetDirectoryName($part)) {
  if ((Test-Path -LiteralPath $part) -and ((Get-Item -LiteralPath $part -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Verknüpfte Startpfade sind nicht erlaubt.' }
 }
}
$leasePath=Join-Path $app 'Manager-Work-Lease.ps1'
$lease=if (Test-Path -LiteralPath $leasePath -PathType Leaf) { & $leasePath } else { $null }
if ($versionedManager -and $null -eq $lease) {
    throw 'Die ausgewählte Manager-Generation ist nicht bestätigt.'
}
try {
    & (Join-Path $app 'Start-Hintergrund.ps1') -Configuration (Join-Path $profile 'background.json') | Out-Null
    & (Join-Path $app 'Start-Fenster.ps1') -Store (Join-Path $profile 'store') | Out-Null
} finally { if ($null -ne $lease) { $lease.Dispose() } }
