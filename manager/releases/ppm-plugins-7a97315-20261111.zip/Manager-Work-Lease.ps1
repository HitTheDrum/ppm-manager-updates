﻿# Shared Windows file lease for manager windows with editable or unsaved work.
# The independent selector opens the same file exclusively before switching.
$appDirectory = [IO.Path]::GetFullPath($PSScriptRoot)
$parent = [IO.Path]::GetFullPath((Split-Path $appDirectory -Parent))
$generationId = [IO.Path]::GetFileName($appDirectory)
$versioned = ([IO.Path]::GetFileName($parent) -ceq 'manager-generations' -and
    $generationId -cmatch '^[a-f0-9]{32}-[0-9]{12}$')
$installRoot = if ($versioned) { [IO.Path]::GetFullPath((Split-Path $parent -Parent)) }
    else { $parent }
$installation = Join-Path $installRoot 'installation.json'
$adoptionPending = Join-Path $installRoot 'standalone-self-update-pending.json'
if (Test-Path -LiteralPath $adoptionPending) {
    throw 'Die Uebernahme dieser Installation ist noch nicht abgeschlossen. Bitte den geprueften Installer erneut oeffnen.'
}
if (-not [IO.File]::Exists($installation)) {
    if ($versioned) { throw 'Die ausgewählte Manager-Installation fehlt.' }
    return $null
}
$settings = Get-Content -LiteralPath $installation -Raw -Encoding UTF8 | ConvertFrom-Json
$profileDirectory = [IO.Path]::GetFullPath([string]$settings.profileDirectory)
if (-not $profileDirectory.StartsWith((Join-Path $installRoot 'profiles') + [IO.Path]::DirectorySeparatorChar,
        [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Das Manager-Profil gehört nicht zu dieser Installation.'
}
$state = Join-Path $profileDirectory 'manager-state'
foreach ($candidatePath in @($appDirectory,$installation,$state)) {
    for ($part = $candidatePath; $part; $part = [IO.Path]::GetDirectoryName($part)) {
        if (([IO.File]::Exists($part) -or [IO.Directory]::Exists($part)) -and
            (([IO.File]::GetAttributes($part) -band [IO.FileAttributes]::ReparsePoint) -ne 0)) {
            throw 'Verknüpfte Manager-Pfade sind nicht erlaubt.'
        }
    }
}
$uncertainOwner = Join-Path $state 'manager-owner-uncertain.json'
if ([IO.File]::Exists($uncertainOwner) -or [IO.Directory]::Exists($uncertainOwner)) {
    throw 'Die Manager-Auswahl hat einen ungeklärten Besitzer.'
}
if ($versioned) {
    $pointerPath = Join-Path $state 'current-generation.json'
    $ledgerPath = Join-Path $state 'manager-generation-ledger.json'
    if (-not [IO.File]::Exists($pointerPath) -or -not [IO.File]::Exists($ledgerPath)) {
        throw 'Die Manager-Generation ist nicht bestätigt.'
    }
    foreach ($path in @($pointerPath,$ledgerPath)) {
        $file = Get-Item -LiteralPath $path
        if ($file.Length -le 0 -or $file.Length -gt 1048576 -or
            (($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) {
            throw 'Die Manager-Auswahl ist ungültig.'
        }
    }
    $pointer = Get-Content -LiteralPath $pointerPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $ledger = Get-Content -LiteralPath $ledgerPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($pointer.schemaVersion -ne 1 -or $ledger.schemaVersion -ne 1 -or
        $ledger.installationId -cnotmatch '^[a-f0-9]{32}$' -or
        $pointer.artifactDigest -cnotmatch '^[a-f0-9]{64}$' -or
        $ledger.pending -or $pointer.generationId -cne $generationId -or
        $ledger.confirmedGenerationId -cne $generationId -or
        $pointer.artifactDigest -cne $ledger.confirmedArtifactDigest -or
        $pointer.installationId -cne $ledger.installationId -or
        [long]$pointer.ledgerRevision -ne [long]$ledger.revision) {
        throw 'Dieses Manager-Fenster gehört nicht zur bestätigten Generation.'
    }
} elseif (-not $settings.appDirectory -or
    -not ([IO.Path]::GetFullPath([string]$settings.appDirectory)).Equals(
        $appDirectory, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Dieses Manager-Fenster gehört nicht zur ausgewählten Installation.'
} elseif ([IO.File]::Exists((Join-Path $state 'current-generation.json')) -or
    [IO.Directory]::Exists((Join-Path $state 'current-generation.json')) -or
    [IO.File]::Exists((Join-Path $state 'manager-generation-ledger.json')) -or
    [IO.Directory]::Exists((Join-Path $state 'manager-generation-ledger.json'))) {
    throw 'Der feste Manager-Pfad wurde durch die ausgewählte Generation ersetzt.'
}
[IO.Directory]::CreateDirectory($state) | Out-Null
$leasePath = Join-Path $state '.interactive-work.lock'
if ([IO.File]::Exists($leasePath) -and
    (([IO.File]::GetAttributes($leasePath) -band [IO.FileAttributes]::ReparsePoint) -ne 0)) {
    throw 'Verknüpfte Manager-Fenstersperre ist nicht erlaubt.'
}
return [IO.FileStream]::new($leasePath, [IO.FileMode]::OpenOrCreate,
    [IO.FileAccess]::ReadWrite, [IO.FileShare]::ReadWrite)
