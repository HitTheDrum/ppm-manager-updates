﻿param([Parameter(Mandatory=$true)][string]$Configuration, [switch]$ValidateOnly, [switch]$NoTray)
$ErrorActionPreference = 'Stop'
function Safe-Path([string]$Path) {
    $full = [IO.Path]::GetFullPath($Path)
    if ($full.Contains('"') -or $full.Contains("`r") -or $full.Contains("`n")) { throw 'Ungültiger Pfad.' }
    for ($part = $full; $part; $part = [IO.Path]::GetDirectoryName($part)) {
        if (Test-Path -LiteralPath $part) {
            if (([IO.File]::GetAttributes($part) -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Verknüpfte Pfade sind nicht erlaubt.' }
        }
    }
    return $full
}
$Configuration = Safe-Path $Configuration
$configRoot = [IO.Path]::GetDirectoryName($Configuration)
if ((Get-Item -LiteralPath $Configuration).Length -gt 65536) { throw 'Die Konfigurationsdatei ist zu groß.' }
$config = Get-Content -LiteralPath $Configuration -Raw -Encoding UTF8 | ConvertFrom-Json
if ($config.schemaVersion -ne 1 -or $config.mode -notin @('local','signed','manager-only')) { throw 'Unbekannte Hintergrund-Konfiguration.' }
$allowed = @('schemaVersion','mode','store','catalog','source','trust','intervalSeconds','cycles','maintenance','codex','clientHome','device','company','companyTrust','managerSource','preferencesMode','preferencesSource','preferencesTrust','preferencesPolicySource','preferencesPolicyTrust')
foreach ($property in $config.PSObject.Properties.Name) { if ($property -notin $allowed) { throw 'Unbekanntes Konfigurationsfeld.' } }
function Config-Path([string]$Name) {
    $value = [string]$config.$Name
    if (-not $value) { throw ('Pfad fehlt: ' + $Name) }
    return Safe-Path ([IO.Path]::Combine($configRoot, $value))
}
$store = Config-Path 'store'
$marker = Join-Path $store '.plugin-manager-store'
if (-not (Test-Path -LiteralPath $marker) -or [IO.File]::ReadAllText($marker) -cne 'personal-plugin-manager-v1') { throw 'Eine bereits eingerichtete Manager-Ablage ist erforderlich.' }
$interval = if ($null -ne $config.intervalSeconds) { [int]$config.intervalSeconds } else { 900 }
$cycles = if ($null -ne $config.cycles) { [int]$config.cycles } else { 0 }
if ($interval -lt 5 -or $interval -gt 86400 -or $cycles -lt 0) { throw 'Ungültiges Prüfintervall.' }
$manager = Safe-Path (Join-Path $PSScriptRoot 'out\PluginManager.exe')
if (-not (Test-Path -LiteralPath $manager)) { throw 'Das gebaute Programm fehlt.' }
$managerSourceArguments = $null
$managerSourceStore = $null
if ($config.mode -eq 'manager-only' -and $null -eq $config.managerSource) {
    throw 'Ein Manager ohne Plugin-Profil benötigt eine Updatequelle.'
}
if ($null -ne $config.managerSource) {
    $managerSource = $config.managerSource
    $managerSourceFields = @('branch','store','trust','bootstrapVersion')
    if ($config.mode -eq 'manager-only') {
        $managerSourceFields += @('owner','repository','credentialTarget')
        if ($managerSource.owner -cne 'HitTheDrum' -or
            $managerSource.repository -cne 'ppm-manager-updates' -or
            $null -ne $managerSource.credentialTarget) {
            throw 'Die öffentliche Manager-Quelle weicht vom Installer ab.'
        }
    }
    foreach ($property in $managerSource.PSObject.Properties.Name) {
        if ($property -notin $managerSourceFields) {
            throw 'Unbekanntes Manager-Quellenfeld.'
        }
    }
    $branch = [string]$managerSource.branch
    if (-not $branch -or $branch -notmatch '^[A-Za-z0-9][A-Za-z0-9._/-]{0,199}$' -or
        $branch.Contains('..') -or $branch.StartsWith('refs/') -or
        $branch.EndsWith('/') -or $branch.Contains('//')) {
        throw 'Ungültiger Manager-Quellenzweig.'
    }
    if (-not $managerSource.store -or -not $managerSource.trust -or
        $null -eq $managerSource.bootstrapVersion -or
        [int]$managerSource.bootstrapVersion -lt 1) {
        throw 'Manager-Quelle benötigt getrennte Ablage, Trust und Bootstrap-Version.'
    }
    $managerSourceStore = Safe-Path ([IO.Path]::Combine($configRoot, [string]$managerSource.store))
    $managerInstallRoot = $null
    if ([string]$managerSource.trust -ceq 'bootstrap') {
        $managerInstallRoot = Safe-Path (Join-Path $configRoot '..\..')
        $managerTrust = Safe-Path (Join-Path $managerInstallRoot 'bootstrap\manager-trust.json')
    } else {
        $managerTrust = Safe-Path ([IO.Path]::Combine($configRoot, [string]$managerSource.trust))
    }
    if ($managerSourceStore.Equals($store, [StringComparison]::OrdinalIgnoreCase) -or
        $managerSourceStore.StartsWith($store + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase) -or
        $store.StartsWith($managerSourceStore + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase) -or
        -not (Test-Path -LiteralPath $managerTrust -PathType Leaf)) {
        throw 'Manager-Quellenablage und Trust müssen getrennt und vorhanden sein.'
    }
    $managerSourceArguments = @('watch-manager-source','--source-branch',$branch,
        '--store',$managerSourceStore,'--trust',$managerTrust,
        '--bootstrap-version',[string][int]$managerSource.bootstrapVersion)
    if ($managerInstallRoot) { $managerSourceArguments += @('--install-root',$managerInstallRoot) }
}
$arguments = @('--store',$store,'--interval-seconds',[string]$interval,'--cycles',[string]$cycles)
if ($config.mode -eq 'signed') {
    $source = Config-Path 'source'; $trust = Config-Path 'trust'
    if (-not (Test-Path -LiteralPath $source) -or -not (Test-Path -LiteralPath $trust)) { throw 'Quelle oder Vertrauensdatei fehlt.' }
    $arguments = @('watch-signed') + $arguments + @('--source',$source,'--trust',$trust)
} elseif ($config.mode -eq 'local') {
    $catalog = Config-Path 'catalog'
    if (-not (Test-Path -LiteralPath $catalog)) { throw 'Der lokale Katalog fehlt.' }
    $arguments = @('watch') + $arguments + @('--catalog',$catalog)
} else {
    $arguments = $managerSourceArguments
}
$managed = ($config.maintenance -eq 'when-closed')
if ($config.maintenance -and $config.maintenance -notin @('disabled','when-closed')) { throw 'Unbekannte Wartungseinstellung.' }
if ($managed) {
    if ($config.mode -ne 'signed') { throw 'Automatische Wartung benötigt signierte Freigaben.' }
    $cli = Config-Path 'codex'; $clientHome = Config-Path 'clientHome'
    if (-not (Test-Path -LiteralPath $cli -PathType Leaf) -or -not (Test-Path -LiteralPath $clientHome -PathType Container) -or $clientHome -eq $store) { throw 'CLI und getrenntes Clientprofil müssen vorhanden sein.' }
    $arguments[0] = 'watch-managed'
    $arguments += @('--codex',$cli,'--client-home',$clientHome,'--maintenance','when-closed')
    if ($managerInstallRoot) { $arguments += @('--manager-install-root',$managerInstallRoot) }
}
foreach ($binding in @(@('device','device'),@('company','company'),@('companyTrust','company-trust'))) {
    if ($config.($binding[0])) {
        if ($config.mode -ne 'signed') { throw 'Firmen- und Gerätezuordnung benötigen den signierten Abgleich.' }
        $arguments += @(('--'+$binding[1]),(Config-Path $binding[0]))
    }
}
$preferenceFields = @('preferencesMode','preferencesSource','preferencesTrust','preferencesPolicySource','preferencesPolicyTrust')
if (@($config.PSObject.Properties.Name | Where-Object { $_ -in $preferenceFields }).Count -gt 0) {
    if ($config.mode -ne 'signed') { throw 'Einstellungsquellen benötigen den signierten Abgleich.' }
    $hasPersonal = @($config.PSObject.Properties.Name | Where-Object { $_ -in @('preferencesMode','preferencesSource','preferencesTrust') }).Count -gt 0
    if ($hasPersonal) {
        if ($config.preferencesMode -notin @('review-only','apply-compatible')) { throw 'Persönliche Einstellungen benötigen einen expliziten Gerätemodus.' }
        $preferenceSource=Config-Path 'preferencesSource'; $preferenceTrust=Config-Path 'preferencesTrust'
        if (!(Test-Path -LiteralPath $preferenceSource -PathType Leaf) -or !(Test-Path -LiteralPath $preferenceTrust -PathType Leaf)) { throw 'Konfigurationsquelle oder Vertrauensdatei fehlt.' }
        $arguments+=@('--preferences-mode',[string]$config.preferencesMode,'--preferences-source',$preferenceSource,'--preferences-trust',$preferenceTrust)
    }
    if ('preferencesPolicySource' -in $config.PSObject.Properties.Name -or 'preferencesPolicyTrust' -in $config.PSObject.Properties.Name) {
        $policySource=Config-Path 'preferencesPolicySource'; $policyTrust=Config-Path 'preferencesPolicyTrust'
        if (!(Test-Path -LiteralPath $policySource -PathType Leaf) -or !(Test-Path -LiteralPath $policyTrust -PathType Leaf)) { throw 'Firmen-Konfigurationsquelle oder Vertrauensdatei fehlt.' }
        $arguments+=@('--preferences-policy-source',$policySource,'--preferences-policy-trust',$policyTrust)
    }
}
$sha = [Security.Cryptography.SHA256]::Create()
try { $identity = [BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($store.ToUpperInvariant()))).Replace('-','').Substring(0,24) } finally { $sha.Dispose() }
$installedRoot=Safe-Path (Join-Path $configRoot '..\..')
$managedLedger=Safe-Path (Join-Path $configRoot 'manager-state\manager-generation-ledger.json')
if ([IO.File]::Exists($managedLedger)) {
    $appParent=Split-Path $PSScriptRoot -Parent
    $versionedStart=((Split-Path $appParent -Leaf) -ceq 'manager-generations')
    if ($versionedStart) {
        # An obsolete or pending generation must not use this forwarding route.
        $checkLease=& (Join-Path $PSScriptRoot 'Manager-Work-Lease.ps1')
        if ($checkLease) {$checkLease.Dispose()}
        $scriptRoot=Split-Path $appParent -Parent
    } else {
        $scriptRoot=$appParent
        $startSettings=Get-Content -LiteralPath (Safe-Path (Join-Path $installedRoot 'installation.json')) -Raw -Encoding UTF8|ConvertFrom-Json
        if ((Safe-Path ([string]$startSettings.appDirectory)) -ine (Safe-Path $PSScriptRoot) -or
            (Safe-Path ([string]$startSettings.profileDirectory)) -ine $configRoot) {
            throw 'Dieser Hintergrundstarter gehört nicht zur ausgewählten Installation.'
        }
    }
    if ((Safe-Path $scriptRoot) -ine $installedRoot) {throw 'Die Manager-Startzuordnung stimmt nicht überein.'}
    $stableEntry=Safe-Path (Join-Path $installedRoot 'bootstrap\ManagerUpdatesLauncher.exe')
    $stableBackground=Safe-Path (Join-Path $installedRoot 'bootstrap\Manager-Background.ps1')
    if (-not [IO.File]::Exists($stableEntry) -or -not [IO.File]::Exists($stableBackground)) {
        throw 'Der unabhängige Hintergrundstarter fehlt. Bitte den geprüften Übergangsinstaller ausführen.'
    }
    if ($ValidateOnly) {
        'Hintergrund-Konfiguration geprüft; kein Prozess und kein Autostart eingerichtet.'
        return
    }
    $start=New-Object Diagnostics.ProcessStartInfo
    # This verified GUI executable must not inherit the redirected output handles
    # of BackgroundLauncher's short-lived PowerShell child. Otherwise that outer
    # launcher waits for EOF until the independent observer itself exits.
    $start.FileName=$stableEntry;$start.UseShellExecute=$true;$start.WindowStyle='Hidden'
    $start.Arguments=if($NoTray){'--background-no-tray'}else{'--background'}
    $forwarded=[Diagnostics.Process]::Start($start)
    if (-not $forwarded) {throw 'Der unabhängige Hintergrundstart konnte nicht angefordert werden.'}
    $forwarded.Dispose()
    return
}
if ($ValidateOnly) {
    $validationLease = & (Join-Path $PSScriptRoot 'Manager-Work-Lease.ps1')
    try { 'Hintergrund-Konfiguration geprüft; kein Prozess und kein Autostart eingerichtet.' }
    finally { if ($validationLease) { $validationLease.Dispose() } }
    return
}
$script:managerWorkLease = & (Join-Path $PSScriptRoot 'Manager-Work-Lease.ps1')
$runtimeOwnerPath = Safe-Path (Join-Path $configRoot 'manager-state\.manager-runtime-owner.lock')
[IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($runtimeOwnerPath)) | Out-Null
try {
    $runtimeOwnerLease = [IO.File]::Open($runtimeOwnerPath, [IO.FileMode]::OpenOrCreate,
        [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
} catch [IO.IOException] {
    throw 'Ein bestätigter Managerprozess besitzt bereits den Hintergrundbetrieb.'
}
$mutex = New-Object Threading.Mutex($false, ('Local\PersonalPlugins-' + $identity))
$owned = $false
$worker = $null
$managerSourceWorker = $null
$tray = $null
$trayIcon = $null
$stopRequested = $false
$supervisorFailed = $false
$statusPath = Safe-Path (Join-Path $store 'background-status.json')
function Save-Status([string]$State) {
    if (-not ('PersonalPlugins.BackgroundStatusWriter' -as [type])) {
        Add-Type @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
namespace PersonalPlugins {
    public static class BackgroundStatusWriter {
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool MoveFileEx(string existing, string replacement, uint flags);
        public static void Publish(string temporary, string destination) {
            if (!MoveFileEx(temporary, destination, 1))
                throw new Win32Exception(Marshal.GetLastWin32Error());
        }
    }
}
'@
    }
    $temporary = Safe-Path ($statusPath + '.' + [guid]::NewGuid().ToString('N') + '.tmp')
    $value = @{state=$State;updatedAt=[DateTime]::UtcNow.ToString('o');supervisorId=$PID;workerId=$worker.Id;workerStartedAt=$worker.StartTime.ToUniversalTime().ToString('o');mode=$config.mode;installationAutomatic=$managed;managerSourceEnabled=($null -ne $managerSourceArguments);managerSourceWorkerId=$(if ($managerSourceWorker) { $managerSourceWorker.Id } else { $null })}
    [IO.File]::WriteAllText($temporary, ($value | ConvertTo-Json), (New-Object Text.UTF8Encoding($false)))
    # Windows readers may briefly deny deletion (including ERROR_ACCESS_DENIED).
    # Never delete the last snapshot first; permanent denial still fails boundedly.
    try {
        for ($attempt = 0; ; $attempt++) {
            try {
                [PersonalPlugins.BackgroundStatusWriter]::Publish($temporary, $statusPath)
                break
            } catch {
                $failure = $_.Exception
                while ($failure.InnerException) { $failure = $failure.InnerException }
                if ($failure -isnot [ComponentModel.Win32Exception] -or $failure.NativeErrorCode -notin @(5,32,33) -or $attempt -ge 10) { throw }
                Start-Sleep -Milliseconds 50
            }
        }
    } finally {
        if ([IO.File]::Exists($temporary)) { [IO.File]::Delete($temporary) }
    }
}
function Request-Stop {
    if ($script:stopRequested) { return }
    if ($config.mode -eq 'manager-only') {
        $script:stopRequested = $true
        Request-ManagerSourceStop
        Save-Status 'stopping'
        return
    }
    # This is the same local signal used by stop-watch; no client process is terminated.
    $path = Safe-Path (Join-Path $store '.stop-watch.json')
    [IO.File]::WriteAllText($path, '{"requestedBy":"windows-background"}')
    $script:stopRequested = $true
    Save-Status 'stopping'
    if ($tray) { $tray.Text = 'Plugin-Verwaltung: wird beendet' }
}
function Request-ManagerSourceStop {
    $sourceWorker = if ($config.mode -eq 'manager-only') { $worker } else { $managerSourceWorker }
    if (-not $sourceWorker -or $sourceWorker.HasExited) { return }
    try { & $manager stop-manager-source --store $managerSourceStore | Out-Null } catch { }
}
try {
    try { $owned = $mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $owned = $true }
    if (-not $owned) { return }
    # Detect an already-running standalone watch before creating a second worker.
    if ($config.mode -ne 'manager-only') {
        $lock = [IO.File]::Open((Safe-Path (Join-Path $store '.writer.lock')), 'OpenOrCreate', 'ReadWrite', 'None')
        $lock.Dispose()
    }
    $start = New-Object Diagnostics.ProcessStartInfo
    $start.FileName = $manager; $start.UseShellExecute = $false; $start.CreateNoWindow = $true
    $start.WorkingDirectory = $PSScriptRoot
    $start.Arguments = ($arguments | ForEach-Object { '"' + $_ + '"' }) -join ' '
    $worker = [Diagnostics.Process]::Start($start)
    if ($managerSourceArguments -and $config.mode -ne 'manager-only') {
        $managerStart = New-Object Diagnostics.ProcessStartInfo
        $managerStart.FileName = $manager
        $managerStart.UseShellExecute = $false
        $managerStart.CreateNoWindow = $true
        $managerStart.WorkingDirectory = $PSScriptRoot
        $managerStart.Arguments = ($managerSourceArguments | ForEach-Object { '"' + $_ + '"' }) -join ' '
        $managerSourceWorker = [Diagnostics.Process]::Start($managerStart)
    }
    Save-Status 'starting'
    if (-not $NoTray) {
        Add-Type -AssemblyName System.Windows.Forms
        Add-Type -AssemblyName System.Drawing
        $tray = New-Object Windows.Forms.NotifyIcon
        $iconPath = Join-Path $PSScriptRoot 'assets\plugin-manager.ico'
        if (Test-Path -LiteralPath $iconPath) {
            $trayIcon = New-Object Drawing.Icon($iconPath,([Windows.Forms.SystemInformation]::SmallIconSize))
            $tray.Icon = $trayIcon
        } else { $tray.Icon = [Drawing.SystemIcons]::Application }
        $tray.Text = 'Plugin-Verwaltung: Abgleich läuft'
        $menu = New-Object Windows.Forms.ContextMenuStrip
        $info = $menu.Items.Add('Freigaben werden bereitgestellt'); $info.Enabled = $false
        $open = $menu.Items.Add('Plugin-Übersicht öffnen')
        $open.Add_Click({
            try { & (Join-Path $PSScriptRoot 'Start-Fenster.ps1') -Store $store | Out-Null }
            catch { [Windows.Forms.MessageBox]::Show('Die Plugin-Übersicht konnte nicht starten. Bitte die Manager-Installation prüfen.', 'Plugin-Übersicht konnte nicht starten') | Out-Null }
        })
        $stableRoot = Safe-Path (Join-Path $configRoot '..\..')
        $stableUpdates = Safe-Path (Join-Path $stableRoot 'bootstrap\ManagerUpdatesLauncher.exe')
        if (Test-Path -LiteralPath $stableUpdates -PathType Leaf) {
            $openUpdates = $menu.Items.Add('Manager-Updates öffnen')
            $openUpdates.Add_Click({
                try {
                    $launch = New-Object Diagnostics.ProcessStartInfo
                    $launch.FileName = $stableUpdates
                    $launch.UseShellExecute = $true
                    $launch.WindowStyle = [Diagnostics.ProcessWindowStyle]::Normal
                    $process = [Diagnostics.Process]::Start($launch)
                    if ($null -eq $process) { throw 'Manager-Updates konnte nicht geöffnet werden.' }
                    $process.Dispose()
                } catch {
                    [Windows.Forms.MessageBox]::Show('Manager-Updates konnte nicht starten. Bitte die Installation prüfen.',
                        'Manager-Updates konnte nicht starten') | Out-Null
                }
            })
        }
        $autostart = $menu.Items.Add('Bei Windows-Anmeldung starten')
        $autostart.CheckOnClick = $false
        $autostart.Enabled = ($cycles -eq 0)
        $runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
        $runName = 'PersonalPlugins-' + $identity
        $launcher=Safe-Path (Join-Path $PSScriptRoot 'out\BackgroundLauncher.exe')
        if (!(Test-Path -LiteralPath $launcher)) {throw 'Das Hintergrund-Startprogramm fehlt. Bitte den Manager aktualisieren.'}
        $startupCommand = '"' + $launcher + '" "' + $Configuration + '"'
        $legacyStartupCommand = 'powershell.exe -NoProfile -STA -WindowStyle Hidden -File "' + (Safe-Path $PSCommandPath) + '" -Configuration "' + $Configuration + '"'
        function Read-Autostart {
            $key = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Software\Microsoft\Windows\CurrentVersion\Run')
            if ($null -eq $key) { return $null }
            try { return $key.GetValue($runName, $null) } finally { $key.Dispose() }
        }
        function Test-OwnedAutostart([string]$Command) {
            if ($Command -eq $startupCommand -or $Command -eq $legacyStartupCommand) { return $true }
            # An app-directory update can leave the native Windows Run entry at
            # the previous version (a packaged setup caller may see another HKCU).
            # Only the active installation may migrate its own profile's entry.
            try {
                if ($Command -notmatch '^"([^"\r\n]+)" "([^"\r\n]+)"$') { return $false }
                $previousLauncher = Safe-Path $Matches[1]
                $previousConfiguration = Safe-Path $Matches[2]
                if ($previousConfiguration -ne $Configuration) { return $false }
                $installationRoot = [IO.Path]::GetDirectoryName($PSScriptRoot)
                $installationPath = Safe-Path (Join-Path $installationRoot 'installation.json')
                $installation = Get-Content -LiteralPath $installationPath -Raw -Encoding UTF8 | ConvertFrom-Json
                if ($installation.schemaVersion -ne 1 -or
                    (Safe-Path $installation.appDirectory) -ne $PSScriptRoot -or
                    (Safe-Path (Join-Path $installation.profileDirectory 'background.json')) -ne $Configuration) { return $false }
                $previousOut = [IO.Path]::GetDirectoryName($previousLauncher)
                $previousApp = [IO.Path]::GetDirectoryName($previousOut)
                if ([IO.Path]::GetFileName($previousLauncher) -ne 'BackgroundLauncher.exe' -or
                    [IO.Path]::GetFileName($previousOut) -ne 'out' -or
                    [IO.Path]::GetDirectoryName($previousApp) -ne $installationRoot -or
                    [IO.Path]::GetFileName($previousApp) -notmatch '^app(?:-.+)?$') { return $false }
                foreach ($ownedFile in @($previousLauncher, (Join-Path $previousApp 'Hintergrund.ps1'), (Join-Path $previousOut 'PluginManager.exe'))) {
                    if (!(Test-Path -LiteralPath (Safe-Path $ownedFile) -PathType Leaf)) { return $false }
                }
                return $true
            } catch { return $false }
        }
        $existing = Read-Autostart
        # Both accepted commands contain fixed switches and Windows file paths.
        # Path casing does not identify another installation or profile.
        if ($existing -and $existing -ne $startupCommand -and (Test-OwnedAutostart $existing)) {
            New-ItemProperty -LiteralPath $runKey -Name $runName -Value $startupCommand -PropertyType String -Force | Out-Null
            $existing=$startupCommand
        }
        $autostart.Checked = ($existing -eq $startupCommand)
        $autostart.Add_Click({
            try {
                $current = Read-Autostart
                if ($current -and !(Test-OwnedAutostart $current)) { throw 'Ein anderer Autostart-Eintrag belegt diesen Namen.' }
                if ($current) { Remove-ItemProperty -LiteralPath $runKey -Name $runName; $autostart.Checked = $false }
                else { if (-not (Test-Path -LiteralPath $runKey)) { New-Item -Path $runKey -Force | Out-Null }; New-ItemProperty -LiteralPath $runKey -Name $runName -Value $startupCommand -PropertyType String -Force | Out-Null; $autostart.Checked = $true }
            } catch { [Windows.Forms.MessageBox]::Show('Die Autostart-Einstellung konnte nicht geändert werden. Bitte den bestehenden Windows-Eintrag prüfen.', 'Autostart') | Out-Null }
        })
        $stop = $menu.Items.Add('Abgleich beenden'); $stop.Add_Click({ Request-Stop; Request-ManagerSourceStop })
        $tray.ContextMenuStrip = $menu; $tray.Visible = $true
    }
    . (Join-Path $PSScriptRoot 'Online-Tray.ps1')
    . (Join-Path $PSScriptRoot 'Manager-Tray.ps1')
    Save-Status 'running'
    while (-not $worker.HasExited) {
        if ($managerSourceWorker -and $managerSourceWorker.HasExited) {
            $supervisorFailed = $true
            Request-Stop
            break
        }
        if ($script:stopRequested) {
            # Repeat until acknowledged so a stop requested during worker startup is not lost.
            if ($config.mode -ne 'manager-only') {
                [IO.File]::WriteAllText((Safe-Path (Join-Path $store '.stop-watch.json')), '{"requestedBy":"windows-background"}')
            }
            Request-ManagerSourceStop
        }
        if ($tray) {
            $journalPath = Safe-Path (Join-Path $store 'journal.jsonl')
            if (Test-Path -LiteralPath $journalPath) {
                try {
                    $recent = Get-Content -LiteralPath $journalPath -Tail 1 -Encoding UTF8 | ConvertFrom-Json
                    if ($recent.action -match 'failed') { $info.Text = 'Abgleich fehlgeschlagen; bisheriger Stand bleibt erhalten' }
                    elseif ($recent.action -in @('staged','signature-verified')) { $info.Text = 'Letzter Abgleich erfolgreich; Pakete bereitgestellt' }
                } catch { $info.Text = 'Abgleich läuft; Ergebnis wird aktualisiert' }
            }
            if ($managed) {
                try {
                    $maintenance = Get-Content -LiteralPath (Safe-Path (Join-Path $store 'maintenance-state.json')) -Raw -Encoding UTF8 | ConvertFrom-Json
                    $info.Text = switch ($maintenance.state) {
                        'waiting-for-closed-client' { 'Update wartet auf geschlossene Clients' }
                        'applying' { 'Freigegebene Plugins werden installiert' }
                        'installed-awaiting-client-activation' { 'Installiert; Aktivierung beim nächsten Clientstart prüfen' }
                        'needs-recovery' { 'Wiederherstellung erforderlich; Installation angehalten' }
                        'needs-attention' { 'Prüfung erforderlich; Installation angehalten' }
                        'manager-policy-deadline-blocked' { 'Manager-Frist erreicht; neue Plugin-Wartung pausiert. Geprüftes Manager-Update erforderlich' }
                        'manager-policy-time-uncertain' { 'Manager-Frist zeitlich unklar; neue Plugin-Wartung pausiert' }
                        'manager-policy-authority-unavailable' { 'Manager-Richtlinie unvollständig; neue Plugin-Wartung pausiert' }
                        default { 'Abgleich blockiert oder Quelle nicht erreichbar' }
                    }
                } catch { $info.Text = 'Wartungszustand noch nicht verfügbar' }
            }
            [Windows.Forms.Application]::DoEvents()
        }
        Update-OnlineTray
        Update-ManagerTray
        Start-Sleep -Milliseconds 250
    }
    if ($managerSourceWorker -and -not $managerSourceWorker.HasExited) {
        $until = [DateTime]::UtcNow.AddSeconds(40)
        while (-not $managerSourceWorker.HasExited -and [DateTime]::UtcNow -lt $until) {
            Request-ManagerSourceStop
            Start-Sleep -Milliseconds 250
        }
    }
    if ($worker.ExitCode -eq 0 -and -not $supervisorFailed -and
        (-not $managerSourceWorker -or
            ($managerSourceWorker.HasExited -and $managerSourceWorker.ExitCode -eq 0))) {
        Save-Status 'stopped'
    } else { Save-Status 'failed' }
} catch {
    $supervisorFailed = $true
    throw
} finally {
    if ($worker -and -not $worker.HasExited) {
        try {
            Request-Stop
            $until = [DateTime]::UtcNow.AddSeconds(15)
            while (-not $worker.HasExited -and [DateTime]::UtcNow -lt $until) {
                if ($config.mode -ne 'manager-only') {
                    [IO.File]::WriteAllText((Safe-Path (Join-Path $store '.stop-watch.json')), '{"requestedBy":"windows-background"}')
                }
                Start-Sleep -Milliseconds 200
            }
        } catch { }
    }
    if ($managerSourceWorker -and -not $managerSourceWorker.HasExited) {
        $until = [DateTime]::UtcNow.AddSeconds(40)
        while (-not $managerSourceWorker.HasExited -and [DateTime]::UtcNow -lt $until) {
            Request-ManagerSourceStop
            Start-Sleep -Milliseconds 250
        }
        if (-not $managerSourceWorker.HasExited) {
            try { Save-Status 'failed' } catch { }
        }
    }
    if ($worker -and $supervisorFailed) { try { Save-Status 'failed' } catch { } }
    if ($worker) { $worker.Dispose() }
    if ($managerSourceWorker) { $managerSourceWorker.Dispose() }
    if ($script:managerAttentionProcess) {
        # This observer has no update authority; allow its bounded query to finish.
        $null=$script:managerAttentionProcess.WaitForExit(3000)
        $script:managerAttentionProcess.Dispose()
    }
    if ($tray) { $tray.Visible = $false; $tray.Dispose() }
    if ($trayIcon) { $trayIcon.Dispose() }
    if ($alertIcon) { $alertIcon.Dispose() }
    if ($script:observer) { $script:observer.Dispose() }
    if ($script:managerWorkLease) { $script:managerWorkLease.Dispose() }
    if ($owned) { $mutex.ReleaseMutex() }
    $mutex.Dispose()
    $runtimeOwnerLease.Dispose()
}
