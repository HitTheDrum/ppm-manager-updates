﻿param([string]$Store, [switch]$ValidateOnly, [switch]$Company, [switch]$Move, [switch]$Disconnect, [switch]$Rotate)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
$Store=[IO.Path]::GetFullPath($Store)
$profile=[IO.Path]::GetDirectoryName($Store)
$manager=Join-Path $PSScriptRoot 'out\PluginManager.exe'
$script:isMove=[bool]$Move; $script:isCompany=[bool]$Company; $script:isDisconnect=[bool]$Disconnect; $script:isRotate=[bool]$Rotate
$selectedModes=@($Move,$Company,$Disconnect,$Rotate) | Where-Object { $_ }
if (@($selectedModes).Count -gt 1) { throw 'Nur ein Geräteablauf kann zugleich geöffnet werden.' }
if ($Move -or $Disconnect -or $Rotate) {
    $statePath=Join-Path $Store 'preferences-state.json'
    if (!(Test-Path -LiteralPath $statePath -PathType Leaf)) { throw 'Dieses Gerät hat noch keine gebundene persönliche Quelle.' }
    $boundState=Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json
}
$script:devicePlan=$null; $script:process=$null; $script:restartNeeded=$false
$form=New-Object Windows.Forms.Form
$form.Text=if ($Company) { 'Firmenregeln auf diesem Gerät einrichten' }
    elseif ($Move) { 'Persönliche Quelle wechseln' }
    elseif ($Rotate) { 'Persönlichen Prüfschlüssel wechseln' }
    elseif ($Disconnect) { 'Persönliche Quellenverbindung trennen' }
    else { 'Persönliche Einstellungen auf diesem Gerät einrichten' }
$form.Size=New-Object Drawing.Size(850,570); $form.MinimumSize=New-Object Drawing.Size(700,500)
$form.StartPosition='CenterScreen'; $form.Font=New-Object Drawing.Font('Segoe UI',11)
$layout=New-Object Windows.Forms.TableLayoutPanel
$layout.Dock='Fill'; $layout.Padding=New-Object Windows.Forms.Padding(18)
$layout.ColumnCount=1; $layout.RowCount=8
foreach ($height in @(65,35,42,35,42,55,0,55)) {
    $style=if ($height -eq 0) { New-Object Windows.Forms.RowStyle('Percent',100) }
        else { New-Object Windows.Forms.RowStyle('Absolute',$height) }
    $layout.RowStyles.Add($style) | Out-Null
}
$form.Controls.Add($layout)
$intro=New-Object Windows.Forms.Label; $intro.Dock='Fill'
$intro.Text=if ($Company) { 'Dieses Gerät liest nur die ausdrücklich gewählte signierte Firmenregel. Das persönliche Profil und bestehende Zugänge bleiben getrennt.' }
    elseif ($Move) { 'Nur die persönliche Quelle wird gewechselt. Profil, Prüfschlüssel und bereits verwendete Revision bleiben gebunden. Der neue Ort muss eine passende signierte Freigabe liefern.' }
    elseif ($Rotate) { 'Der neue Prüfschlüssel braucht eine höhere signierte Profilrevision und eine befristete Übergabe mit dem bisherigen Schlüssel. Bereits angewendete Werte bleiben erhalten.' }
    elseif ($Disconnect) { 'Dieses Gerät soll keine neuen persönlichen Profilrevisionen mehr automatisch beziehen. Bereits geprüfte Werte bleiben lokal nutzbar; gebundene Firmenregeln laufen weiter.' }
    else { 'Dieses Gerät liest nur die ausdrücklich gewählte signierte Profilfreigabe. Zugänge und Berechtigungen werden dadurch nicht eingerichtet.' }
$layout.Controls.Add($intro,0,0)
$sourceLabel=New-Object Windows.Forms.Label; $sourceLabel.Text=if ($Company) { 'Firmenquelle' } elseif ($Move -or $Rotate) { 'Neue persönliche Quelle' } elseif ($Disconnect) { 'Derzeitige persönliche Quelle' } else { 'Persönliche Quelle' }; $sourceLabel.Dock='Fill'
$layout.Controls.Add($sourceLabel,0,1)
$sourceRow=New-Object Windows.Forms.TableLayoutPanel; $sourceRow.Dock='Fill'; $sourceRow.ColumnCount=2
$sourceRow.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',85))) | Out-Null
$sourceRow.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',15))) | Out-Null
$source=New-Object Windows.Forms.TextBox; $source.Dock='Fill'; $source.AccessibleName=$sourceLabel.Text
$source.Text=if ($Move -or $Rotate) { '' } elseif ($Disconnect) { $boundState.sourcePath } elseif ($Company) {
    $existing=Join-Path $profile 'preferences-policy-source.json'
    if (Test-Path -LiteralPath $existing) { $existing } else { '' }
} else { Join-Path $profile 'preferences-source-template.json' }
$sourceBrowse=New-Object Windows.Forms.Button; $sourceBrowse.Text='Auswählen'; $sourceBrowse.Dock='Fill'
$sourceRow.Controls.Add($source,0,0); $sourceRow.Controls.Add($sourceBrowse,1,0)
$layout.Controls.Add($sourceRow,0,2)
$trustLabel=New-Object Windows.Forms.Label; $trustLabel.Text=if ($Move -or $Disconnect) { 'Gebundener Prüfschlüssel (bleibt unverändert)' } elseif ($Rotate) { 'Neue öffentliche Prüfschlüsseldatei' } else { 'Öffentlicher Prüfschlüssel' }; $trustLabel.Dock='Fill'
$layout.Controls.Add($trustLabel,0,3)
$trustRow=New-Object Windows.Forms.TableLayoutPanel; $trustRow.Dock='Fill'; $trustRow.ColumnCount=2
$trustRow.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',85))) | Out-Null
$trustRow.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',15))) | Out-Null
$trust=New-Object Windows.Forms.TextBox; $trust.Dock='Fill'; $trust.AccessibleName='Öffentlicher Prüfschlüssel'
$trust.Text=if ($Rotate) { '' } elseif ($Move -or $Disconnect) { $boundState.trustPath } elseif ($Company) {
    $existing=Join-Path $profile 'preferences-policy-trust.json'
    if (Test-Path -LiteralPath $existing) { $existing } else { '' }
} else { Join-Path $profile 'preferences-trust-template.json' }
$trustBrowse=New-Object Windows.Forms.Button; $trustBrowse.Text='Auswählen'; $trustBrowse.Dock='Fill'
$trustRow.Controls.Add($trust,0,0); $trustRow.Controls.Add($trustBrowse,1,0)
$layout.Controls.Add($trustRow,0,4)
$modeRow=New-Object Windows.Forms.FlowLayoutPanel; $modeRow.Dock='Fill'
$modeLabel=New-Object Windows.Forms.Label; $modeLabel.Text='Nach Prüfung neuer Revisionen:'; $modeLabel.AutoSize=$true
$mode=New-Object Windows.Forms.ComboBox; $mode.DropDownStyle='DropDownList'; $mode.Width=360
$mode.AccessibleName='Übernahme neuer Revisionen'
$mode.Items.AddRange(@('Erst anzeigen und selbst übernehmen','Kompatible Revisionen automatisch übernehmen'))
$mode.SelectedIndex=0
$modeRow.Controls.Add($modeLabel); $modeRow.Controls.Add($mode)
$modeRow.Visible=!$Company -and !$Move -and !$Disconnect -and !$Rotate
$optionHost=New-Object Windows.Forms.Panel; $optionHost.Dock='Fill'
$optionHost.Controls.Add($modeRow)
$handoverRow=New-Object Windows.Forms.TableLayoutPanel; $handoverRow.Dock='Fill'; $handoverRow.ColumnCount=3
$handoverRow.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Absolute',175))) | Out-Null
$handoverRow.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',85))) | Out-Null
$handoverRow.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',15))) | Out-Null
$handoverLabel=New-Object Windows.Forms.Label; $handoverLabel.Text='Signierte Übergabe'; $handoverLabel.Dock='Fill'
$handover=New-Object Windows.Forms.TextBox; $handover.Dock='Fill'; $handover.AccessibleName='Signierte Schlüsselübergabe'
$handoverBrowse=New-Object Windows.Forms.Button; $handoverBrowse.Text='Auswählen'; $handoverBrowse.Dock='Fill'
$handoverRow.Controls.Add($handoverLabel,0,0); $handoverRow.Controls.Add($handover,1,0); $handoverRow.Controls.Add($handoverBrowse,2,0)
$handoverRow.Visible=[bool]$Rotate; $optionHost.Controls.Add($handoverRow); $handoverRow.BringToFront()
$layout.Controls.Add($optionHost,0,5)
$summary=New-Object Windows.Forms.TextBox; $summary.Dock='Fill'; $summary.Multiline=$true
$summary.ReadOnly=$true; $summary.ScrollBars='Vertical'; $summary.AccessibleName='Prüfergebnis'
$summary.Text=if ($Move) { 'Neue Quelldatei auswählen, dann den Wechsel prüfen. Der bisherige Profilstand bleibt während der Prüfung in Gebrauch.' }
    elseif ($Rotate) { 'Neue Quelle, neue öffentliche Prüfschlüsseldatei und signierte Übergabe auswählen. Danach den Wechsel auf diesem Gerät prüfen.' }
    elseif ($Disconnect) { 'Die bestehende Verbindung prüfen, dann ausdrücklich trennen. Persönliche Werte und lokale Historie bleiben erhalten.' }
    else { 'Quelle und Prüfschlüssel auswählen, dann „Quelle prüfen“.' }
$layout.Controls.Add($summary,0,6)
$buttons=New-Object Windows.Forms.FlowLayoutPanel; $buttons.Dock='Fill'
$check=New-Object Windows.Forms.Button; $check.Text=if ($Move -or $Rotate) { 'Wechsel prüfen' } elseif ($Disconnect) { 'Trennung prüfen' } else { 'Quelle prüfen' }; $check.AutoSize=$true
$bind=New-Object Windows.Forms.Button; $bind.Text=if ($Move) { 'Quelle wechseln' } elseif ($Rotate) { 'Prüfschlüssel wechseln' } elseif ($Disconnect) { 'Verbindung trennen' } else { 'Dieses Gerät verbinden' }; $bind.AutoSize=$true
$resume=New-Object Windows.Forms.Button; $resume.Text=if ($Disconnect) { 'Trennung fortsetzen' } else { 'Wechsel fortsetzen' }; $resume.AutoSize=$true; $resume.Visible=$Move -or $Disconnect -or $Rotate
$restart=New-Object Windows.Forms.Button; $restart.Text='Abgleich neu starten'; $restart.AutoSize=$true
$close=New-Object Windows.Forms.Button; $close.Text='Schließen'; $close.AutoSize=$true
$buttons.Controls.AddRange(@($check,$bind,$resume,$restart,$close)); $layout.Controls.Add($buttons,0,7)
$timer=New-Object Windows.Forms.Timer; $timer.Interval=150
function Device-Mode { if ($mode.SelectedIndex -eq 1) { 'apply-compatible' } else { 'review-only' } }
function Update-Buttons {
    $busy=$null -ne $script:process
    $disconnectPending=$script:isDisconnect -and (Test-Path -LiteralPath (Join-Path $Store 'preferences-source-disconnect.json') -PathType Leaf)
    $rotationPending=$script:isRotate -and (Test-Path -LiteralPath (Join-Path $Store 'preferences-trust-rotation.json') -PathType Leaf)
    $check.Enabled=(!$busy -and !$disconnectPending -and !$rotationPending -and ($script:isDisconnect -or (![string]::IsNullOrWhiteSpace($source.Text) -and ($script:isMove -or ![string]::IsNullOrWhiteSpace($trust.Text)) -and (!$script:isRotate -or ![string]::IsNullOrWhiteSpace($handover.Text)))))
    $bind.Enabled=(!$busy -and !$disconnectPending -and !$rotationPending -and $null -ne $script:devicePlan -and (!$script:isDisconnect -or $script:devicePlan.canDisconnect))
    $resume.Enabled=(!$busy -and (($script:isMove -and (Test-Path -LiteralPath (Join-Path $Store 'preferences-source-migration.json') -PathType Leaf)) -or
        $disconnectPending -or $rotationPending))
    $restart.Enabled=(!$busy -and $script:restartNeeded)
    $close.Enabled=!$busy
    $source.Enabled=(!$busy -and !$script:isDisconnect -and !$rotationPending); $trust.Enabled=(!$busy -and !$script:isMove -and !$script:isDisconnect -and !$rotationPending); $mode.Enabled=(!$busy -and !$script:isCompany -and !$script:isMove -and !$script:isDisconnect -and !$script:isRotate)
    $handover.Enabled=(!$busy -and !$rotationPending)
    $sourceBrowse.Enabled=(!$busy -and !$script:isDisconnect -and !$rotationPending); $trustBrowse.Enabled=(!$busy -and !$script:isMove -and !$script:isDisconnect -and !$rotationPending); $handoverBrowse.Enabled=(!$busy -and !$rotationPending)
}
function Start-DeviceAction([string]$Action) {
    if ($script:process) { return }
    if ($Action -eq 'restart') {
        $arguments=@('-NoProfile','-File',(Join-Path $PSScriptRoot 'Neustart-Hintergrund.ps1'),'-Store',$Store)
    } else {
        if ($script:isDisconnect) {
            $command='preferences-source-disconnect-'+$(if ($Action -eq 'bind') { 'commit' } else { $Action })
            $arguments=@($command,'--store',$Store)
        } elseif ($script:isMove) {
            $command='preferences-source-migration-'+$(if ($Action -eq 'bind') { 'commit' } else { $Action })
            $arguments=@($command,'--store',$Store)
            if ($Action -ne 'resume') { $arguments+=@('--new-source',$source.Text) }
        } elseif ($script:isRotate) {
            $command='preferences-trust-rotation-'+$(if ($Action -eq 'bind') { 'commit' } else { $Action })
            $arguments=@($command,'--store',$Store)
            if ($Action -ne 'resume') { $arguments+=@('--new-source',$source.Text,'--new-trust',$trust.Text,'--handover',$handover.Text) }
        } elseif ($script:isCompany) {
            $command='preferences-company-device-'+$Action
            $arguments=@($command,'--store',$Store,
                '--preferences-policy-source',$source.Text,'--preferences-policy-trust',$trust.Text)
        } else {
            $command='preferences-device-'+$Action
            $arguments=@($command,'--store',$Store,
                '--preferences-source',$source.Text,'--preferences-trust',$trust.Text,'--preferences-mode',(Device-Mode))
        }
        if ($Action -eq 'bind') { $arguments+=@('--confirmation',$script:devicePlan.planDigest) }
    }
    $start=New-Object Diagnostics.ProcessStartInfo
    if ($Action -eq 'restart') { $start.FileName='powershell.exe' } else { $start.FileName=$manager }
    $start.UseShellExecute=$false; $start.CreateNoWindow=$true
    $start.RedirectStandardOutput=$true; $start.RedirectStandardError=$true
    $start.StandardOutputEncoding=New-Object Text.UTF8Encoding($false)
    $start.StandardErrorEncoding=New-Object Text.UTF8Encoding($false)
    $start.Arguments=($arguments | ForEach-Object { '"'+[regex]::Replace([regex]::Replace([string]$_,'(\\*)"','$1$1\"'),'(\\+)$','$1$1')+'"' }) -join ' '
    try {
        $script:action=$Action; $script:process=[Diagnostics.Process]::Start($start)
        $script:stdout=$script:process.StandardOutput.ReadToEndAsync()
        $script:stderr=$script:process.StandardError.ReadToEndAsync()
        $summary.Text=if ($script:isDisconnect) { 'Persönliche Verbindung wird geprüft …' }
            else { 'Signierte Quelle und Bindung werden geprüft …' }
        $timer.Start()
    } catch { $script:process=$null; $summary.Text='Der Manager konnte nicht gestartet werden. Bitte die lokale Installation prüfen.' }
    Update-Buttons
}
$timer.Add_Tick({
    if (!$script:process -or !$script:process.HasExited) { return }
    $code=$script:process.ExitCode; $output=$script:stdout.GetAwaiter().GetResult()
    $failure=$script:stderr.GetAwaiter().GetResult()
    $script:process.Dispose(); $script:process=$null; $timer.Stop()
    if ($code -eq 0) {
        try {
            $result=$output | ConvertFrom-Json
            if ($script:action -eq 'restart') {
                $script:restartNeeded=$false
                $summary.Text=if ($script:isCompany) { 'Der Hintergrundabgleich wurde mit der Firmenquelle neu gestartet. Neue Regeln werden signiert geprüft.' }
                    elseif ($script:isDisconnect) { 'Der Hintergrundabgleich wurde ohne persönliche Quellenverbindung neu gestartet. Eine gebundene Firmenquelle wird weiterhin geprüft.' }
                    else { 'Der Hintergrundabgleich wurde mit den persönlichen Einstellungen neu gestartet. Neue Revisionen werden nach dem gewählten Modus geprüft.' }
            } elseif ($script:action -eq 'plan' -and $script:isMove) {
                $script:devicePlan=$result
                $summary.Text='Profil: '+$result.authority+'/'+$result.profileId+' · bisher Revision '+$result.oldRevision+
                    ', neue Quelle Revision '+$result.newRevision+"`r`n"+
                    'Der gebundene Prüfschlüssel bleibt unverändert. Die bisher angewendete Generation bleibt erhalten; neue Werte werden hier nicht übernommen.'+"`r`n"+
                    'Nach dem Wechsel ist ein Neustart des Hintergrundabgleichs erforderlich.'
            } elseif ($script:action -eq 'plan' -and $script:isRotate) {
                $script:devicePlan=$result
                $summary.Text='Profil: '+$result.authority+'/'+$result.profileId+' · bisher Revision '+$result.oldRevision+
                    ', neue Revision '+$result.newRevision+"`r`n"+
                    'Bisheriger Prüfschlüssel: '+$result.oldKeyId+"`r`n"+
                    'Neuer Prüfschlüssel: '+$result.newKeyId+"`r`n"+
                    'Signierte Übergabe gültig bis: '+$result.handoverExpiresAt+"`r`n"+
                    'Die bisher angewendete Generation bleibt erhalten. Neue Werte werden hier nicht übernommen; Plugin-Pakete werden nicht installiert.'+"`r`n"+
                    'Vor dem Wechsel den laufenden Abgleich beenden; danach den Hintergrundabgleich neu starten.'
            } elseif ($script:action -eq 'plan' -and $script:isDisconnect) {
                $script:devicePlan=$result
                $companyText=if ($result.companyBindingPreserved) { 'Die gebundene Firmenquelle und ihre Regeln bleiben im Hintergrund aktiv.' }
                    else { 'Auf diesem Gerät ist keine Firmenquelle gebunden.' }
                $valueText=if ($result.retainsAppliedValues) { 'Zuletzt angewendet: Revision '+$result.appliedRevision+'. Diese Werte und die lokale Historie bleiben erhalten.' }
                    else { 'Bisher wurde keine persönliche Revision angewendet. Die lokale Historie bleibt erhalten.' }
                $summary.Text='Profil: '+$result.profileId+"`r`n"+
                    'Dieses Gerät bezieht nach der Trennung keine neuen persönlichen Revisionen automatisch. '+
                    $valueText+"`r`n"+
                    $companyText+"`r`n"+
                    'Das entfernte Profil und Zugangsdaten werden nicht gelöscht. Vor der Trennung den laufenden Abgleich beenden; danach ist ein Neustart erforderlich.'
            } elseif ($script:action -eq 'plan') {
                $script:devicePlan=$result
                if ($script:isCompany) {
                    $summary.Text='Firma: '+$result.authority+'/'+$result.companyId+' · Revision '+$result.revision+"`r`n"+
                        'Quelle und Signatur wurden jetzt geprüft. Gültig bis: '+$result.expiresAt+"`r`n"+
                        'Firmenregeln können persönliche oder projektbezogene Werte begrenzen. Bestehende Zugänge ändern sich nicht.'
                } else {
                    $effect=if ($result.mode -eq 'apply-compatible') { 'Kompatible Revisionen werden nach Prüfung lokal übernommen.' }
                        else { 'Neue Revisionen werden zunächst nur angezeigt.' }
                    $summary.Text='Profil: '+$result.authority+'/'+$result.profile+' · Revision '+$result.revision+"`r`n"+
                        'Quelle und Signatur wurden jetzt geprüft. '+$effect+"`r`n"+
                        'Der Projektordner bleibt geräteabhängig; Zugänge und externe Freigaben werden nicht erteilt.'
                }
            } else {
                $script:devicePlan=$null
                $script:restartNeeded=$true
                if ($script:isDisconnect) {
                    $valueText=if ($result.appliedGenerationPreserved) { 'Die bisher angewendeten Werte bleiben lokal nutzbar.' }
                        else { 'Bisher war keine persönliche Revision angewendet.' }
                    $summary.Text='Die persönliche Quellenverbindung wurde auf diesem Gerät getrennt. '+
                        $valueText+' Neue persönliche Revisionen werden nicht automatisch bezogen.'+"`r`n"+
                        'Den Hintergrundabgleich neu starten. Eine gebundene Firmenquelle wird weiter geprüft.'
                } elseif ($script:isMove) {
                    $summary.Text='Die persönliche Quelle wurde auf Revision '+$result.revision+' umgestellt. Die bisher angewendete Generation bleibt erhalten.'+"`r`n"+
                        'Den Hintergrundabgleich neu starten, damit künftige Revisionen von der neuen Quelle geprüft werden.'
                } elseif ($script:isRotate) {
                    $summary.Text='Der persönliche Prüfschlüssel wurde auf diesem Gerät gewechselt. Die bisher angewendete Generation bleibt erhalten.'+"`r`n"+
                        'Die neue Revision muss gesondert übernommen werden. Den Hintergrundabgleich neu starten, damit künftige Revisionen geprüft werden.'
                } elseif ($script:isCompany) {
                    $summary.Text='Die signierten Firmenregeln der Revision '+$result.revision+' sind auf diesem Gerät gebunden.'+"`r`n"+
                        'Der laufende Hintergrundabgleich muss neu gestartet werden, damit spätere Revisionen geprüft werden.'
                } else {
                    $summary.Text='Dieses Gerät ist mit Revision '+$result.revision+' verbunden. '+
                        $(if ($result.application -eq 'applied') { 'Die signierte Konfiguration wurde lokal übernommen.' }
                          else { 'Die signierte Konfiguration wartet auf deine Übernahme.' })+"`r`n"+
                        'Der laufende Hintergrundabgleich muss neu gestartet werden, damit spätere Revisionen automatisch geprüft werden.'
                }
            }
        } catch { $summary.Text='Die Antwort konnte nicht gelesen werden. Den Gerätestatus im Manager erneut prüfen.' }
    } else {
        $script:devicePlan=$null
        $summary.Text=if ($script:isDisconnect -and $failure -match 'resume-source-disconnect') {
            'Eine begonnene Trennung muss zuerst über „Trennung fortsetzen“ abgeschlossen werden.'
        } elseif ($script:isMove -and $failure -match 'resume-source-migration') {
            'Ein begonnener Quellenwechsel muss zuerst über „Wechsel fortsetzen“ abgeschlossen werden.'
        } elseif ($script:isRotate -and $failure -match 'resume-trust-rotation') {
            'Ein begonnener Prüfschlüsselwechsel muss zuerst über „Wechsel fortsetzen“ abgeschlossen werden.'
        } elseif ($failure -match 'GitHub read failed|release path|FileNotFound') {
            'Die signierte Freigabe ist noch nicht erreichbar. Der bestehende Plugin-Betrieb bleibt erhalten.'
        } else { 'Einrichtung angehalten. Bitte Quelle, Prüfschlüssel und Berechtigung prüfen; der bestehende Stand bleibt erhalten.' }
    }
    Update-Buttons
})
foreach ($inputControl in @($source,$trust,$mode,$handover)) {
    $inputControl.Add_TextChanged({ $script:devicePlan=$null; Update-Buttons })
}
$sourceBrowse.Add_Click({ $picker=New-Object Windows.Forms.OpenFileDialog; $picker.Filter='JSON-Dateien (*.json)|*.json';
    try { if ($picker.ShowDialog() -eq 'OK') { $source.Text=$picker.FileName } } finally { $picker.Dispose() } })
$trustBrowse.Add_Click({ $picker=New-Object Windows.Forms.OpenFileDialog; $picker.Filter='JSON-Dateien (*.json)|*.json';
    try { if ($picker.ShowDialog() -eq 'OK') { $trust.Text=$picker.FileName } } finally { $picker.Dispose() } })
$handoverBrowse.Add_Click({ $picker=New-Object Windows.Forms.OpenFileDialog; $picker.Filter='JSON-Dateien (*.json)|*.json';
    try { if ($picker.ShowDialog() -eq 'OK') { $handover.Text=$picker.FileName } } finally { $picker.Dispose() } })
$check.Add_Click({ Start-DeviceAction 'plan' })
$bind.Add_Click({
    if (!$script:devicePlan) { return }
    $message=if ($script:isDisconnect) {
        'Persönliche Quellenverbindung auf diesem Gerät trennen?'+"`r`n`r`n"+
            'Neue persönliche Revisionen werden dann nicht mehr automatisch bezogen. '+
            'Bereits geprüfte Werte und die lokale Historie bleiben erhalten. '+
            'Eine gebundene Firmenquelle läuft weiter. Das entfernte Profil und Zugangsdaten werden nicht gelöscht.'+"`r`n`r`n"+
            'Danach ist ein Neustart des Hintergrundabgleichs nötig.'
    } elseif ($script:isMove) {
        'Persönliche Quelle zu '+$script:devicePlan.newSourcePath+' wechseln?'+"`r`n"+
            'Prüfschlüssel und angewendete Werte bleiben erhalten. Danach ist ein Neustart des Hintergrundabgleichs nötig.'
    } elseif ($script:isRotate) {
        'Prüfschlüssel für '+$script:devicePlan.authority+'/'+$script:devicePlan.profileId+' wechseln?'+"`r`n"+
            'Revision '+$script:devicePlan.oldRevision+' zu '+$script:devicePlan.newRevision+"`r`n"+
            'Übergabe gültig bis: '+$script:devicePlan.handoverExpiresAt+"`r`n`r`n"+
            'Bereits angewendete Werte bleiben erhalten. Neue Werte werden gesondert übernommen. Danach den Hintergrundabgleich neu starten.'
    } elseif ($script:isCompany) {
        'Firma '+$script:devicePlan.authority+'/'+$script:devicePlan.companyId+' · Revision '+$script:devicePlan.revision+
            "`r`nGültig bis: "+$script:devicePlan.expiresAt+"`r`n`r`nDieses Gerät jetzt mit genau dieser Firmenquelle verbinden?"
    } else {
        'Profil '+$script:devicePlan.authority+'/'+$script:devicePlan.profile+' · Revision '+$script:devicePlan.revision+
            "`r`nModus: "+$mode.Text+"`r`n`r`nDieses Gerät jetzt mit genau dieser Quelle verbinden?"
    }
    if ([Windows.Forms.MessageBox]::Show($form,$message,$form.Text,'YesNo','Question') -eq 'Yes') {
        Start-DeviceAction 'bind'
    }
})
$resume.Add_Click({ Start-DeviceAction 'resume' })
$restart.Add_Click({ Start-DeviceAction 'restart' })
$close.Add_Click({ $form.Close() })
$form.Add_FormClosing({ param($sender,$eventArgs)
    if ($script:process) { $eventArgs.Cancel=$true; $summary.Text='Die Quellenprüfung läuft noch. Bitte ihr Ergebnis abwarten.' }
})
Update-Buttons
if ($ValidateOnly) { $timer.Dispose(); $form.Dispose(); 'Preferences device dialog constructed; no source or profile changed.'; return }
$script:managerWorkLease = & (Join-Path $PSScriptRoot 'Manager-Work-Lease.ps1')
try {
    try { $form.ShowDialog() | Out-Null } finally { $timer.Dispose(); $form.Dispose() }
} finally {
    if ($script:managerWorkLease) { $script:managerWorkLease.Dispose() }
}
