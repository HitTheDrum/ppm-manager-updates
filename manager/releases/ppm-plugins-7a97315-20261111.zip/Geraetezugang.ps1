﻿param([switch]$SelfTest, [switch]$ValidateOnly, [switch]$CloseOnSuccess, [switch]$CheckExisting)
$ErrorActionPreference = 'Stop'
$script:managerWorkLease = & (Join-Path $PSScriptRoot 'Manager-Work-Lease.ps1')
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Net.Http
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class ProfileCredentialSetup {
    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
    struct Credential {
        public uint Flags, Type;
        public string TargetName, Comment;
        public System.Runtime.InteropServices.ComTypes.FILETIME LastWritten;
        public uint CredentialBlobSize;
        public IntPtr CredentialBlob;
        public uint Persist, AttributeCount;
        public IntPtr Attributes;
        public string TargetAlias, UserName;
    }
    [DllImport("advapi32.dll", EntryPoint="CredWriteW", CharSet=CharSet.Unicode, SetLastError=true)]
    static extern bool Write(ref Credential value, uint flags);
    [DllImport("advapi32.dll", EntryPoint="CredReadW", CharSet=CharSet.Unicode, SetLastError=true)]
    static extern bool Read(string target, uint type, uint flags, out IntPtr value);
    [DllImport("advapi32.dll", EntryPoint="CredDeleteW", CharSet=CharSet.Unicode, SetLastError=true)]
    static extern bool Delete(string target, uint type, uint flags);
    [DllImport("advapi32.dll")] static extern void CredFree(IntPtr value);
    public const string Target = "PersonalPluginManager/github/HitTheDrum/personal-plugin-profile";
    public static bool Exists(string target) {
        IntPtr value;
        if (Read(target, 1, 0, out value)) { CredFree(value); return true; }
        if (Marshal.GetLastWin32Error() != 1168) throw new InvalidOperationException("Anmeldespeicher nicht lesbar.");
        return false;
    }
    public static void Save(string target, string token) {
        if (target != Target && !target.StartsWith(Target + "/self-test/", StringComparison.Ordinal))
            throw new InvalidOperationException("Unbekanntes Zugangsziel.");
        if (String.IsNullOrWhiteSpace(token) || token.Length > 1280)
            throw new InvalidOperationException("Ungueltiger Zugang.");
        foreach(char c in token) if (Char.IsControl(c)) throw new InvalidOperationException("Ungueltiger Zugang.");
        if (Exists(target)) throw new InvalidOperationException("Ein Zugang ist bereits vorhanden. Er wurde nicht ersetzt.");
        IntPtr secret = Marshal.StringToCoTaskMemUni(token);
        try {
            Credential value = new Credential { Type=1, TargetName=target, UserName="HitTheDrum",
                Comment="Personal plugin profile: device read access", Persist=2,
                CredentialBlobSize=checked((uint)token.Length * 2), CredentialBlob=secret };
            if (!Write(ref value, 0)) throw new InvalidOperationException("Zugang konnte nicht gespeichert werden.");
        } finally { Marshal.ZeroFreeCoTaskMemUnicode(secret); }
    }
    public static void Test() {
        string target=Target + "/self-test/" + Guid.NewGuid().ToString("N");
        string sample="disposable-test-" + Guid.NewGuid().ToString("N");
        try {
            Save(target, sample);
            IntPtr value;
            if (!Read(target, 1, 0, out value)) throw new Exception("Test read failed.");
            try {
                Credential data=(Credential)Marshal.PtrToStructure(value, typeof(Credential));
                if (data.Type!=1 || data.Persist!=2 || data.CredentialBlobSize!=sample.Length*2 ||
                    Marshal.PtrToStringUni(data.CredentialBlob, sample.Length)!=sample) throw new Exception("Test mismatch.");
            } finally { CredFree(value); }
            bool blocked=false;
            try { Save(target,sample); } catch(InvalidOperationException) { blocked=true; }
            if (!blocked) throw new Exception("Overwrite protection failed.");
        } finally {
            if (Exists(target) && !Delete(target,1,0)) throw new Exception("Test cleanup failed.");
        }
        if (Exists(target)) throw new Exception("Test entry remains.");
    }
}
'@
if ($SelfTest) {
    [ProfileCredentialSetup]::Test()
    Write-Output 'PASS: Windows credential roundtrip, overwrite protection, cleanup.'
    return
}
if ($CheckExisting) {
    if ([ProfileCredentialSetup]::Exists([ProfileCredentialSetup]::Target)) { Write-Output 'present' }
    else { Write-Output 'absent' }
    return
}
[System.Windows.Forms.Application]::EnableVisualStyles()
$form = New-Object System.Windows.Forms.Form
$form.Text = 'Plugin-Verwaltung: Geraetezugang'
$form.ClientSize = New-Object System.Drawing.Size(610,330)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$intro = New-Object System.Windows.Forms.Label
$intro.SetBounds(20,15,570,85)
$intro.Text = "GitHub-Lesezugang fuer dieses Geraet einrichten.`r`nIm GitHub-Formular: Only select repositories > personal-plugin-profile.`r`nBerechtigung: Contents = Read-only; keine Schreibrechte.`r`nDen erzeugten Token ausschliesslich unten eingeben."
$form.Controls.Add($intro)
$link = New-Object System.Windows.Forms.LinkLabel
$link.SetBounds(20,105,560,25)
$link.Text = 'GitHub-Formular oeffnen (Lesezugang, 90 Tage)'
$link.Add_LinkClicked({ Start-Process 'https://github.com/settings/personal-access-tokens/new?name=PluginManager-Geraet&target_name=HitTheDrum&expires_in=90&contents=read' })
$form.Controls.Add($link)
$tokenBox = New-Object System.Windows.Forms.TextBox
$tokenBox.SetBounds(20,140,570,28)
$tokenBox.UseSystemPasswordChar = $true
$tokenBox.MaxLength = 1280
$form.Controls.Add($tokenBox)
$scope = New-Object System.Windows.Forms.CheckBox
$scope.SetBounds(20,177,570,35)
$scope.Text = 'Nur personal-plugin-profile ausgewaehlt, Contents nur lesend.'
$form.Controls.Add($scope)
$status = New-Object System.Windows.Forms.Label
$status.SetBounds(20,260,570,60)
$status.Text = 'Der Zugriffstest prueft Lesbarkeit; er kann andere Token-Rechte nicht erkennen.'
$form.Controls.Add($status)
$save = New-Object System.Windows.Forms.Button
$save.SetBounds(20,220,270,32)
$save.Text = 'Lesezugriff pruefen und speichern'
$save.Add_Click({
    if (!$scope.Checked -or $tokenBox.Text -notmatch '^github_pat_[A-Za-z0-9_]+$') {
        $status.Text = 'Fine-grained Token eingeben und die Repository-Auswahl bestaetigen.'
        return
    }
    $save.Enabled = $false
    $status.Text = 'Lesezugriff wird geprueft (maximal 30 Sekunden) ...'
    $form.Refresh()
    $handler = New-Object System.Net.Http.HttpClientHandler
    $handler.AllowAutoRedirect = $false
    $handler.UseCookies = $false
    $http = New-Object System.Net.Http.HttpClient($handler)
    $http.Timeout = [TimeSpan]::FromSeconds(30)
    $http.MaxResponseContentBufferSize = 1000000
    $response = $null
    try {
        if ([ProfileCredentialSetup]::Exists([ProfileCredentialSetup]::Target)) { throw 'existing' }
        $http.DefaultRequestHeaders.UserAgent.ParseAdd('PersonalPluginManager/0.1')
        $http.DefaultRequestHeaders.Authorization = New-Object System.Net.Http.Headers.AuthenticationHeaderValue('Bearer', $tokenBox.Text)
        $http.DefaultRequestHeaders.Accept.ParseAdd('application/vnd.github.raw+json')
        $response = $http.GetAsync('https://api.github.com/repos/HitTheDrum/personal-plugin-profile/contents/profile.intent.json?ref=main').GetAwaiter().GetResult()
        if ([int]$response.StatusCode -ne 200) { throw 'access' }
        $body = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult() | ConvertFrom-Json
        if ($body.profileId -ne 'personal' -or $body.owner -ne 'HitTheDrum') { throw 'identity' }
        [ProfileCredentialSetup]::Save([ProfileCredentialSetup]::Target, $tokenBox.Text)
        $status.Text = 'Lesezugang im Windows-Anmeldespeicher gespeichert. Automatische Installation bleibt aus.'
        $tokenBox.Enabled = $false
        if ($CloseOnSuccess) { $form.DialogResult=[Windows.Forms.DialogResult]::OK; $form.Close() }
    } catch {
        $status.Text = 'Nicht gespeichert: Zugriff, Netzverbindung oder vorhandenen Anmeldeeintrag pruefen. Keine Geheimnisse protokolliert.'
        $save.Enabled = $true
    } finally {
        $tokenBox.Clear()
        if ($null -ne $response) { $response.Dispose() }
        $http.Dispose()
        $handler.Dispose()
    }
})
$form.Controls.Add($save)
try {
    if ($ValidateOnly) {
        if (!$tokenBox.UseSystemPasswordChar -or $form.Controls.Count -ne 6) { throw 'UI construction failed.' }
        Write-Output 'PASS: credential UI constructed, masked input, no network or credential mutation.'
    } else {
        [void]$form.ShowDialog()
        if ($CloseOnSuccess) {
            if ($form.DialogResult -eq [Windows.Forms.DialogResult]::OK) { Write-Output 'saved' }
            else { Write-Output 'cancelled' }
        }
    }
} finally { $tokenBox.Clear(); $form.Dispose() }
