﻿$script:managerAttentionProcess = $null
$script:managerAttentionOutput = $null
$script:managerAttentionError = $null
$script:managerAttentionStartedTick = 0L
$script:managerAttentionTimedOut = $false
$script:nextManagerAttention = [DateTime]::MinValue
$script:managerAttentionSnapshot = $null
$script:managerBalloonTarget = $false
if ($tray) {
    $tray.Add_BalloonTipClicked({
        if (-not $script:managerBalloonTarget) { return }
        try {
            $entry=Safe-Path (Join-Path (Join-Path $configRoot '..\..') 'bootstrap\ManagerUpdatesLauncher.exe')
            $start=New-Object Diagnostics.ProcessStartInfo
            $start.FileName=$entry;$start.UseShellExecute=$false;$start.CreateNoWindow=$true
            $process=[Diagnostics.Process]::Start($start)
            if ($process) {$process.Dispose()}
        } catch { }
    })
}
function Update-ManagerTray {
    if (-not $managerSourceStore) { return }
    if ($script:managerAttentionProcess -and $script:managerAttentionStartedTick -gt 0 -and
        ([Diagnostics.Stopwatch]::GetTimestamp() - $script:managerAttentionStartedTick) / [double][Diagnostics.Stopwatch]::Frequency -gt 30 -and
        (-not $script:managerAttentionProcess.HasExited -or
            -not $script:managerAttentionOutput.IsCompleted -or
            -not $script:managerAttentionError.IsCompleted)) {
        # Only our non-authoritative observer is stopped; no runtime/update worker.
        $script:managerAttentionTimedOut = $true
        try { if (-not $script:managerAttentionProcess.HasExited) { $script:managerAttentionProcess.Kill() } } catch { }
        $script:managerAttentionSnapshot = [pscustomobject]@{attention=[pscustomobject]@{
            healthy=$false;prompt=$false;needsYou=$false;
            summary='Manager-Hinweisprüfung überschritt ihre Frist. Manager-Updates öffnen.'}}
    }
    # Process exit alone does not guarantee EOF: a descendant can retain a
    # redirected handle. Never block the UI thread waiting for that reader.
    if ($script:managerAttentionProcess -and $script:managerAttentionProcess.HasExited -and
        -not $script:managerAttentionTimedOut -and
        (-not $script:managerAttentionOutput.IsCompleted -or
            -not $script:managerAttentionError.IsCompleted)) { return }
    if ($script:managerAttentionProcess -and $script:managerAttentionProcess.HasExited) {
        try {
            if ($script:managerAttentionTimedOut) { throw 'attention-query-timeout' }
            if ($script:managerAttentionProcess.ExitCode -ne 0) { throw 'attention-query-failed' }
            $raw = $script:managerAttentionOutput.GetAwaiter().GetResult()
            $script:managerAttentionSnapshot = $raw | ConvertFrom-Json
        } catch {
            if (-not $script:managerAttentionTimedOut) {
                $script:managerAttentionSnapshot = [pscustomobject]@{attention=[pscustomobject]@{
                    healthy=$false;prompt=$false;needsYou=$false;
                    summary='Manager-Hinweise nicht bestätigt. Manager-Updates öffnen.'}}
            }
        } finally {
            $script:managerAttentionProcess.Dispose()
            $script:managerAttentionProcess = $null
            $script:managerAttentionOutput = $null
            $script:managerAttentionError = $null
            $script:managerAttentionStartedTick = 0L
            $script:managerAttentionTimedOut = $false
        }
        $attention = $script:managerAttentionSnapshot.attention
        if ($tray -and $attention.prompt) {
            # Reservation was flushed by the single owner before this unobservable attempt.
            # Windows may suppress balloons; no delivery/read/consent claim follows.
            $script:managerBalloonTarget=$true
            try { $tray.ShowBalloonTip(8000,'Manager-Update',
                'Für die Plugin-Verwaltung ist ein Schritt nötig. Manager-Updates öffnen.',
                [Windows.Forms.ToolTipIcon]::Info) } catch { }
        }
    }
    if ($script:managerAttentionSnapshot -and $tray) {
        $attention = $script:managerAttentionSnapshot.attention
        if ($openUpdates) {
            $openUpdates.Text = if (-not $attention.healthy) { 'Manager-Updates: Hinweisstatus ungeklärt' }
                elseif ($attention.needsYou) { 'Manager-Updates: Handlung erforderlich' }
                elseif ($attention.PSObject.Properties['health'] -and -not $attention.health.healthy) { 'Manager-Updates: Hinweisstatus eingeschränkt' }
                else { 'Manager-Updates öffnen' }
            $openUpdates.AccessibleName = $openUpdates.Text
            $openUpdates.ToolTipText = [string]$attention.summary
            if($attention.PSObject.Properties['health'] -and -not $attention.health.healthy) {
                $openUpdates.ToolTipText += ' ' + [string]$attention.health.summary
            }
        }
        if ($attention.needsYou) {
            if ($alertIcon) { $tray.Icon = $alertIcon }
            $tray.Text = 'Plugin-Verwaltung: Manager benötigt deine Handlung'
        } else {
            if ($script:pluginAttention -and $alertIcon) { $tray.Icon = $alertIcon }
            elseif ($trayIcon) { $tray.Icon = $trayIcon }
            if ($script:pluginTrayText) { $tray.Text = $script:pluginTrayText }
        }
    }
    if (-not $script:managerAttentionProcess -and [DateTime]::UtcNow -ge $script:nextManagerAttention) {
        $script:nextManagerAttention = [DateTime]::UtcNow.AddSeconds(5)
        try {
            $stableRoot = Safe-Path (Join-Path $configRoot '..\..')
            $scriptPath = Safe-Path (Join-Path $stableRoot 'bootstrap\Manager-Updates.ps1')
            if (-not [IO.File]::Exists($scriptPath)) { return }
            $start = New-Object Diagnostics.ProcessStartInfo
            $start.FileName = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
            $start.UseShellExecute = $false
            $start.CreateNoWindow = $true
            $start.WindowStyle = 'Hidden'
            $start.RedirectStandardOutput = $true
            $start.RedirectStandardError = $true
            $start.StandardOutputEncoding = New-Object Text.UTF8Encoding($false)
            $channel = if ($tray -and $tray.Visible) { 'balloon-unobservable' } else { 'unavailable' }
            $start.Arguments = '-NoProfile -NonInteractive -File "' + $scriptPath +
                '" -StateRoot "' + $managerSourceStore + '" -AttentionProbe -ClaimAttentionPrompt -AttentionChannel ' + $channel
            $script:managerAttentionProcess = [Diagnostics.Process]::Start($start)
            $script:managerAttentionStartedTick = [Diagnostics.Stopwatch]::GetTimestamp()
            $script:managerAttentionOutput=$script:managerAttentionProcess.StandardOutput.ReadToEndAsync()
            $script:managerAttentionError=$script:managerAttentionProcess.StandardError.ReadToEndAsync()
        } catch { $script:managerAttentionSnapshot = $null }
    }
}
