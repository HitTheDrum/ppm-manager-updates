﻿param([string]$Store, [switch]$ValidateOnly)
$ErrorActionPreference = 'Stop'
$script:managerWorkLease = & (Join-Path $PSScriptRoot 'Manager-Work-Lease.ps1')
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
$Store = [IO.Path]::GetFullPath($Store)
$manager = Join-Path $PSScriptRoot 'out\PluginManager.exe'
$script:approvalProcess = $null
$script:draft = $null
$form = New-Object Windows.Forms.Form
$form.Text = 'Plugin-Freigabe'; $form.Size = New-Object Drawing.Size(850,780)
$form.MinimumSize = New-Object Drawing.Size(740,680)
$form.StartPosition = 'CenterScreen'; $form.Font = New-Object Drawing.Font('Segoe UI',11)
$iconPath=Join-Path $PSScriptRoot 'assets\plugin-manager.ico'
if (Test-Path -LiteralPath $iconPath) { $form.Icon=New-Object Drawing.Icon($iconPath) }
$layout = New-Object Windows.Forms.TableLayoutPanel
$layout.Dock = 'Fill'; $layout.Padding = New-Object Windows.Forms.Padding(18)
$layout.ColumnCount=1; $layout.RowCount=7
foreach ($height in @(90,0,40,55,95,65,85)) {
    $style = if ($height -eq 0) { New-Object Windows.Forms.RowStyle('Percent',100) } else { New-Object Windows.Forms.RowStyle('Absolute',$height) }
    $layout.RowStyles.Add($style) | Out-Null
}
$form.Controls.Add($layout)
$heading = New-Object Windows.Forms.Label
$heading.Dock='Fill'; $heading.Text='1. Vorbereiten → 2. Prüfen → 3. Veröffentlichen'
$layout.Controls.Add($heading,0,0)
$summary = New-Object Windows.Forms.TextBox
$summary.Multiline=$true; $summary.ReadOnly=$true; $summary.ScrollBars='Vertical'; $summary.Dock='Fill'
$layout.Controls.Add($summary,0,1)
$links = New-Object Windows.Forms.FlowLayoutPanel; $links.Dock='Fill'
$sourceChoice = New-Object Windows.Forms.ComboBox; $sourceChoice.DropDownStyle='DropDownList'; $sourceChoice.Width=280
$compare = New-Object Windows.Forms.Button; $compare.Text='Änderungen ansehen'; $compare.AutoSize=$true
$links.Controls.AddRange(@($sourceChoice,$compare)); $layout.Controls.Add($links,0,2)
$instructions = New-Object Windows.Forms.Label; $instructions.Dock='Fill'
$instructions.Text='Was wurde geprüft, und welche Tests belegen es? Hier nur den Prüfvermerk eintragen, keine Zugangsdaten. Er wird im privaten Profil gespeichert.'
$layout.Controls.Add($instructions,0,3)
$evidence = New-Object Windows.Forms.TextBox; $evidence.Multiline=$true; $evidence.ScrollBars='Vertical'; $evidence.Dock='Fill'; $evidence.MaxLength=2000
$layout.Controls.Add($evidence,0,4)
$confirm = New-Object Windows.Forms.CheckBox; $confirm.Dock='Fill'
$confirm.Text='Ich habe die Änderungen und Testergebnisse geprüft und gebe genau die angezeigten Versionen für mein persönliches Profil frei.'
$layout.Controls.Add($confirm,0,5)
$actions=New-Object Windows.Forms.FlowLayoutPanel; $actions.Dock='Fill'
$publish=New-Object Windows.Forms.Button; $publish.Text='Freigeben und veröffentlichen'; $publish.AutoSize=$true
$prepare=New-Object Windows.Forms.Button; $prepare.Text='Neu vorbereiten'; $prepare.AutoSize=$true
$close=New-Object Windows.Forms.Button; $close.Text='Später / Schließen'; $close.AutoSize=$true
$actions.Controls.AddRange(@($publish,$prepare,$close)); $layout.Controls.Add($actions,0,6)
$timer=New-Object Windows.Forms.Timer; $timer.Interval=250
function Update-ApprovalButtons {
    $busy=$null -ne $script:approvalProcess
    $publish.Enabled=(!$busy -and $script:draft -and !$script:draft.published -and $confirm.Checked -and $evidence.Text.Trim().Length -ge 12)
    $prepare.Enabled=!$busy
    $close.Enabled=!$busy
    $confirm.Enabled=(!$busy -and $script:draft -and !$script:draft.published)
    $evidence.ReadOnly=($busy -or ($script:draft -and $script:draft.publicationPending))
}
function Start-ApprovalAction([string]$Action) {
    if ($script:approvalProcess) { return }
    if (!(Test-Path -LiteralPath (Join-Path $Store 'authoring-config.json'))) {
        $heading.Text='Dieses Gerät ist nicht als Freigabegerät eingerichtet. Hier können freigegebene Updates gelesen und installiert werden.'
        return
    }
    $arguments=@($Action,'--store',$Store)
    if ($Action -eq 'publish-approval') {
        $arguments+=@('--draft',$script:draft.draftId,'--confirmation',$script:draft.fingerprint,'--evidence',$evidence.Text.Trim())
    }
    $start=New-Object Diagnostics.ProcessStartInfo
    $start.FileName=$manager; $start.UseShellExecute=$false; $start.CreateNoWindow=$true
    $start.RedirectStandardOutput=$true; $start.RedirectStandardError=$true
    $start.Arguments=($arguments | ForEach-Object { '"'+[regex]::Replace([regex]::Replace([string]$_,'(\\*)"','$1$1\"'),'(\\+)$','$1$1')+'"' }) -join ' '
    try {
        $script:action=$Action
        $script:approvalProcess=[Diagnostics.Process]::Start($start)
        $script:stdout=$script:approvalProcess.StandardOutput.ReadToEndAsync()
        $script:stderr=$script:approvalProcess.StandardError.ReadToEndAsync()
        $heading.Text=if ($Action -eq 'publish-approval') { '3. Veröffentlichen läuft … Signatur und Online-Stand werden geprüft.' } else { '1. Vorbereitung läuft … Quellen und Paketdateien werden geprüft.' }
        Update-ApprovalButtons; $timer.Start()
    } catch { $script:approvalProcess=$null; $heading.Text='Der Freigabevorgang konnte nicht starten. Bitte die lokale Einrichtung prüfen.'; Update-ApprovalButtons }
}
$timer.Add_Tick({
    if (!$script:approvalProcess -or !$script:approvalProcess.HasExited) { return }
    $code=$script:approvalProcess.ExitCode
    $output=$script:stdout.GetAwaiter().GetResult(); $failure=$script:stderr.GetAwaiter().GetResult()
    $script:approvalProcess.Dispose(); $script:approvalProcess=$null; $timer.Stop()
    if ($code -ne 0) {
        $heading.Text='Angehalten. Details unten. Bei Übertragungsfehlern denselben Entwurf erneut versuchen; bei geändertem Stand neu vorbereiten.'
        $summary.Text='Der Freigabevorgang wurde nicht abgeschlossen. Bitte den Stand prüfen und bei unveränderten Eingaben erneut versuchen.'
        # Reload a persisted publication receipt so retries use the original review evidence.
        if ($script:action -eq 'publish-approval') { $script:lastFailure=$summary.Text; Start-ApprovalAction 'approval-status'; return }
    } else {
        try {
            $result=$output | ConvertFrom-Json
            if ($script:action -eq 'publish-approval') {
                $script:draft.published=$true
                $heading.Text=$result.message
            } elseif ($result.prepared) {
                $script:draft=$result; $summary.Text=$result.summary
                $heading.Text=if ($result.published) { 'Veröffentlicht. In der Übersicht jetzt online prüfen und Installation vorbereiten.' } else { '2. Änderungen und Tests prüfen. Die Paketversion erhält einen eindeutigen Commit-Zusatz. Plugin-Tests wurden hier nicht ausgeführt.' }
                $sourceChoice.Items.Clear()
                foreach ($change in $result.changes) { $sourceChoice.Items.Add($change.name) | Out-Null }
                if ($sourceChoice.Items.Count) { $sourceChoice.SelectedIndex=0 }
                $confirm.Checked=$false; $evidence.Text=[string]$result.evidence
                if ($script:lastFailure) { $heading.Text='Veröffentlichung angehalten. Details unten; bei geändertem Stand neu vorbereiten.'; $summary.Text=$script:lastFailure+"`r`n`r`n"+$summary.Text; $script:lastFailure=$null }
            } else { $script:draft=$null; $summary.Text=''; $heading.Text=$result.message }
        } catch { $heading.Text='Die Antwort konnte nicht gelesen werden. Fenster erneut öffnen; gespeicherte Entwürfe bleiben erhalten.' }
    }
    Update-ApprovalButtons
})
$compare.Add_Click({
    if (!$script:draft -or $sourceChoice.SelectedIndex -lt 0) { return }
    $url=$script:draft.changes[$sourceChoice.SelectedIndex].reviewUrl
    if ($url -match '^https://github.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+/compare/[a-f0-9]{40}\.\.\.[a-f0-9]{40}$') { Start-Process $url }
})
$prepare.Add_Click({ $script:draft=$null; $confirm.Checked=$false; $evidence.Text=''; Start-ApprovalAction 'prepare-approval' })
$publish.Add_Click({ Start-ApprovalAction 'publish-approval' })
$confirm.Add_CheckedChanged({ Update-ApprovalButtons }); $evidence.Add_TextChanged({ Update-ApprovalButtons })
$close.Add_Click({ $form.Close() })
$form.Add_FormClosing({ param($sender,$eventArgs)
    if ($script:approvalProcess) { $eventArgs.Cancel=$true; $heading.Text='Der Vorgang läuft noch. Bitte das Ergebnis abwarten.' }
    elseif ($script:draft -and $script:draft.draftId -match '^[a-f0-9]{32}$' -and !$script:draft.published) {
        try {
            $notePath=Join-Path $Store ('approvals\'+$script:draft.draftId+'\review-note.json')
            $note=@{fingerprint=$script:draft.fingerprint;evidence=$evidence.Text} | ConvertTo-Json
            [IO.File]::WriteAllText($notePath,$note,(New-Object Text.UTF8Encoding($false)))
        } catch { $eventArgs.Cancel=$true; $heading.Text='Prüfvermerk konnte nicht gespeichert werden. Bitte Text kopieren und erneut schließen.' }
    }
})
$form.Add_Shown({
    $currentPath=Join-Path $Store 'approval-current.json'
    try {
        $current=if (Test-Path -LiteralPath $currentPath) { Get-Content -LiteralPath $currentPath -Raw -Encoding UTF8 | ConvertFrom-Json } else { $null }
        if ($current -and $current.status -ne 'completed') { Start-ApprovalAction 'approval-status' }
        else { Start-ApprovalAction 'prepare-approval' }
    } catch { $heading.Text='Gespeicherter Entwurf ist nicht lesbar. Mit Neu vorbereiten erneut beginnen.' }
})
Update-ApprovalButtons
if ($ValidateOnly) { $form.Dispose(); $timer.Dispose(); Write-Output 'Freigabedialog geprüft; keine Quellen gelesen oder Freigabe veröffentlicht.'; return }
try { $form.ShowDialog() | Out-Null } finally { $timer.Dispose(); $form.Dispose() }
