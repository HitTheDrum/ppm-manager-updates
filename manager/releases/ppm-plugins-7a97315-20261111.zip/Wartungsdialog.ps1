﻿# UI helpers only; sourcing this file never starts maintenance.
function Get-MaintenanceBlockers {
    param([object[]]$Processes = @(Get-CimInstance Win32_Process))
    $byId = @{}
    foreach ($item in $Processes) { $byId[[int]$item.ProcessId] = $item }
    $labels = @()
    foreach ($item in $Processes) {
        if ($item.Name -notmatch '^(ChatGPT|Codex)(\.exe)?$') { continue }
        $parent = $item; $seen = @{}; $editor = $false
        while ($parent -and !$seen.ContainsKey([int]$parent.ProcessId)) {
            $seen[[int]$parent.ProcessId] = $true
            if ($parent.Name -match '^Code( - Insiders)?(\.exe)?$') { $editor = $true; break }
            $parent = $byId[[int]$parent.ParentProcessId]
        }
        if ($editor) { $labels += 'Visual Studio Code mit laufender Codex-Instanz' }
        elseif ($item.ExecutablePath -match 'WindowsApps' -or $item.Name -match '^ChatGPT') { $labels += 'ChatGPT-Desktop-App' }
        else { $labels += ('Codex-Prozess (PID ' + $item.ProcessId + ') – gegebenenfalls im Terminal oder Editor') }
    }
    $labels | Select-Object -Unique
}

function Show-MaintenanceReady {
    param([string]$PlanSummary = '', [long]$Revision = 0, [switch]$AutoStart)
    Add-Type -AssemblyName System.Windows.Forms
    $form = New-Object Windows.Forms.Form
    $form.Text = 'Plugin-Update vorbereiten'
    $form.Width = 640; $form.Height = 490; $form.StartPosition = 'CenterScreen'
    $form.FormBorderStyle = 'FixedDialog'; $form.MaximizeBox = $false
    $label = New-Object Windows.Forms.TextBox
    $label.Multiline = $true; $label.ReadOnly = $true; $label.ScrollBars = 'Vertical'; $label.BorderStyle = 'None'
    $label.SetBounds(20,20,580,350); $form.Controls.Add($label)
    $start = New-Object Windows.Forms.Button
    $start.Text = 'Update starten'; $start.SetBounds(320,385,140,35)
    $start.DialogResult = 'OK'; $form.Controls.Add($start)
    if ($AutoStart) { $start.Visible = $false }
    $cancel = New-Object Windows.Forms.Button
    $cancel.Text = 'Abbrechen'; $cancel.SetBounds(470,385,130,35)
    $cancel.DialogResult = 'Cancel'; $form.Controls.Add($cancel); $form.CancelButton = $cancel
    $timer = New-Object Windows.Forms.Timer; $timer.Interval = 1000
    $refresh = {
        try {
            $blockers = @(Get-MaintenanceBlockers)
            $start.Enabled = $blockers.Count -eq 0
            $label.Text = "Freigabe: Revision $Revision`r`n$PlanSummary`r`n`r`nSpeichere deine Arbeit und schließe die unten genannten Programme.`r`nDieses Update-Fenster bleibt geöffnet. Es wird nichts automatisch beendet.`r`n`r`n"
            if ($blockers.Count) { $label.Text += "Noch geöffnet:`r`n• " + ($blockers -join "`r`n• ") }
            else {
                if ($AutoStart) { $label.Text += 'Bereit. Das Update startet jetzt automatisch.' }
                else { $label.Text += 'Bereit. Klicke auf „Update starten“. Danach wird der Fortschritt angezeigt.' }
            }
            $label.Text += "`r`n`r`nNach dem Update öffnest du die ChatGPT-Desktop-App wieder.`r`ncanon-bootstrap ist ein Skill und muss nicht separat gestartet werden."
            if ($AutoStart -and $blockers.Count -eq 0 -and $form.Visible) {
                $form.DialogResult = [Windows.Forms.DialogResult]::OK
                $form.Close()
            }
        } catch { $start.Enabled = $false; $label.Text = 'Laufende Programme konnten nicht geprüft werden. Bitte abbrechen und die Verwaltung prüfen lassen.' }
    }
    $timer.Add_Tick($refresh)
    try { & $refresh; $timer.Start(); return $form.ShowDialog() -eq 'OK' }
    finally { $timer.Stop(); $timer.Dispose(); $form.Dispose() }
}

function Show-MaintenanceProgress {
    $script:progressForm = New-Object Windows.Forms.Form
    $script:progressForm.Text = 'Plugin-Update läuft'
    $script:progressForm.Width = 590; $script:progressForm.Height = 180
    $script:progressForm.StartPosition = 'CenterScreen'; $script:progressForm.ControlBox = $false
    $script:progressLabel = New-Object Windows.Forms.Label
    $script:progressLabel.SetBounds(20,20,540,90)
    $script:progressForm.Controls.Add($script:progressLabel)
    $script:progressForm.Show()
    Set-MaintenanceProgress 'Update wird gestartet …'
}

function Set-MaintenanceProgress([string]$Text) {
    if ($script:progressForm -and !$script:progressForm.IsDisposed) {
        $script:progressLabel.Text = $Text + "`r`n`r`nBitte warten. ChatGPT und die zuvor geschlossenen Coding Agents noch nicht öffnen."
        $script:progressForm.Refresh()
        [Windows.Forms.Application]::DoEvents()
    }
}

function Close-MaintenanceProgress {
    if ($script:progressForm) { $script:progressForm.Dispose(); $script:progressForm = $null }
}

function Show-AdoptionConfirmation {
    param([Parameter(Mandatory=$true)][string]$Summary)
    Add-Type -AssemblyName System.Windows.Forms
    $dialog=New-Object Windows.Forms.Form
    $dialog.Text='Vorhandenes Plugin übernehmen';$dialog.Size=New-Object Drawing.Size(720,440)
    $dialog.StartPosition='CenterScreen';$dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false
    $dialog.Font=New-Object Drawing.Font('Segoe UI',11)
    $text=New-Object Windows.Forms.TextBox
    $text.Multiline=$true;$text.ReadOnly=$true;$text.ScrollBars='Vertical';$text.SetBounds(20,20,665,285);$text.Text=$Summary
    $dialog.Controls.Add($text)
    $accept=New-Object Windows.Forms.Button
    $accept.Text='Vorhandene Installation übernehmen';$accept.SetBounds(20,325,390,45)
    $accept.DialogResult=[Windows.Forms.DialogResult]::OK;$dialog.Controls.Add($accept)
    $cancel=New-Object Windows.Forms.Button
    $cancel.Text='Abbrechen';$cancel.SetBounds(435,325,180,45)
    $cancel.DialogResult=[Windows.Forms.DialogResult]::Cancel;$dialog.Controls.Add($cancel)
    $dialog.CancelButton=$cancel;$dialog.AcceptButton=$null
    try { return $dialog.ShowDialog() -eq [Windows.Forms.DialogResult]::OK } finally {$dialog.Dispose()}
}

function Invoke-PathLink {
    param([Parameter(Mandatory=$true)]$Target,
          [ValidateSet('Container','Item')][string]$Segment,
          [int]$Modifiers=0)
    Add-Type -AssemblyName System.Windows.Forms
    $control=($Modifiers -band [int][Windows.Forms.Keys]::Control) -ne 0
    $alt=($Modifiers -band [int][Windows.Forms.Keys]::Alt) -ne 0
    if ($Segment -eq 'Container') {
        if ($control) { [Windows.Forms.Clipboard]::SetText($Target.Directory) }
        elseif ($alt) { [Windows.Forms.Clipboard]::SetText($Target.Full) }
        elseif (Test-Path -LiteralPath $Target.Directory -PathType Container) { Start-Process -FilePath explorer.exe -ArgumentList ('"'+$Target.Directory+'"') }
        else { throw 'Der Protokollordner ist nicht mehr vorhanden.' }
    } else {
        if ($control) { [Windows.Forms.Clipboard]::SetText($Target.Full) }
        elseif ($alt) { [Windows.Forms.Clipboard]::SetText($Target.Name) }
        elseif (Test-Path -LiteralPath $Target.Full -PathType Leaf) { Start-Process -FilePath notepad.exe -ArgumentList ('"'+$Target.Full+'"') }
        else { throw 'Die Protokolldatei ist nicht mehr vorhanden.' }
    }
}

function Format-MaintenanceFailure {
    param([string]$Operation,[string]$Stage,[string]$ErrorText,[int]$ExitCode)
    $heading = if ($Operation -eq 'adoption-plan') { 'Vorprüfung der vorhandenen Plugins' }
        else { 'Plugin-Wartung angehalten' }
    if ($Operation -eq 'adoption-plan' -and
        $ErrorText -match '^TimeoutException: CLI operation plugin-list exceeded ([0-9]{1,3}(?:\.[0-9]{1,3})?) seconds') {
        if ($ErrorText -like '*the process exited but an output stream remained open*') {
            $reason = 'Der Codex-Client hat die Prüfung der vorhandenen Plugins beendet, aber sein Ausgabekanal blieb offen. Die Plugin-Installation wurde noch nicht begonnen.'
        } else {
            $seconds = $Matches[1]
            $reason = "Die Prüfung der vorhandenen Plugins hat nach $seconds Sekunden keine Antwort vom Codex-Client erhalten. Die Plugin-Installation wurde noch nicht begonnen; der Grund ist noch nicht bekannt."
        }
    } else {
        $reason = "Der Manager hat diesen Schritt nicht abgeschlossen (Code $ExitCode). Bitte den bisherigen Stand prüfen lassen."
    }
    return "$heading`r`n$reason"
}

function Show-PathMessage {
    param([Parameter(Mandatory=$true)][string]$Message,
          [string]$Title='Plugin-Verwaltung', [string]$FilePath='')
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $form=New-Object Windows.Forms.Form
    $form.Text=$Title;$form.ClientSize=New-Object Drawing.Size(740,310)
    $form.MinimumSize=New-Object Drawing.Size(620,300)
    $form.StartPosition='CenterScreen';$form.Font=New-Object Drawing.Font('Segoe UI',10)
    $messageBox=New-Object Windows.Forms.TextBox
    $messageBox.Multiline=$true;$messageBox.ReadOnly=$true;$messageBox.ScrollBars='Vertical'
    $messageBox.BorderStyle='None';$messageBox.SetBounds(20,20,700,135)
    $messageBox.Anchor='Top,Left,Right';$messageBox.Text=$Message
    $form.Controls.Add($messageBox)
    $tip=New-Object Windows.Forms.ToolTip
    if ($FilePath) {
        $full=[IO.Path]::GetFullPath($FilePath)
        $directory=[IO.Path]::GetDirectoryName($full)
        $paths=[pscustomobject]@{Full=$full;Directory=$directory;Name=[IO.Path]::GetFileName($full)}
        $folderCaption=New-Object Windows.Forms.Label
        $folderCaption.Text='Protokollordner:';$folderCaption.SetBounds(20,166,700,22)
        $form.Controls.Add($folderCaption)
        $folderLink=New-Object Windows.Forms.LinkLabel
        $folderLink.Text=$directory;$folderLink.Tag=$paths
        $folderLink.AutoEllipsis=$true;$folderLink.SetBounds(20,188,700,24)
        $folderLink.Anchor='Top,Left,Right';$folderLink.AccessibleName="Protokollordner öffnen: $directory"
        $folderLink.Add_LinkClicked({
            param($sender,$eventArgs)
            try {
                Invoke-PathLink -Target $sender.Tag -Segment Container -Modifiers ([int][Windows.Forms.Control]::ModifierKeys)
            } catch { [void][Windows.Forms.MessageBox]::Show('Der Protokollordner konnte nicht geöffnet werden. Bitte die Zugriffsrechte prüfen.','Ordner öffnen') }
        })
        $tip.SetToolTip($folderLink,'Klick: Ordner öffnen. Strg+Klick: Ordnerpfad kopieren. Alt+Klick: vollständigen Dateipfad kopieren.')
        $form.Controls.Add($folderLink)
        $fileCaption=New-Object Windows.Forms.Label
        $fileCaption.Text='Protokolldatei:';$fileCaption.SetBounds(20,218,700,22)
        $form.Controls.Add($fileCaption)
        $fileLink=New-Object Windows.Forms.LinkLabel
        $fileLink.Text=$paths.Name;$fileLink.Tag=$paths
        $fileLink.SetBounds(20,240,700,24);$fileLink.Anchor='Top,Left,Right'
        $fileLink.AccessibleName="Protokolldatei öffnen: $full"
        $fileLink.Add_LinkClicked({
            param($sender,$eventArgs)
            try {
                Invoke-PathLink -Target $sender.Tag -Segment Item -Modifiers ([int][Windows.Forms.Control]::ModifierKeys)
            } catch { [void][Windows.Forms.MessageBox]::Show('Die Protokolldatei konnte nicht geöffnet werden. Bitte die Zugriffsrechte prüfen.','Datei öffnen') }
        })
        $tip.SetToolTip($fileLink,'Klick: Datei öffnen. Strg+Klick: vollständigen Pfad kopieren. Alt+Klick: Dateinamen kopieren.')
        $form.Controls.Add($fileLink)
    }
    $close=New-Object Windows.Forms.Button
    $close.Text='Schließen';$close.SetBounds(600,272,120,28)
    $close.Anchor='Bottom,Right';$close.DialogResult=[Windows.Forms.DialogResult]::OK
    $form.Controls.Add($close);$form.AcceptButton=$close
    try { [void]$form.ShowDialog() } finally { $tip.Dispose();$form.Dispose() }
}
