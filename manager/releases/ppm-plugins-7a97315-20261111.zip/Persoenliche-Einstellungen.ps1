﻿param([string]$Store, [switch]$ValidateOnly)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
$Store = [IO.Path]::GetFullPath($Store)
$manager = Join-Path $PSScriptRoot 'out\PluginManager.exe'
$script:preferencePlan = $null; $script:preferenceProcess = $null; $script:pendingEdits = @{}; $script:pendingOfflineEdits = @{}
$script:publicationPlan = $null
$script:activeDraftId = 'personal-editor'; $script:migrationPlan = $null; $script:migrationNewDraft = $null
$script:recentMigrationFrom = $null; $script:draftBeforeSelection = $null
$script:loadingField = $false; $script:selectedPreference = $null; $script:requestFile = $null
$form = New-Object Windows.Forms.Form
$form.Text = 'Persönliche Einstellungen'; $form.Size = New-Object Drawing.Size(1120,800)
$form.MinimumSize = New-Object Drawing.Size(860,650); $form.StartPosition = 'CenterScreen'
$form.Font = New-Object Drawing.Font('Segoe UI',11)
$layout = New-Object Windows.Forms.TableLayoutPanel
$layout.Dock='Fill'; $layout.Padding=New-Object Windows.Forms.Padding(18)
$layout.ColumnCount=1; $layout.RowCount=7
foreach ($height in @(75,40,0,100,125,75,95)) {
    $style=if ($height -eq 0) { New-Object Windows.Forms.RowStyle('Percent',100) } else { New-Object Windows.Forms.RowStyle('Absolute',$height) }
    $layout.RowStyles.Add($style) | Out-Null
}
$form.Controls.Add($layout)
$heading=New-Object Windows.Forms.Label; $heading.Dock='Fill'
$heading.Text='Persönlicher Entwurf wird geladen. Gespeicherte Änderungen werden erst nach einer Freigabe verteilt.'
$layout.Controls.Add($heading,0,0)
$profileLine=New-Object Windows.Forms.Label; $profileLine.Dock='Fill'; $layout.Controls.Add($profileLine,0,1)
$list=New-Object Windows.Forms.ListView; $list.Dock='Fill'; $list.View='Details'; $list.FullRowSelect=$true; $list.MultiSelect=$false; $list.HideSelection=$false
$list.AccessibleName='Einstellungen'
foreach ($column in @(@('Plugin / Einstellung',265),@('Persönlicher Entwurf',210),@('Vorschau',175),@('Quelle / Regel',330))) { $list.Columns.Add($column[0],$column[1]) | Out-Null }
$layout.Controls.Add($list,0,2)
$editor=New-Object Windows.Forms.TableLayoutPanel; $editor.Dock='Fill'; $editor.ColumnCount=2; $editor.RowCount=2
$editor.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',35))) | Out-Null
$editor.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent',65))) | Out-Null
$modeLabel=New-Object Windows.Forms.Label; $modeLabel.Text='Persönliche Vorgabe'; $modeLabel.Dock='Fill'
$valueLabel=New-Object Windows.Forms.Label; $valueLabel.Text='Wert'; $valueLabel.Dock='Fill'
$mode=New-Object Windows.Forms.ComboBox; $mode.DropDownStyle='DropDownList'; $mode.Dock='Fill'; $mode.AccessibleName='Persönliche Vorgabe'
$mode.Items.AddRange(@('Wieder erben','Wert','Fragen','Bewusst ungelöst'))
$value=New-Object Windows.Forms.ComboBox; $value.Dock='Fill'; $value.AccessibleName='Persönlicher Wert'
$editor.Controls.Add($modeLabel,0,0); $editor.Controls.Add($valueLabel,1,0); $editor.Controls.Add($mode,0,1); $editor.Controls.Add($value,1,1)
$layout.Controls.Add($editor,0,3)
$details=New-Object Windows.Forms.TextBox; $details.Dock='Fill'; $details.Multiline=$true; $details.ReadOnly=$true; $details.ScrollBars='Vertical'; $details.AccessibleName='Herkunft und Regeln'
$layout.Controls.Add($details,0,4)
$status=New-Object Windows.Forms.Label; $status.Dock='Fill'; $status.AccessibleName='Bearbeitungsstatus'
$layout.Controls.Add($status,0,5)
$actions=New-Object Windows.Forms.FlowLayoutPanel; $actions.Dock='Fill'; $layout.Controls.Add($actions,0,6)
$save=New-Object Windows.Forms.Button; $save.Text='Entwurf speichern'; $save.AutoSize=$true
$offlineEdit=New-Object Windows.Forms.Button; $offlineEdit.Text='Offline-Frist ändern'; $offlineEdit.AutoSize=$true
$refresh=New-Object Windows.Forms.Button; $refresh.Text='Stand neu lesen'; $refresh.AutoSize=$true
$rebase=New-Object Windows.Forms.Button; $rebase.Text='Mit neuem Profil abgleichen'; $rebase.AutoSize=$true
$migrate=New-Object Windows.Forms.Button; $migrate.Text='Schemaänderung übertragen'; $migrate.AutoSize=$true
$rescue=New-Object Windows.Forms.Button; $rescue.Text='Entwurf mit verlorener Basis retten'; $rescue.AutoSize=$true
$chooseDraft=New-Object Windows.Forms.Button; $chooseDraft.Text='Anderen Entwurf öffnen'; $chooseDraft.AutoSize=$true
$runEvidence=New-Object Windows.Forms.Button; $runEvidence.Text='Auftragsbeleg ansehen'; $runEvidence.AutoSize=$true
$review=New-Object Windows.Forms.Button; $review.Text='Freigabe prüfen'; $review.AutoSize=$true
$publish=New-Object Windows.Forms.Button; $publish.Text='Veröffentlichen'; $publish.AutoSize=$true
$discard=New-Object Windows.Forms.Button; $discard.Text='Offene Eingaben verwerfen'; $discard.AutoSize=$true
$close=New-Object Windows.Forms.Button; $close.Text='Schließen'; $close.AutoSize=$true
$actions.Controls.AddRange(@($save,$offlineEdit,$refresh,$rebase,$migrate,$rescue,$chooseDraft,$runEvidence,$review,$publish,$discard,$close))
$timer=New-Object Windows.Forms.Timer; $timer.Interval=150

function Get-EntryText($Entry) {
    if ($null -eq $Entry) { return 'Wieder erben' }
    switch ($Entry.mode) {
        'ask' { return 'Pro Projekt fragen' }
        'unset' { return 'Bewusst ungelöst' }
        'value' { if ($Entry.value -is [bool]) { if ($Entry.value) { return 'Ja' } else { return 'Nein' } }; return [string]$Entry.value }
        default { return 'Nicht gesetzt' }
    }
}
function Get-OfflineRuleText($Policy,[string]$Plugin,[string]$Field) {
    if ($Policy -is [string]) { return 'Offline: letzter geprüfter Stand ohne Altersgrenze (alter Vertrag)' }
    if (!$Policy -or !$Policy.plugins -or !$Policy.plugins.PSObject.Properties[$Plugin]) { return 'Offline-Regel nicht verfügbar' }
    $rules=$Policy.plugins.PSObject.Properties[$Plugin].Value
    if (!$rules.PSObject.Properties[$Field]) { return 'Offline-Regel für dieses Feld nicht gesetzt' }
    $rule=$rules.PSObject.Properties[$Field].Value
    if ($rule.mode -eq 'unbounded') { return 'Offline: ohne Altersgrenze für diesen persönlichen Wert' }
    if ($rule.mode -eq 'max-age') {
        $days=[math]::Round([double]$rule.maxAgeSeconds/86400,2)
        return 'Offline: '+$days+' Tage seit Prüfung der verwendeten Profilrevision; danach erneut fragen'
    }
    return 'Offline-Regel unbekannt; Wert nicht automatisch verwenden'
}
function Show-OfflineRuleChoice($CurrentRule) {
    $dialog=New-Object Windows.Forms.Form
    $dialog.Text='Offline-Frist für einen Wert'; $dialog.Size=New-Object Drawing.Size(570,245)
    $dialog.StartPosition='CenterParent'; $dialog.Font=$form.Font
    $panel=New-Object Windows.Forms.FlowLayoutPanel; $panel.Dock='Fill'; $panel.FlowDirection='TopDown'
    $panel.WrapContents=$false; $panel.Padding=New-Object Windows.Forms.Padding(16)
    $label=New-Object Windows.Forms.Label; $label.Width=510; $label.Height=46
    $label.Text='Wie lange darf der zuletzt geprüfte persönliche Wert offline verwendet werden? Nach Ablauf wird für diesen Wert erneut gefragt.'
    $choice=New-Object Windows.Forms.ComboBox; $choice.Width=500; $choice.DropDownStyle='DropDownList'
    $choice.AccessibleName='Offline-Nutzung'; $choice.Items.AddRange(@('Ohne Altersgrenze','Frist in Tagen'))
    $choice.SelectedIndex=if ($CurrentRule.mode -eq 'max-age') { 1 } else { 0 }
    $days=New-Object Windows.Forms.NumericUpDown; $days.Minimum=1; $days.Maximum=3650; $days.Width=130
    $days.AccessibleName='Offline-Frist in Tagen'
    if ($CurrentRule.mode -eq 'max-age') { $days.Value=[Math]::Min(3650,[Math]::Max(1,[Math]::Ceiling([double]$CurrentRule.maxAgeSeconds/86400))) }
    else { $days.Value=30 }
    $days.Enabled=($choice.SelectedIndex -eq 1)
    $choice.Add_SelectedIndexChanged({ $days.Enabled=($choice.SelectedIndex -eq 1) }.GetNewClosure())
    $buttons=New-Object Windows.Forms.FlowLayoutPanel; $buttons.Width=500; $buttons.Height=44
    $ok=New-Object Windows.Forms.Button; $ok.Text='In Entwurf übernehmen'; $ok.AutoSize=$true; $ok.DialogResult='OK'
    $cancel=New-Object Windows.Forms.Button; $cancel.Text='Abbrechen'; $cancel.AutoSize=$true; $cancel.DialogResult='Cancel'
    $buttons.Controls.AddRange(@($ok,$cancel))
    $panel.Controls.AddRange(@($label,$choice,$days,$buttons)); $dialog.Controls.Add($panel)
    $dialog.AcceptButton=$ok; $dialog.CancelButton=$cancel
    try {
        if ($dialog.ShowDialog($form) -ne 'OK') { return $null }
        if ($choice.SelectedIndex -eq 0) { return @{mode='unbounded'} }
        return @{mode='max-age';maxAgeSeconds=([int]$days.Value * 86400)}
    } finally { $dialog.Dispose() }
}
function Show-MigrationChoice($Change,$Candidates) {
    $dialog=New-Object Windows.Forms.Form
    $dialog.Text=if ($Change.priorChangeUnknown) { 'Alten Feldwert prüfen' } else { 'Feldänderung übertragen' }; $dialog.Size=New-Object Drawing.Size(720,350)
    $dialog.MinimumSize=New-Object Drawing.Size(580,320); $dialog.StartPosition='CenterParent'
    $dialog.Font=$form.Font
    $panel=New-Object Windows.Forms.TableLayoutPanel
    $panel.Dock='Fill'; $panel.Padding=New-Object Windows.Forms.Padding(18)
    $panel.ColumnCount=1; $panel.RowCount=5
    foreach ($height in @(105,35,42,42,55)) { $panel.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',$height))) | Out-Null }
    $dialog.Controls.Add($panel)
    $description=New-Object Windows.Forms.Label; $description.Dock='Fill'
    $sameFieldText=if ($Change.sameFieldSupported) { Get-EntryText $Change.currentSameField } else { 'Im neuen Vertrag nicht vorhanden' }
    $comparison=if ($Change.priorChangeUnknown) { 'Die alte Ausgangsrevision fehlt; ob dieser Wert lokal geändert wurde, ist unbekannt. Gespeicherter alter Wert: '+(Get-EntryText $Change.local) }
        else { 'Vorher: '+(Get-EntryText $Change.before)+' · dein Entwurf: '+(Get-EntryText $Change.local) }
    $description.Text='Plugin '+$Change.pluginId+' · bisheriges Feld '+$Change.oldField+"`r`n"+$comparison+"`r`nNeuer Stand im gleichnamigen Feld: "+$sameFieldText
    $panel.Controls.Add($description,0,0)
    $choice=New-Object Windows.Forms.ComboBox; $choice.DropDownStyle='DropDownList'; $choice.Dock='Fill'
    $choice.AccessibleName='Entscheidung für altes Feld'
    $choice.Items.Add($(if ($Change.priorChangeUnknown) { 'Aktuellen Stand behalten; alten Wert nicht übernehmen' }
        else { 'Neuen Stand behalten; alte Änderung nicht übernehmen' })) | Out-Null
    if ($Candidates.Count -gt 0) {
        $choice.Items.Add('Meinen alten Wert in ein neues Feld übernehmen') | Out-Null
        $choice.Items.Add('Neues Feld wieder erben lassen') | Out-Null
    }
    $choice.SelectedIndex=0; $panel.Controls.Add($choice,0,1)
    $targetLabel=New-Object Windows.Forms.Label; $targetLabel.Text='Zielfeld im neuen Vertrag (nur für Übernehmen/Erben)'; $targetLabel.Dock='Fill'
    $panel.Controls.Add($targetLabel,0,2)
    $target=New-Object Windows.Forms.ComboBox; $target.DropDownStyle='DropDownList'; $target.Dock='Fill'
    $target.AccessibleName='Zielfeld im neuen Vertrag'
    foreach ($candidate in $Candidates) { $target.Items.Add($candidate.field+' · '+$candidate.label+' ('+$candidate.type+')') | Out-Null }
    $same=@($Candidates | Where-Object { $_.field -eq $Change.oldField })
    if ($same.Count -eq 1) { $target.SelectedIndex=[array]::IndexOf(@($Candidates.field),$Change.oldField) }
    $target.Enabled=$false; $panel.Controls.Add($target,0,3)
    $buttons=New-Object Windows.Forms.FlowLayoutPanel; $buttons.Dock='Fill'
    $ok=New-Object Windows.Forms.Button; $ok.Text='Entscheidung übernehmen'; $ok.AutoSize=$true
    $cancel=New-Object Windows.Forms.Button; $cancel.Text='Abbrechen'; $cancel.AutoSize=$true; $cancel.DialogResult='Cancel'
    $buttons.Controls.AddRange(@($ok,$cancel)); $panel.Controls.Add($buttons,0,4)
    $dialog.Tag=@{Choice=$choice;Target=$target}
    $choice.Add_SelectedIndexChanged({ $context=$this.FindForm().Tag; $context.Target.Enabled=($this.SelectedIndex -ne 0) })
    $ok.Add_Click({
        $context=$this.FindForm().Tag
        if ($context.Choice.SelectedIndex -ne 0 -and $context.Target.SelectedIndex -lt 0) {
            [Windows.Forms.MessageBox]::Show($this.FindForm(),'Wähle zuerst ein Zielfeld.','Feldentscheidung','OK','Information') | Out-Null
            return
        }
        $this.FindForm().DialogResult='OK'; $this.FindForm().Close()
    })
    $dialog.CancelButton=$cancel
    try {
        if ($dialog.ShowDialog($form) -ne 'OK') { return $null }
        if ($choice.SelectedIndex -eq 0) { return @{choice='current'} }
        $selected=$Candidates[$target.SelectedIndex]
        return @{choice=$(if ($choice.SelectedIndex -eq 1) { 'local' } else { 'inherit' });targetField=$selected.field}
    } finally { $dialog.Dispose() }
}
function Show-DraftChooser {
    $directory=Join-Path $Store 'preferences-drafts'
    $ids=@(Get-ChildItem -LiteralPath $directory -File -Filter '*.json' -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -cmatch '^[a-z][a-z0-9-]{0,63}\.json$' } |
        ForEach-Object { [IO.Path]::GetFileNameWithoutExtension($_.Name) } | Sort-Object -Unique)
    if ($ids.Count -eq 0) { return $null }
    $dialog=New-Object Windows.Forms.Form
    $dialog.Text='Lokalen Entwurf öffnen'; $dialog.Size=New-Object Drawing.Size(580,220)
    $dialog.StartPosition='CenterParent'; $dialog.Font=$form.Font
    $panel=New-Object Windows.Forms.FlowLayoutPanel; $panel.Dock='Fill'; $panel.Padding=New-Object Windows.Forms.Padding(18)
    $label=New-Object Windows.Forms.Label; $label.Text='Wähle einen gespeicherten Entwurf. Seine Werte werden neu geprüft.'
    $label.Width=510; $label.Height=38
    $selector=New-Object Windows.Forms.ComboBox; $selector.DropDownStyle='DropDownList'; $selector.Width=510
    $selector.AccessibleName='Gespeicherter Entwurf'; $selector.Items.AddRange([string[]]$ids)
    $selector.SelectedIndex=[Math]::Max(0,[array]::IndexOf($ids,$script:activeDraftId))
    $open=New-Object Windows.Forms.Button; $open.Text='Entwurf öffnen'; $open.AutoSize=$true; $open.DialogResult='OK'
    $cancel=New-Object Windows.Forms.Button; $cancel.Text='Abbrechen'; $cancel.AutoSize=$true; $cancel.DialogResult='Cancel'
    $panel.Controls.AddRange(@($label,$selector,$open,$cancel)); $dialog.Controls.Add($panel)
    $dialog.AcceptButton=$open; $dialog.CancelButton=$cancel
    try { if ($dialog.ShowDialog($form) -eq 'OK') { return [string]$selector.SelectedItem }; return $null }
    finally { $dialog.Dispose() }
}
function Show-RunChooser {
    $directory=Join-Path $Store 'preferences-runs'
    $ids=@(Get-ChildItem -LiteralPath $directory -File -Filter '*.json' -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -cmatch '^[a-z][a-z0-9-]{0,63}\.json$' } |
        ForEach-Object { [IO.Path]::GetFileNameWithoutExtension($_.Name) } | Sort-Object -Unique)
    if ($ids.Count -eq 0) { $status.Text='Für dieses Gerät ist noch kein gebundener Auftragsbeleg gespeichert.'; return $null }
    $dialog=New-Object Windows.Forms.Form
    $dialog.Text='Auftragsbeleg ansehen'; $dialog.Size=New-Object Drawing.Size(580,220)
    $dialog.StartPosition='CenterParent'; $dialog.Font=$form.Font
    $panel=New-Object Windows.Forms.FlowLayoutPanel; $panel.Dock='Fill'; $panel.Padding=New-Object Windows.Forms.Padding(18)
    $label=New-Object Windows.Forms.Label; $label.Text='Wähle einen Auftrag. Der Manager prüft seinen Beleg und die signierte Profilrevision erneut.'
    $label.Width=510; $label.Height=38
    $selector=New-Object Windows.Forms.ComboBox; $selector.DropDownStyle='DropDownList'; $selector.Width=510
    $selector.AccessibleName='Gebundener Auftrag'; $selector.Items.AddRange([string[]]$ids); $selector.SelectedIndex=0
    $open=New-Object Windows.Forms.Button; $open.Text='Beleg prüfen'; $open.AutoSize=$true; $open.DialogResult='OK'
    $cancel=New-Object Windows.Forms.Button; $cancel.Text='Abbrechen'; $cancel.AutoSize=$true; $cancel.DialogResult='Cancel'
    $panel.Controls.AddRange(@($label,$selector,$open,$cancel)); $dialog.Controls.Add($panel)
    $dialog.AcceptButton=$open; $dialog.CancelButton=$cancel
    try { if ($dialog.ShowDialog($form) -eq 'OK') { return [string]$selector.SelectedItem }; return $null }
    finally { $dialog.Dispose() }
}
function Confirm-Migration([string]$NewDraft,[int]$Count) {
    $message='Die '+$Count+" ausgewählten Entscheidungen in einen neuen lokalen Entwurf übertragen?`r`nDer bisherige Entwurf bleibt erhalten. Es wird nichts veröffentlicht oder auf andere Geräte übertragen."
    return [Windows.Forms.MessageBox]::Show($form,$message,'Entwurf übertragen','YesNo','Question') -eq 'Yes'
}
function Update-PreferenceButtons {
    $busy=$null -ne $script:preferenceProcess
    $pending=$script:pendingEdits.Count + $script:pendingOfflineEdits.Count
    $save.Enabled=(!$busy -and $pending -gt 0)
    $discard.Enabled=(!$busy -and $pending -gt 0)
    $refresh.Enabled=(!$busy -and $pending -eq 0)
    $rebase.Enabled=(!$busy -and $pending -eq 0 -and $script:preferencePlan -and $script:preferencePlan.stale -and $script:preferencePlan.canRebase)
    $migrate.Enabled=(!$busy -and $pending -eq 0 -and $script:preferencePlan -and @($script:preferencePlan.structuralConflicts | Where-Object { $_.reason -ne 'offline-policy-changed' }).Count -gt 0)
    $rescue.Enabled=(!$busy -and $pending -eq 0)
    $chooseDraft.Enabled=(!$busy -and $pending -eq 0)
    $runEvidence.Enabled=!$busy
    $review.Enabled=(!$busy -and $pending -eq 0 -and $script:preferencePlan -and $script:preferencePlan.canExport)
    $publish.Enabled=(!$busy -and $pending -eq 0 -and $null -ne $script:publicationPlan -and !$script:publicationPlan.published -and !$script:publicationPlan.outcomeNeedsReconciliation)
    $list.Enabled=!$busy; $editor.Enabled=(!$busy -and $null -ne $script:selectedPreference)
    $offlineEdit.Enabled=(!$busy -and $null -ne $script:selectedPreference -and $script:preferencePlan -and $script:preferencePlan.offlineUse -isnot [string])
    $value.Enabled=($mode.SelectedIndex -eq 1)
    $close.Enabled=!$busy
}
function Show-PreferenceField {
    if ($list.SelectedItems.Count -ne 1 -or !$script:preferencePlan) { return }
    $script:loadingField=$true
    try {
        $script:selectedPreference=$list.SelectedItems[0].Tag
        $selected=$script:selectedPreference
        $plugin=$script:preferencePlan.editablePlugins.($selected.Plugin)
        $definition=$plugin.schema.fields.($selected.Field)
        $key=$selected.Plugin+'/'+$selected.Field
        $entry=if ($script:pendingEdits.ContainsKey($key)) { $script:pendingEdits[$key].Entry } else { $plugin.values.($selected.Field) }
        $mode.SelectedIndex=if ($null -eq $entry) { 0 } elseif ($entry.mode -eq 'value') { 1 } elseif ($entry.mode -eq 'ask') { 2 } else { 3 }
        $value.Items.Clear(); $value.Text=''
        if ($definition.type -eq 'boolean') { $value.DropDownStyle='DropDownList'; $value.Items.AddRange(@('Ja','Nein')); $value.SelectedIndex=if ($entry.value -eq $true) { 0 } else { 1 } }
        elseif ($definition.type -eq 'enum') { $value.DropDownStyle='DropDownList'; foreach ($item in $definition.values) { $value.Items.Add([string]$item) | Out-Null }; $value.SelectedItem=[string]$entry.value }
        else { $value.DropDownStyle='DropDown'; $value.Text=[string]$entry.value }
        $resolved=$script:preferencePlan.plugins.($selected.Plugin).fields.($selected.Field)
        $lines=@('Persönliche Bearbeitung: '+$definition.label, 'Die Vorschau ist noch keine lokal übernommene Einstellung.',
            (Get-OfflineRuleText $script:preferencePlan.offlineUse $selected.Plugin $selected.Field))
        if ($script:pendingOfflineEdits.ContainsKey($key)) {
            $rule=$script:pendingOfflineEdits[$key].Rule
            $lines+=$(if ($rule.mode -eq 'unbounded') { 'Noch nicht gespeichert: offline ohne Altersgrenze' }
                else { 'Noch nicht gespeichert: offline '+($rule.maxAgeSeconds / 86400)+' Tage' })
        }
        if ($resolved) {
            foreach ($item in $resolved.history) { $lines+=([string]$item.scope+' · '+[string]$item.source+' · Revision '+[string]$item.revision+' · '+(Get-EntryText $item.entry)) }
            foreach ($constraint in $resolved.constraints) { $lines+=('Verbindliche Regel: '+$constraint.source+' · Revision '+$constraint.revision+' · '+($constraint.rule | ConvertTo-Json -Compress -Depth 8)) }
        } else { $lines+='Firmenregeln derzeit nicht prüfbar. Speichern bleibt möglich; Freigabe und wirksame Vorschau sind gesperrt.' }
        $details.Text=$lines -join "`r`n"
    } finally { $script:loadingField=$false; Update-PreferenceButtons }
}
function Remember-PreferenceEdit {
    if ($script:loadingField -or !$script:selectedPreference) { return }
    $selected=$script:selectedPreference
    $definition=$script:preferencePlan.editablePlugins.($selected.Plugin).schema.fields.($selected.Field)
    $entry=switch ($mode.SelectedIndex) {
        0 { $null }; 2 { @{mode='ask'} }; 3 { @{mode='unset'} }
        1 { $chosen=if ($definition.type -eq 'boolean') { $value.SelectedIndex -eq 0 } else { $value.Text }; @{mode='value';value=$chosen} }
    }
    $script:pendingEdits[$selected.Plugin+'/'+$selected.Field]=@{Plugin=$selected.Plugin;Field=$selected.Field;Entry=$entry}
    $script:publicationPlan=$null
    if ($list.SelectedItems.Count -eq 1) { $list.SelectedItems[0].SubItems[1].Text=(Get-EntryText $entry)+' *' }
    $status.Text='Noch nicht gespeichert. „Entwurf speichern“ erhält alle bearbeiteten Felder; die Vorschau wird anschließend neu berechnet.'
    Update-PreferenceButtons
}
function Show-PreferencePlan($Plan) {
    $selected=$script:selectedPreference
    $script:preferencePlan=$Plan
    $list.BeginUpdate()
    try {
        $list.Items.Clear()
        foreach ($plugin in $Plan.editablePlugins.PSObject.Properties) {
            foreach ($field in $plugin.Value.schema.fields.PSObject.Properties) {
                if ($field.Value.scopes -notcontains 'personal') { continue }
                $resolved=$Plan.plugins.($plugin.Name).fields.($field.Name)
                $row=New-Object Windows.Forms.ListViewItem(($plugin.Name+' / '+$field.Value.label))
                $row.Tag=@{Plugin=$plugin.Name;Field=$field.Name}
                $row.SubItems.Add((Get-EntryText $plugin.Value.values.($field.Name))) | Out-Null
                $row.SubItems.Add($(if ($resolved) { Get-EntryText $resolved } else { 'Nicht prüfbar' })) | Out-Null
                $origin=if ($resolved) { [string]$resolved.origin.scope+' · '+[string]$resolved.origin.source } else { 'Firmenregeln nicht verfügbar' }
                if ($resolved.constraints.Count -gt 0) { $origin+=' · verbindliche Regel' }
                if ($Plan.offlineUse -isnot [string] -and $Plan.offlineUse.plugins.PSObject.Properties[$plugin.Name]) {
                    $offlineRule=$Plan.offlineUse.plugins.PSObject.Properties[$plugin.Name].Value.PSObject.Properties[$field.Name]
                    if ($offlineRule -and $offlineRule.Value.mode -eq 'max-age') {
                        $origin+=' · offline '+([math]::Round([double]$offlineRule.Value.maxAgeSeconds/86400,2))+' Tage'
                    }
                }
                $row.SubItems.Add($origin) | Out-Null; $list.Items.Add($row) | Out-Null
                if ($selected -and $selected.Plugin -eq $plugin.Name -and $selected.Field -eq $field.Name) { $row.Selected=$true }
            }
        }
        if ($list.SelectedItems.Count -eq 0 -and $list.Items.Count -gt 0) { $list.Items[0].Selected=$true }
    } finally { $list.EndUpdate() }
    $heading.Text=if ($Plan.stale) { 'Ein neuer Profilstand liegt vor. Dein Entwurf bleibt erhalten. Gleiche ihn vor der Freigabe mit dem neuen Stand ab.' } else { 'Persönlicher Entwurf. Speichern ändert noch keine andere Installation und veröffentlicht keine Freigabe.' }
    $appliedText=if ($null -ne $Plan.appliedRevision) { [string]$Plan.appliedRevision } else { 'noch keine' }
    $profileLine.Text='Profil: '+$Plan.displayName+' ('+$Plan.authority+'/'+$Plan.profileId+') · empfangen: '+$Plan.currentRevision+' · lokal übernommen: '+$appliedText+' · Entwurf: '+$script:activeDraftId
    $status.Text=if (@($Plan.structuralConflicts | Where-Object { $_.reason -eq 'offline-policy-changed' }).Count -gt 0) { 'Die Offline-Regel wurde auch im neueren Profil geändert. Der Entwurf bleibt erhalten; prüfe beide Regeln vor einer neuen Freigabe.' }
        elseif ($Plan.structuralConflicts.Count -gt 0) { 'Der Einstellungsvertrag hat sich geändert. Der Entwurf bleibt erhalten; eine Schema-Migration ist erforderlich.' }
        elseif ($Plan.conflicts.Count + $Plan.offlineConflicts.Count -gt 0) { [string]($Plan.conflicts.Count + $Plan.offlineConflicts.Count)+' Konflikt(e). Beim Abgleichen wählst du für jeden Wert und jede Offline-Regel deinen Entwurf oder den neuen Profilstand.' }
        elseif ($Plan.canExport) { 'Entwurf gespeichert und geprüft. „Freigabe prüfen“ zeigt Ziel, Revision und Änderungen vor der Veröffentlichung.' }
        else { 'Entwurf gespeichert. Herkunft und verbindliche Regeln stehen in den Felddetails.' }
    if ($script:recentMigrationFrom) {
        $status.Text='Neuer Entwurf geöffnet. Der frühere Entwurf „'+$script:recentMigrationFrom+'“ bleibt unter „Anderen Entwurf öffnen“ erhalten. Noch nichts veröffentlicht.'
        $script:recentMigrationFrom=$null
    }
    Show-PreferenceField; Update-PreferenceButtons
}
function Start-PreferenceAction([string]$Action, $Patch=$null) {
    if ($script:preferenceProcess) { return }
    $arguments=if ($Action -eq 'preferences-run-evidence') { @($Action,'--store',$Store,'--run-id',[string]$Patch) }
        else { @($Action,'--store',$Store,'--draft',$script:activeDraftId) }
    if ($Action -eq 'preferences-draft-save') { $arguments+=@('--confirmation',$script:preferencePlan.draftDigest) }
    if ($Action -eq 'preferences-draft-rebase') { $arguments+=@('--confirmation',$script:preferencePlan.planDigest) }
    if ($Action -like 'preferences-draft-migration-*' -or $Action -like 'preferences-draft-salvage-migration-*') { $arguments+=@('--new-draft',$script:migrationNewDraft) }
    if ($Action -eq 'preferences-draft-migration-apply' -or $Action -eq 'preferences-draft-salvage-migration-apply') { $arguments+=@('--confirmation',$script:migrationPlan.planDigest) }
    if ($Action -eq 'preferences-publication-publish') { $arguments+=@('--confirmation',$script:publicationPlan.confirmation) }
    if ($null -ne $Patch -and $Action -ne 'preferences-run-evidence') {
        $script:requestFile=Join-Path ([IO.Path]::GetTempPath()) ('ppm-preference-edit-'+[guid]::NewGuid().ToString('N')+'.json')
        $request=if ($Patch -is [hashtable] -and $Patch.ContainsKey('schemaVersion')) { $Patch } else { @{schemaVersion=1;plugins=$Patch} }
        [IO.File]::WriteAllText($script:requestFile,($request | ConvertTo-Json -Depth 20),(New-Object Text.UTF8Encoding($false)))
        $arguments+=@('--input',$script:requestFile)
    }
    $start=New-Object Diagnostics.ProcessStartInfo
    $start.FileName=$manager; $start.UseShellExecute=$false; $start.CreateNoWindow=$true
    $start.RedirectStandardOutput=$true; $start.RedirectStandardError=$true
    $start.StandardOutputEncoding=New-Object Text.UTF8Encoding($false); $start.StandardErrorEncoding=New-Object Text.UTF8Encoding($false)
    $start.Arguments=($arguments | ForEach-Object { '"'+[regex]::Replace([regex]::Replace([string]$_,'(\\*)"','$1$1\"'),'(\\+)$','$1$1')+'"' }) -join ' '
    try {
        $script:preferenceAction=$Action; $script:preferenceProcess=[Diagnostics.Process]::Start($start)
        $script:preferenceStdout=$script:preferenceProcess.StandardOutput.ReadToEndAsync(); $script:preferenceStderr=$script:preferenceProcess.StandardError.ReadToEndAsync()
        $status.Text='Manager prüft und speichert den gewählten Vorgang …'; $timer.Start()
    } catch {
        $script:preferenceProcess=$null; $status.Text='Manager konnte nicht starten. Deine Eingaben bleiben im Fenster erhalten.'
        if ($script:requestFile) { Remove-Item -LiteralPath $script:requestFile -ErrorAction SilentlyContinue; $script:requestFile=$null }
    }
    Update-PreferenceButtons
}
$timer.Add_Tick({
    if (!$script:preferenceProcess -or !$script:preferenceProcess.HasExited) { return }
    $code=$script:preferenceProcess.ExitCode; $output=$script:preferenceStdout.GetAwaiter().GetResult(); $failure=$script:preferenceStderr.GetAwaiter().GetResult()
    $script:preferenceProcess.Dispose(); $script:preferenceProcess=$null; $timer.Stop()
    if ($script:requestFile) { Remove-Item -LiteralPath $script:requestFile -ErrorAction SilentlyContinue; $script:requestFile=$null }
    if ($code -eq 0) {
        try {
            $result=$output | ConvertFrom-Json
            if ($script:preferenceAction -eq 'preferences-run-evidence') {
                if ($result.status -eq 'bound-input-recorded') {
                    $applied=if ($result.currentApplied) { 'Ja' } else { 'Nein; der Auftrag behält seine frühere Revision' }
                    $details.Text='Auftrag: '+$result.runId+"`r`nPlugin: "+$result.pluginId+"`r`nGebundene Profilrevision: "+$result.revision+"`r`nSignierte Generation: "+$result.generation+"`r`nDerzeit lokal übernommen: "+$applied+"`r`nInput-Digest: "+$result.inputDigest+"`r`nWirksamer Digest: "+$result.effectiveDigest
                    $status.Text='Der Manager-Lese- und Bindungsbeleg ist geprüft. Eine spätere Projektaktion oder Agentenausführung wird dadurch nicht bestätigt.'
                } else { $status.Text='Für diesen Auftrag ist kein Beleg gespeichert.' }
            } elseif ($script:preferenceAction -eq 'preferences-publication-plan') {
                $script:publicationPlan=$result
                $changes=@($result.draft.changes | ForEach-Object { $_.pluginId+' / '+$_.field+': '+(Get-EntryText $_.before)+' → '+(Get-EntryText $_.local) })
                foreach ($policyChange in $result.draft.offlineChanges) {
                    foreach ($policyPlugin in $policyChange.local.plugins.PSObject.Properties) {
                        foreach ($policyField in $policyPlugin.Value.PSObject.Properties) {
                            $prior=$policyChange.before.plugins.($policyPlugin.Name).($policyField.Name)
                            $new=$policyField.Value
                            if (($prior | ConvertTo-Json -Compress) -ne ($new | ConvertTo-Json -Compress)) {
                                $beforeText=if ($prior.mode -eq 'unbounded') { 'ohne Frist' } else { ([math]::Round([double]$prior.maxAgeSeconds/86400,2))+' Tage' }
                                $newText=if ($new.mode -eq 'unbounded') { 'ohne Frist' } else { ([math]::Round([double]$new.maxAgeSeconds/86400,2))+' Tage' }
                                $changes+=($policyPlugin.Name+' / '+$policyField.Name+' Offline: '+$beforeText+' → '+$newText)
                            }
                        }
                    }
                }
                $details.Text='Freigabeziel: '+$result.destination+"`r`nNeue Revision: "+$result.nextRevision+"`r`n"+($changes -join "`r`n")
                $status.Text=if ($result.published) { 'Diese Revision wurde bereits veröffentlicht. Die lokale Übernahme und andere Geräte bleiben getrennt zu prüfen.' }
                    elseif ($result.publicationPending) { 'Veröffentlichung vorbereitet; der Ausgangsstand ist noch aktuell. „Veröffentlichen“ setzt denselben Vorgang fort.' }
                    elseif ($result.outcomeNeedsReconciliation) { 'Remote-Stand geändert. Der Ausgang der Veröffentlichung muss abgeglichen werden.' }
                    else { 'Freigabe geprüft. Lies Ziel und Änderungen, bevor du „Veröffentlichen“ auswählst.' }
            } elseif ($script:preferenceAction -eq 'preferences-publication-publish') {
                $script:publicationPlan=$null
                $status.Text='Revision '+$result.acceptedRevision+' veröffentlicht. Lokale Übernahme und Nutzung durch andere Geräte sind noch nicht bestätigt.'
            } elseif ($script:preferenceAction -eq 'preferences-draft-migration-plan' -or
                      $script:preferenceAction -eq 'preferences-draft-salvage-migration-plan') {
                $isRescue=$script:preferenceAction -eq 'preferences-draft-salvage-migration-plan'
                $script:migrationPlan=$result
                if (!$result.canMigrate) { $status.Text=if ($isRescue) { 'Die Ausgangsrevision ist noch verfügbar oder die Profilidentität passt nicht. Der Entwurf bleibt unverändert; nutze den normalen Abgleich oder die Schemaübertragung.' }
                    else { 'Für diesen Entwurf ist derzeit keine Schemaübertragung möglich. Der alte Entwurf bleibt erhalten.' } }
                else {
                    $decisions=@{}; $cancelled=$false
                    if ($isRescue) { $changes=@($result.oldPersonalFields) }
                    else { $changes=@($result.localChanges) }
                    foreach ($change in $changes) {
                        $candidates=@($result.targetFields.($change.pluginId) | Where-Object { $null -ne $_ })
                        $decision=Show-MigrationChoice $change $candidates
                        if ($null -eq $decision) { $cancelled=$true; break }
                        if (!$decisions.ContainsKey($change.pluginId)) { $decisions[$change.pluginId]=@{} }
                        $decisions[$change.pluginId][$change.oldField]=$decision
                    }
                    if ($cancelled) { $status.Text='Übertragung abgebrochen. Der bisherige Entwurf ist unverändert.' }
                    else {
                        if (Confirm-Migration $script:migrationNewDraft $changes.Count) {
                            Start-PreferenceAction $(if ($isRescue) { 'preferences-draft-salvage-migration-apply' } else { 'preferences-draft-migration-apply' }) $decisions
                        } else { $status.Text='Übertragung nicht übernommen. Der bisherige Entwurf ist unverändert.' }
                    }
                }
            } elseif ($script:preferenceAction -eq 'preferences-draft-migration-apply' -or
                      $script:preferenceAction -eq 'preferences-draft-salvage-migration-apply') {
                $old=$script:activeDraftId
                $script:draftBeforeSelection=$old
                $script:activeDraftId=$result.newDraftId
                $script:recentMigrationFrom=$old
                $script:migrationPlan=$null; $script:publicationPlan=$null; $script:pendingEdits=@{}; $script:pendingOfflineEdits=@{}
                Start-PreferenceAction 'preferences-draft-plan'
            } else {
                $script:publicationPlan=$null; $script:pendingEdits=@{}; $script:pendingOfflineEdits=@{}; Show-PreferencePlan $result
                $script:draftBeforeSelection=$null
            }
        }
        catch { $status.Text='Die Antwort konnte nicht gelesen werden. Gespeicherte Entwürfe bleiben erhalten; öffne das Fenster erneut.' }
    } else {
        if ($script:preferenceAction -eq 'preferences-draft-plan' -and $script:draftBeforeSelection) {
            $script:activeDraftId=$script:draftBeforeSelection; $script:draftBeforeSelection=$null
            $script:recentMigrationFrom=$null
        }
        if ($script:preferenceAction -like 'preferences-publication-*') { $script:publicationPlan=$null }
        $status.Text=if ($failure -match 'preferences:not-configured|store-not-initialized') { 'Noch nicht eingerichtet: Eine geprüfte persönliche Konfigurationsquelle muss zuerst diesem Gerät zugeordnet werden.' }
            elseif ($script:preferenceAction -in @('preferences-draft-create','preferences-draft-plan') -and $failure -match 'command-failed code=file-missing|generation-missing') { 'Eine signierte Ausgangsgeneration des Entwurfs fehlt. Der gespeicherte Entwurf bleibt erhalten. Prüfe den Managerzustand; über „Entwurf mit verlorener Basis retten“ kannst du seine Werte einzeln auf den aktuellen Stand übertragen.' }
            elseif ($failure -match 'draft-or-plan-changed') { 'Der Entwurf wurde zwischenzeitlich geändert. Deine Eingaben bleiben hier erhalten. Kopiere sie vor dem Schließen; ein neues Fenster zeigt den gespeicherten Stand.' }
            elseif ($script:preferenceAction -in @('preferences-draft-migration-apply','preferences-draft-salvage-migration-apply') -and $failure -match 'migration-plan-changed') { 'Der Profilstand oder der alte Entwurf hat sich geändert. Prüfe die Übertragung erneut; es wurde kein neuer Entwurf übernommen.' }
            elseif ($script:preferenceAction -in @('preferences-draft-migration-apply','preferences-draft-salvage-migration-apply') -and $failure -match 'text-required|boolean-required|unsupported-value|absolute-path-required|https-origin-required|migration-unknown-or-duplicate-target') { 'Der alte Wert passt nicht zum gewählten Zielfeld. Wähle ein anderes Zielfeld oder behalte den neuen Stand und bearbeite den neuen Entwurf anschließend.' }
            elseif ($script:preferenceAction -in @('preferences-draft-migration-apply','preferences-draft-salvage-migration-apply') -and $failure -match 'new-draft-exists|new-draft-already-differs') { 'Der vorgesehene neue Entwurf existiert bereits. Öffne ihn über „Anderen Entwurf öffnen“ oder prüfe den Vorgang erneut.' }
            else { 'Der Manager hat den Vorgang angehalten. Deine Eingaben bleiben erhalten; bitte den gespeicherten Stand prüfen.' }
    }
    Update-PreferenceButtons
})
$list.Add_SelectedIndexChanged({ Show-PreferenceField })
$mode.Add_SelectedIndexChanged({
    try { Remember-PreferenceEdit; Update-PreferenceButtons }
    catch { $status.Text='Die Änderung konnte nicht übernommen werden. Deine Eingabe bleibt im Fenster erhalten.' }
})
$value.Add_TextChanged({
    try { Remember-PreferenceEdit }
    catch { $status.Text='Die Änderung konnte nicht übernommen werden. Deine Eingabe bleibt im Fenster erhalten.' }
})
$value.Add_SelectedIndexChanged({
    try { Remember-PreferenceEdit }
    catch { $status.Text='Die Auswahl konnte nicht übernommen werden. Bitte den Feldwert erneut prüfen.' }
})
$save.Add_Click({
    $values=@{}
    foreach ($edit in $script:pendingEdits.Values) { if (!$values.ContainsKey($edit.Plugin)) { $values[$edit.Plugin]=@{} }; $values[$edit.Plugin][$edit.Field]=$edit.Entry }
    $patch=if ($script:pendingOfflineEdits.Count -gt 0) {
        $rules=@{}
        foreach ($edit in $script:pendingOfflineEdits.Values) {
            if (!$rules.ContainsKey($edit.Plugin)) { $rules[$edit.Plugin]=@{} }
            $rules[$edit.Plugin][$edit.Field]=$edit.Rule
        }
        @{schemaVersion=2;plugins=$values;offlineUse=@{plugins=$rules}}
    } else { $values }
    Start-PreferenceAction 'preferences-draft-save' $patch
})
$offlineEdit.Add_Click({
    if (!$script:selectedPreference -or $script:preferencePlan.offlineUse -is [string]) { return }
    $selected=$script:selectedPreference; $key=$selected.Plugin+'/'+$selected.Field
    $rule=if ($script:pendingOfflineEdits.ContainsKey($key)) { $script:pendingOfflineEdits[$key].Rule }
        else { $script:preferencePlan.offlineUse.plugins.($selected.Plugin).($selected.Field) }
    if (!$rule) { $rule=@{mode='unbounded'} }
    $next=Show-OfflineRuleChoice $rule
    if ($null -eq $next) { return }
    $script:pendingOfflineEdits[$key]=@{Plugin=$selected.Plugin;Field=$selected.Field;Rule=$next}
    $script:publicationPlan=$null
    $status.Text='Offline-Frist noch nicht gespeichert. „Entwurf speichern“ prüft die Änderung.'
    Show-PreferenceField
})
$refresh.Add_Click({ Start-PreferenceAction 'preferences-draft-plan' })
$chooseDraft.Add_Click({
    $chosen=Show-DraftChooser
    if ($chosen -and $chosen -ne $script:activeDraftId) {
        $script:draftBeforeSelection=$script:activeDraftId
        $script:activeDraftId=$chosen; $script:publicationPlan=$null; $script:migrationPlan=$null
        $script:selectedPreference=$null; Start-PreferenceAction 'preferences-draft-plan'
    }
})
$runEvidence.Add_Click({ $id=Show-RunChooser; if ($id) { Start-PreferenceAction 'preferences-run-evidence' $id } })
$migrate.Add_Click({
    if (!$script:preferencePlan -or $script:preferencePlan.structuralConflicts.Count -eq 0) { return }
    $script:migrationNewDraft='personal-m'+$script:preferencePlan.currentRevision+'-'+$script:preferencePlan.planDigest.Substring(0,12)
    Start-PreferenceAction 'preferences-draft-migration-plan'
})
$rescue.Add_Click({
    $chosen=Show-DraftChooser
    if (!$chosen) { $status.Text='Kein gespeicherter Entwurf für die Rettung ausgewählt.'; return }
    $script:activeDraftId=$chosen
    $script:migrationNewDraft='personal-r'+[guid]::NewGuid().ToString('N').Substring(0,16)
    $script:migrationPlan=$null; $script:preferencePlan=$null; $script:publicationPlan=$null
    $list.Items.Clear(); $details.Text='Der gespeicherte Entwurf wird gegen das aktuelle signierte Schema geprüft. Die alte Ausgangsrevision fehlt.'
    Start-PreferenceAction 'preferences-draft-salvage-migration-plan'
})
$review.Add_Click({ Start-PreferenceAction 'preferences-publication-plan' })
$publish.Add_Click({
    if (!$script:publicationPlan -or $script:publicationPlan.published -or $script:publicationPlan.outcomeNeedsReconciliation) { return }
    $message='Persönliche Einstellungen als Revision '+$script:publicationPlan.nextRevision+' nach '+$script:publicationPlan.destination+" veröffentlichen?`r`n`r`nDanach können angebundene Geräte diese signierte Revision übernehmen."
    if ([Windows.Forms.MessageBox]::Show($form,$message,'Persönliche Freigabe','YesNo','Question') -eq 'Yes') {
        Start-PreferenceAction 'preferences-publication-publish'
    }
})
$discard.Add_Click({ $script:pendingEdits=@{}; $script:pendingOfflineEdits=@{}; Start-PreferenceAction 'preferences-draft-plan' })
$rebase.Add_Click({
    $patch=@{}
    foreach ($conflict in $script:preferencePlan.conflicts) {
        $message=$conflict.pluginId+' / '+$conflict.field+"`r`nBisher: "+(Get-EntryText $conflict.before)+"`r`nDein Entwurf: "+(Get-EntryText $conflict.local)+"`r`nNeues Profil: "+(Get-EntryText $conflict.remote)+"`r`n`r`nDeinen Entwurf für dieses Feld behalten? Ja: Entwurf. Nein: neues Profil. Abbrechen: nichts ändern."
        $choice=[Windows.Forms.MessageBox]::Show($form,$message,'Profilkonflikt','YesNoCancel','Question')
        if ($choice -eq 'Cancel') { return }
        if (!$patch.ContainsKey($conflict.pluginId)) { $patch[$conflict.pluginId]=@{} }
        $patch[$conflict.pluginId][$conflict.field]=if ($choice -eq 'Yes') { $conflict.local } else { $conflict.remote }
    }
    $offline=@{}
    foreach ($conflict in $script:preferencePlan.offlineConflicts) {
        $before=if ($conflict.before.mode -eq 'unbounded') { 'ohne Frist' } else { ([math]::Round([double]$conflict.before.maxAgeSeconds/86400,2))+' Tage' }
        $local=if ($conflict.local.mode -eq 'unbounded') { 'ohne Frist' } else { ([math]::Round([double]$conflict.local.maxAgeSeconds/86400,2))+' Tage' }
        $remote=if ($conflict.remote.mode -eq 'unbounded') { 'ohne Frist' } else { ([math]::Round([double]$conflict.remote.maxAgeSeconds/86400,2))+' Tage' }
        $message=$conflict.pluginId+' / '+$conflict.field+" · Offline-Frist`r`nBisher: "+$before+"`r`nDein Entwurf: "+$local+"`r`nNeues Profil: "+$remote+"`r`n`r`nDeinen Entwurf für diese Frist behalten? Ja: Entwurf. Nein: neues Profil. Abbrechen: nichts ändern."
        $choice=[Windows.Forms.MessageBox]::Show($form,$message,'Offline-Konflikt','YesNoCancel','Question')
        if ($choice -eq 'Cancel') { return }
        if (!$offline.ContainsKey($conflict.pluginId)) { $offline[$conflict.pluginId]=@{} }
        $offline[$conflict.pluginId][$conflict.field]=if ($choice -eq 'Yes') { $conflict.local } else { $conflict.remote }
    }
    if ($offline.Count -gt 0) { Start-PreferenceAction 'preferences-draft-rebase' @{schemaVersion=2;plugins=$patch;offlineUse=@{plugins=$offline}} }
    else { Start-PreferenceAction 'preferences-draft-rebase' $patch }
})
$close.Add_Click({ $form.Close() })
$form.Add_FormClosing({ param($sender,$eventArgs)
    if ($script:preferenceProcess) { $eventArgs.Cancel=$true; $status.Text='Der Speichervorgang läuft noch. Bitte das Ergebnis abwarten.' }
    elseif ($script:pendingEdits.Count + $script:pendingOfflineEdits.Count -gt 0) { $eventArgs.Cancel=$true; $status.Text='Bitte speichere die offenen Änderungen vor dem Schließen. Bei einem Konflikt kannst du die Werte aus den Feldern kopieren.' }
})
$form.Add_Shown({ Start-PreferenceAction 'preferences-draft-create' })
Update-PreferenceButtons
if ($ValidateOnly) { $form.Dispose(); $timer.Dispose(); 'Preferences editor constructed; no profile read or written.'; return }
$script:managerWorkLease = & (Join-Path $PSScriptRoot 'Manager-Work-Lease.ps1')
try {
    try { $form.ShowDialog() | Out-Null } finally { $timer.Dispose(); $form.Dispose() }
} finally {
    if ($script:managerWorkLease) { $script:managerWorkLease.Dispose() }
}
