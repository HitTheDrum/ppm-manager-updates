﻿param([string]$Store, [switch]$Restore, [switch]$ValidateOnly)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
$Store=[IO.Path]::GetFullPath($Store)
$manager=Join-Path $PSScriptRoot 'out\PluginManager.exe'
$script:prefix=if ($Restore) { 'preferences-local-restore-' } else { 'preferences-local-remove-' }
$script:plan=$null; $script:cancelPlan=$null; $script:process=$null; $script:restartNeeded=$false
$form=New-Object Windows.Forms.Form
$form.Text=if ($Restore) { 'Persönliche Einstellungen hier wiederherstellen' } else { 'Persönliche Einstellungen hier entfernen' }
$form.Size=New-Object Drawing.Size(820,520); $form.MinimumSize=New-Object Drawing.Size(680,430)
$form.StartPosition='CenterScreen'; $form.Font=New-Object Drawing.Font('Segoe UI',11)
$layout=New-Object Windows.Forms.TableLayoutPanel
$layout.Dock='Fill'; $layout.Padding=New-Object Windows.Forms.Padding(18)
$layout.ColumnCount=1; $layout.RowCount=3
$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',105))) | Out-Null
$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Percent',100))) | Out-Null
$layout.RowStyles.Add((New-Object Windows.Forms.RowStyle('Absolute',70))) | Out-Null
$form.Controls.Add($layout)
$intro=New-Object Windows.Forms.Label; $intro.Dock='Fill'; $intro.AutoSize=$false
$intro.Text=if ($Restore) {
    'Die zuletzt geprüfte persönliche Konfiguration kann auf diesem Gerät erneut aktiviert werden. Die Quelle wird dadurch nicht wieder verbunden. Aktuelle Firmenregeln werden vor der Aktivierung geprüft.'
} else {
    'Nur die Nutzung persönlicher Einstellungen auf diesem Gerät wird beendet. Das Profil im Internet, Firmenregeln, Zugangsdaten und bereits ausgeführte Projekte bleiben bestehen.'
}
$layout.Controls.Add($intro,0,0)
$summary=New-Object Windows.Forms.TextBox
$summary.Dock='Fill'; $summary.Multiline=$true; $summary.ReadOnly=$true
$summary.ScrollBars='Vertical'; $summary.AccessibleName='Vorschau und Ergebnis'
$summary.Text=if ($Restore) { 'Wiederherstellung prüfen, bevor du sie bestätigst.' }
    else { 'Lokale Entfernung prüfen, bevor du sie bestätigst. Einen laufenden Hintergrundabgleich zuerst beenden.' }
$layout.Controls.Add($summary,0,1)
$buttons=New-Object Windows.Forms.FlowLayoutPanel; $buttons.Dock='Fill'; $buttons.AutoScroll=$true
$check=New-Object Windows.Forms.Button; $check.Text=if ($Restore) { 'Wiederherstellung prüfen' } else { 'Entfernung prüfen' }; $check.AutoSize=$true
$commit=New-Object Windows.Forms.Button; $commit.Text=if ($Restore) { 'Hier wiederherstellen' } else { 'Hier entfernen' }; $commit.AutoSize=$true
$resume=New-Object Windows.Forms.Button; $resume.Text='Unterbrochenen Schritt fortsetzen'; $resume.AutoSize=$true
$cancel=New-Object Windows.Forms.Button; $cancel.Text='Wiederherstellung abbrechen prüfen'; $cancel.AutoSize=$true; $cancel.Visible=[bool]$Restore
$restart=New-Object Windows.Forms.Button; $restart.Text='Abgleich neu starten'; $restart.AutoSize=$true; $restart.Visible=!$Restore
$close=New-Object Windows.Forms.Button; $close.Text='Schließen'; $close.AutoSize=$true
$buttons.Controls.AddRange(@($check,$commit,$resume,$cancel,$restart,$close))
$layout.Controls.Add($buttons,0,2)
$timer=New-Object Windows.Forms.Timer; $timer.Interval=150
function Pending-Path { Join-Path $Store $(if ($Restore) { 'preferences-local-restore-pending.json' } else { 'preferences-local-removal-pending.json' }) }
function Update-Buttons {
    $busy=$null -ne $script:process
    $pending=Test-Path -LiteralPath (Pending-Path) -PathType Leaf
    $check.Enabled=!$busy -and !$pending
    $commit.Enabled=!$busy -and !$pending -and $null -ne $script:plan -and $(if ($Restore) { $script:plan.canRestore } else { $script:plan.canRemoveHere })
    $resume.Enabled=!$busy -and $pending
    $cancel.Enabled=!$busy -and $pending -and [bool]$Restore
    $cancel.Text=if ($script:cancelPlan) { 'Abbruch bestätigen' } else { 'Wiederherstellung abbrechen prüfen' }
    $restart.Enabled=!$busy -and $script:restartNeeded
    $close.Enabled=!$busy
}
function Format-Entry($Entry) {
    if ($null -eq $Entry) { return 'nicht gesetzt' }
    switch ($Entry.mode) {
        'ask' { return 'pro Projekt fragen' }
        'unset' { return 'bewusst ungelöst' }
        'value' {
            if ($Entry.value -is [bool]) { if ($Entry.value) { return 'Ja' } else { return 'Nein' } }
            if ($null -eq $Entry.value) { return 'kein Wert' }
            return [string]$Entry.value
        }
        default { return 'unbekannt' }
    }
}
function Show-Plan($Result) {
    if ($Restore) {
        $lines=@('Profil: '+$Result.displayName,
            'Wieder zu aktivierende Profilrevision: '+$Result.targetRevision,
            'Online-Stand: nicht geprüft. Die persönliche Quelle bleibt getrennt.',
            'Aktuell gespeicherte Firmenregeln wurden erneut geprüft; Zugangsdaten werden nicht wiederhergestellt.')
        if ($Result.conflictingPlugins.Count -gt 0) {
            $lines+=('Wiederherstellung gesperrt durch verbindliche Regel bei: '+($Result.conflictingPlugins -join ', '))
        } elseif ($Result.fieldChanges.Count -eq 0) {
            $lines+='Die persönlichen Werte der letzten angewendeten und der jetzt zu aktivierenden Generation stimmen überein.'
        } else {
            $lines+='Änderungen gegenüber der zuletzt angewendeten Generation:'
            foreach ($change in $Result.fieldChanges) {
                $lines+=('• '+$change.pluginId+' / '+$change.label+': '+(Format-Entry $change.before)+' → '+(Format-Entry $change.after))
            }
        }
        $summary.Text=$lines -join "`r`n"
    } else {
        $company=if ($Result.companyBound) { 'Die Firmenbindung bleibt aktiv.' } else { 'Keine Firmenquelle auf diesem Gerät gebunden.' }
        $values=if ($Result.appliedRevision) { 'Zuletzt angewendete Profilrevision: '+$Result.appliedRevision }
            else { 'Bisher wurde keine persönliche Generation angewendet.' }
        $connection=if ($Result.sourceConnection -eq 'connected') { 'Die automatische persönliche Quellenverbindung wird getrennt; danach den Abgleich neu starten.' }
            else { 'Die persönliche Quellenverbindung ist bereits getrennt.' }
        $summary.Text=@('Profil: '+$Result.displayName,$values,$connection,$company,
            'Lokale Entwürfe: '+$Result.localDraftCount+' · vorhandene Auftragsbelege: '+$Result.priorRunCount,
            'Signierte Historie bleibt zur Prüfung erhalten. Neue Aufträge erhalten nach der Entfernung keine persönlichen Werte.',
            'Das Online-Profil, vorhandene Projekte, Plugins und Zugangsdaten werden nicht gelöscht.') -join "`r`n"
    }
}
function Start-Action([string]$Action) {
    if ($script:process) { return }
    if ($Action -eq 'restart') {
        $file='powershell.exe'; $arguments=@('-NoProfile','-File',(Join-Path $PSScriptRoot 'Neustart-Hintergrund.ps1'),'-Store',$Store)
    } else {
        $file=$manager; $command=$script:prefix+$(if ($Action -eq 'commit') { 'commit' } else { $Action })
        $arguments=@($command,'--store',$Store)
        if ($Action -eq 'commit') { $arguments+=@('--confirmation',$script:plan.planDigest) }
        if ($Action -eq 'cancel') { $arguments+=@('--confirmation',$script:cancelPlan.planDigest) }
    }
    $start=New-Object Diagnostics.ProcessStartInfo
    $start.FileName=$file; $start.UseShellExecute=$false; $start.CreateNoWindow=$true
    $start.RedirectStandardOutput=$true; $start.RedirectStandardError=$true
    $start.StandardOutputEncoding=New-Object Text.UTF8Encoding($false)
    $start.StandardErrorEncoding=New-Object Text.UTF8Encoding($false)
    $start.Arguments=($arguments | ForEach-Object { '"'+[regex]::Replace([regex]::Replace([string]$_,'(\\*)"','$1$1\"'),'(\\+)$','$1$1')+'"' }) -join ' '
    try {
        $script:action=$Action; $script:process=[Diagnostics.Process]::Start($start)
        $script:stdout=$script:process.StandardOutput.ReadToEndAsync()
        $script:stderr=$script:process.StandardError.ReadToEndAsync()
        $summary.Text='Der lokale Stand wird geprüft …'; $timer.Start()
    } catch { $script:process=$null; $summary.Text='Der Manager konnte nicht gestartet werden. Bitte die lokale Installation prüfen.' }
    Update-Buttons
}
$timer.Add_Tick({
    if (!$script:process -or !$script:process.HasExited) { return }
    $code=$script:process.ExitCode; $output=$script:stdout.GetAwaiter().GetResult()
    $failure=$script:stderr.GetAwaiter().GetResult()
    $script:process.Dispose(); $script:process=$null; $timer.Stop()
    if ($code -eq 0) {
        try {
            if ($script:action -eq 'restart') {
                $script:restartNeeded=$false
                $summary.Text='Der Hintergrundabgleich wurde ohne persönliche Quellenverbindung neu gestartet. Gebundene Firmenregeln werden weiter geprüft.'
            } else {
                $result=$output | ConvertFrom-Json
                if ($script:action -eq 'plan') { $script:plan=$result; Show-Plan $result }
                elseif ($script:action -eq 'cancel-plan') {
                    $script:cancelPlan=$result
                    $summary.Text='Die unterbrochene Wiederherstellung wird abgebrochen. Persönliche Werte bleiben auf diesem Gerät für neue Aufträge gesperrt.'+"`r`n"+
                        'Das Online-Profil und die Firmenbindung bleiben unverändert. Eine spätere Wiederherstellung braucht eine neue Prüfung.'
                }
                else {
                    $script:plan=$null; $script:cancelPlan=$null
                    if ($script:action -eq 'cancel') {
                        $summary.Text='Die unterbrochene Wiederherstellung wurde abgebrochen. Persönliche Werte bleiben hier für neue Aufträge gesperrt; Firmenbindung und Online-Profil sind unverändert.'
                    } elseif ($Restore) { $summary.Text='Persönliche Werte wurden auf diesem Gerät wieder aktiviert. Die Quelle bleibt getrennt; die tatsächliche Nutzung durch neue Aufträge ist noch nicht beobachtet.' }
                    else {
                        $script:restartNeeded=[bool]$result.backgroundRestartRequired
                        $summary.Text='Persönliche Werte wurden auf diesem Gerät für neue Aufträge deaktiviert. Firmenbindung, signierte Historie und Online-Profil bleiben bestehen.'+
                            $(if ($script:restartNeeded) { "`r`nDer Hintergrundabgleich muss nun sichtbar neu gestartet werden." } else { '' })
                    }
                }
            }
        } catch { $summary.Text='Die Antwort konnte nicht gelesen werden. Den lokalen Stand erneut prüfen.' }
    } else {
        $script:plan=$null; $script:cancelPlan=$null
        $summary.Text=if ($failure -match 'command-failed code=io-failure') { 'Ein Hintergrundlauf verwendet den Manager noch. Bitte den Abgleich beenden und dann erneut prüfen.' }
            elseif ($failure -match 'not-configured') { 'Auf diesem Gerät ist noch kein persönliches Profil eingerichtet.' }
            elseif ($Restore -and $failure -match 'command-failed code=file-missing') { 'Auf diesem Gerät gibt es keine lokale Entfernung, die wiederhergestellt werden kann.' }
            elseif ($failure -match 'resume-local-lifecycle') { 'Ein lokaler Schritt ist noch offen. Bitte zuerst „Unterbrochenen Schritt fortsetzen“ wählen.' }
            elseif ($failure -match 'removed-here') { 'Die persönlichen Werte sind hier bereits entfernt oder ein lokaler Schritt ist noch offen. Bitte den Stand erneut prüfen.' }
            else { 'Der Schritt wurde nicht bestätigt. Bitte den bisherigen lokalen Stand prüfen.' }
    }
    Update-Buttons
})
$check.Add_Click({ Start-Action 'plan' })
$commit.Add_Click({ Start-Action 'commit' })
$resume.Add_Click({ Start-Action 'resume' })
$cancel.Add_Click({ if ($script:cancelPlan) { Start-Action 'cancel' } else { Start-Action 'cancel-plan' } })
$restart.Add_Click({ Start-Action 'restart' })
$close.Add_Click({ $form.Close() })
Update-Buttons
if ($ValidateOnly) { $timer.Dispose(); $form.Dispose(); 'Local preferences dialog constructed; no state changed.'; return }
$script:managerWorkLease = & (Join-Path $PSScriptRoot 'Manager-Work-Lease.ps1')
try {
    try { $form.ShowDialog() | Out-Null } finally { $timer.Dispose(); $form.Dispose() }
} finally {
    if ($script:managerWorkLease) { $script:managerWorkLease.Dispose() }
}
