﻿param([Parameter(Mandatory=$true)][string]$Store, [switch]$ValidateOnly)
$ErrorActionPreference='Stop'
$Store=[IO.Path]::GetFullPath($Store)
$profile=[IO.Path]::GetDirectoryName($Store)
$configuration=Join-Path $profile 'background.json'
& (Join-Path $PSScriptRoot 'Hintergrund.ps1') -Configuration $configuration -ValidateOnly | Out-Null
if ($ValidateOnly) { 'Background restart configuration checked; no process changed.'; return }
$statusPath=Join-Path $Store 'background-status.json'
function Read-RunningWorker {
    if (!(Test-Path -LiteralPath $statusPath)) { return $null }
    try {
        $status=Get-Content -LiteralPath $statusPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($status.state -notin @('starting','running','stopping')) { return $null }
        $worker=Get-Process -Id $status.workerId -ErrorAction SilentlyContinue
        if ($worker -and $worker.StartTime.ToUniversalTime().Ticks -eq ([DateTimeOffset]$status.workerStartedAt).UtcDateTime.Ticks) {
            return $status
        }
    } catch { }
    return $null
}
$old=Read-RunningWorker
if ($old) {
    $manager=Join-Path $PSScriptRoot 'out\PluginManager.exe'
    & $manager stop-watch --store $Store | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Der laufende Abgleich konnte nicht angehalten werden.' }
    $deadline=[DateTime]::UtcNow.AddSeconds(45)
    do {
        Start-Sleep -Milliseconds 250
        $worker=Get-Process -Id $old.workerId -ErrorAction SilentlyContinue
        $supervisor=Get-Process -Id $old.supervisorId -ErrorAction SilentlyContinue
        if (!$worker -and !$supervisor) { break }
    } while ([DateTime]::UtcNow -lt $deadline)
    if ($worker -or $supervisor) { throw 'Der bisherige Abgleich läuft noch. Bitte den Neustart später erneut versuchen.' }
}
& (Join-Path $PSScriptRoot 'Start-Hintergrund.ps1') -Configuration $configuration | Out-Null
$deadline=[DateTime]::UtcNow.AddSeconds(20)
do {
    Start-Sleep -Milliseconds 250
    $current=Read-RunningWorker
    if ($current -and (!$old -or $current.workerId -ne $old.workerId)) {
        [pscustomobject]@{restarted=$true;workerId=$current.workerId;configuration=$configuration} | ConvertTo-Json -Compress
        return
    }
} while ([DateTime]::UtcNow -lt $deadline)
throw 'Der neue Hintergrundabgleich konnte nicht bestätigt werden. Bitte den Managerzustand prüfen.'
